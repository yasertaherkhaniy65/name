"""
یارنامه — نقطه ورود نسخه اجرایی ویندوز (بسته PyInstaller).
پنجره راه‌انداز کوچک را باز می‌کند؛ بدون Electron.
"""
import sys
from pathlib import Path


def _ensure_source_path():
    """در حالت اجرایی (frozen)، مسیر منابع بسته را به sys.path اضافه می‌کند."""
    if getattr(sys, "frozen", False):
        base = Path(getattr(sys, "_MEIPASS", Path(sys.executable).parent))
        if str(base) not in sys.path:
            sys.path.insert(0, str(base))


_ensure_source_path()

from launcher import run_gui, run_headless  # noqa: E402

if __name__ == "__main__":
    if "--headless" in sys.argv:
        run_headless()
    else:
        run_gui()
