@echo off
REM ============================================================
REM  یارنامه — اجرای نسخه توسعه روی ویندوز
REM  پیش‌نیاز: Python 3.11+ (تیک Add python.exe to PATH هنگام نصب)
REM ============================================================
chcp 65001 >nul
title YarNameh - Local Service
cd /d "%~dp0"

REM ---------- پیدا کردن پایتون (اول py -3 بعد python) ----------
set "PY="
py -3 --version >nul 2>&1 && set "PY=py -3"
if not defined PY (
    python --version >nul 2>&1 && set "PY=python"
)
if not defined PY (
    echo.
    echo  خطا: پایتون روی این سیستم پیدا نشد!
    echo  --------------------------------------------------
    echo  ۱) Python 3.11 یا جدیدتر را از python.org نصب کنید
    echo  ۲) حین نصب تیک "Add python.exe to PATH" را حتماً بزنید
    echo  ۳) این پنجره را ببندید و run_dev.bat را دوباره اجرا کنید
    echo.
    pause
    exit /b 1
)

REM ---------- بررسی نسخه (حداقل 3.9) ----------
for /f "tokens=2" %%v in ('%PY% -c "import sys; print(sys.version.split()[0])" 2^>nul') do set "PYVER=%%v"
echo پایتون: %PYVER%
%PY% -c "import sys; sys.exit(0 if sys.version_info >= (3, 9) else 1)" || (
    echo.
    echo  خطا: نسخه پایتون قدیمی است. یارنامه به Python 3.9+ نیاز دارد ^(توصیه: 3.11+^).
    echo.
    pause
    exit /b 1
)

REM ---------- نصب وابستگی‌ها (فقط بار اول طول می‌کشد) ----------
echo در حال بررسی/نصب وابستگی‌ها...
%PY% -m pip install -r requirements.txt --disable-pip-version-check -q
if errorlevel 1 (
    echo.
    echo  خطا: نصب وابستگی‌ها ناموفق بود — اتصال اینترنت را بررسی کنید.
    echo.
    pause
    exit /b 1
)

REM ---------- اجرای سرویس ----------
echo.
echo  یارنامه در حال راه‌اندازی است... مرورگر به‌صورت خودکار باز می‌شود.
echo  برای توقف سرویس این پنجره را با Ctrl+C ببندید یا پنجره را ببندید.
echo.
%PY% run_dev.py %*
if errorlevel 1 (
    echo.
    echo  خطا در اجرای سرویس — پیام بالا را بررسی کنید.
    echo  اگر پورت 8765 اشغال است:  run_dev.bat --port 8900
    echo.
    pause
    exit /b 1
)
pause
