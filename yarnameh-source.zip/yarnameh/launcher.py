"""
یارنامه — راه‌انداز دسکتاپ (بدون Electron، با Tkinter استاندارد پایتون)
- راه‌اندازی سرویس محلی روی 127.0.0.1 در نخ جداگانه
- جلوگیری از اجرای چند نمونه (Single Instance با بررسی سلامت سرویس)
- مدیریت پورت اشغالی: اگر پورت یارنامه است، همان را باز کن؛ وگرنه پورت آزاد امن
- باز کردن رابط کاربری در مرورگر پیش‌فرض
- توقف امن سرویس هنگام خروج
"""
from __future__ import annotations

import json
import socket
import sys
import threading
import time
import webbrowser

import urllib.request

# Tkinter ممکن است در برخی محیط‌ها نباشد — اجرای بدون پنجره هم پشتیبانی می‌شود
try:
    import tkinter as tk
    from tkinter import font as tkfont
    from tkinter import messagebox  # ← در سطح ماژول؛ در غیر این صورت نامش در quit_all تعریف‌نشده می‌ماند
    HAS_TK = True
except Exception:
    HAS_TK = False

from app import config


def is_yarnameh_on_port(port: int) -> bool:
    try:
        req = urllib.request.Request(f"http://127.0.0.1:{port}/api/health",
                                     headers={"Host": "127.0.0.1"})
        with urllib.request.urlopen(req, timeout=2) as resp:
            data = json.loads(resp.read().decode())
            return data.get("app") == "YarNameh"
    except Exception:
        return False


def find_free_port(start: int) -> int:
    for p in range(start, start + 40):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            try:
                s.bind(("127.0.0.1", p))
                return p
            except OSError:
                continue
    return start


class Service:
    def __init__(self):
        self.port = None
        self.thread = None
        self.server = None
        self.started = threading.Event()

    def start(self) -> str:
        """خروجی: وضعیت — 'already' | 'started:<port>'"""
        cfg = config.read_config()
        port = int(cfg.get("port", config.DEFAULT_PORT))
        if is_yarnameh_on_port(port):
            self.port = port
            return "already"
        if port_is_busy(port):
            port = find_free_port(port + 1)
            config.write_config({"port": port})
        self.port = port
        self.thread = threading.Thread(target=self._run, daemon=True)
        self.thread.start()
        ok = self.started.wait(timeout=25)
        if not ok:
            raise RuntimeError("سرویس در مدت مجاز راه‌اندازی نشد")
        return f"started:{port}"

    def _run(self):
        import uvicorn
        from app.main import app
        server_cfg = uvicorn.Config(app, host="127.0.0.1", port=self.port, log_level="warning")
        self.server = uvicorn.Server(server_cfg)
        self.started.set()
        self.server.run()

    def stop(self):
        if self.server:
            try:
                self.server.should_exit = True
                for _ in range(50):
                    if not self.server.started or getattr(self.server, "exited", False):
                        break
                    time.sleep(0.1)
            except Exception:
                pass


def port_is_busy(port: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(0.4)
        return s.connect_ex(("127.0.0.1", port)) == 0


def open_ui(port: int):
    webbrowser.open(f"http://127.0.0.1:{port}/", new=1, autoraise=True)


# --------------------------- رابط پنجره کوچک ---------------------------

def run_gui():
    service = Service()
    try:
        status = service.start()
    except Exception as e:
        root = tk.Tk(); root.withdraw()
        messagebox.showerror("یارنامه", f"خطا در راه‌اندازی سرویس:\n{e}")
        sys.exit(1)

    root = tk.Tk()
    root.title("یارنامه — راه‌انداز")
    root.geometry("380x230")
    root.resizable(False, False)
    root.configure(bg="#f2f5fa")
    try:
        root.attributes("-topmost", False)
    except Exception:
        pass

    NAVY = "#123459"
    ACCENT = "#2563eb"
    tkfont.nametofont("TkDefaultFont").configure(size=10)

    tk.Label(root, text="یارنامه", bg="#f2f5fa", fg=NAVY,
             font=("Vazirmatn", 18, "bold")).pack(pady=(18, 2))
    status_text = "سرویس از قبل فعال بود" if status == "already" else "سرویس راه‌اندازی شد"
    tk.Label(root, text=f"{status_text} — پورت {service.port}", bg="#f2f5fa",
             fg="#15803d").pack()
    tk.Label(root, text="http://127.0.0.1:%d" % service.port, bg="#f2f5fa",
             fg="#64748b").pack()

    btns = tk.Frame(root, bg="#f2f5fa")
    btns.pack(pady=14)

    def open_app():
        open_ui(service.port)

    def restart():
        service.stop()

        def _after_stop():
            # صبر تا آزاد شدن واقعی پورت (حداکثر ~۸ ثانیه) تا start حالت "already" نگیرد
            for _ in range(80):
                if not port_is_busy(service.port):
                    break
                time.sleep(0.1)
            try:
                service.start()
                open_app()
            except Exception as e:
                messagebox.showerror("یارنامه", f"راه‌اندازی مجدد ناموفق بود:\n{e}")

        root.after(400, _after_stop)

    def quit_all():
        if quit_all.confirmed or messagebox.askyesno(
                "خروج", "سرویس بسته شود؟ رابط کاربری باز در مرورگر از کار می‌افتد."):
            service.stop()
            root.destroy()
    quit_all.confirmed = False

    tk.Button(btns, text="باز کردن برنامه", command=open_app, bg=ACCENT, fg="white",
              width=16, relief="flat", padx=8, pady=4).grid(row=0, column=0, padx=5)
    tk.Button(btns, text="راه‌اندازی مجدد سرویس", command=restart, bg="#e8f0fe", fg=NAVY,
              width=16, relief="flat", padx=8, pady=4).grid(row=0, column=1, padx=5)
    tk.Button(root, text="خروج و توقف سرویس", command=quit_all, bg="#fdeaea", fg="#dc2626",
              width=34, relief="flat", pady=4).pack()

    tk.Label(root, text="اطلاعات شما در محل مستقل داده‌ها ذخیره می‌شود و با حذف برنامه پاک نمی‌گردد.",
             bg="#f2f5fa", fg="#94a3b8", font=("Vazirmatn", 8), wraplength=340).pack(side="bottom", pady=8)

    open_app()
    root.protocol("WM_DELETE_WINDOW", quit_all)
    root.mainloop()


def run_headless():
    """اجرای بدون پنجره (سرویس + بازکردن مرورگر)."""
    service = Service()
    status = service.start()
    open_ui(service.port)
    print(f"YarNameh service on 127.0.0.1:{service.port} ({status}) — Ctrl+C to stop")
    try:
        while True:
            time.sleep(3600)
    except KeyboardInterrupt:
        service.stop()


if __name__ == "__main__":
    if "--headless" in sys.argv or not HAS_TK:
        run_headless()
    else:
        run_gui()
