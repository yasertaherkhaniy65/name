; یارنامه — نصب‌کننده ویندوز (Inno Setup)
; ساخت: اجرای Inno Setup Compiler روی این فایل پس از ساخت dist\YarNameh با PyInstaller
; خروجی: installer\YarNameh-Setup-1.0.0.exe

#define MyAppName "یارنامه"
#define MyAppNameEn "YarNameh"
#define MyAppVersion "1.0.0"
#define MyAppExeName "YarNameh.exe"

[Setup]
AppId={{8E1B6C42-7A54-4B2E-9C3D-YARNAMEH001}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppVerName={#MyAppName} {#MyAppVersion}
DefaultDirName={autopf}\{#MyAppNameEn}
DefaultGroupName={#MyAppName}
UninstallDisplayIcon={app}\{#MyAppExeName}
OutputDir=.
OutputBaseFilename=YarNameh-Setup-{#MyAppVersion}
Compression=lzma2/max
SolidCompression=yes
WizardStyle=modern
; پشتیبانی زبان فارسی در رابط نصب‌کننده
ShowLanguageDialog=no
PrivilegesRequired=admin
; داده‌های کاربر در LOCALAPPDATA است و هنگام Uninstall حذف نمی‌شود:
UninstallFilesDir={app}\uninst

[Languages]
; ⚠️ Inno Setup 6 به‌صورت پیش‌فرض فایل Persian.isl ندارد و نبودش باعث خطای کامپایل می‌شود.
; اگر فایل Persian.isl را از jrsoftware.org/files/istrans دریافت و در پوشه Languages نصب Inno کپی کردید،
; خط بعدی را فعال کنید:
; Name: "persian"; MessagesFile: "compiler:Languages\Persian.isl"
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "ایجاد میان‌بر روی میزکار"; GroupDescription: "میان‌برها:"

[Files]
; محتوای بسته PyInstaller (کل پوشه dist\YarNameh)
Source: "..\dist\YarNameh\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{group}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"
Name: "{group}\Uninstall {#MyAppName}"; Filename: "{uninstallexe}"
Name: "{autodesktop}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "اجرای {#MyAppName}"; Flags: nowait postinstall skipifsilent

[UninstallRun]

[UninstallDelete]

[Messages]
; محل داده‌های کاربر (پاک نمی‌شود): %LOCALAPPDATA%\YarNameh
