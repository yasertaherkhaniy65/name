// یارنامه — راه‌انداز اصلی، مسیریابی SPA و منو
import { api, toast } from './api.js';
import { icon } from './icons.js';
import { todayJalali, formatJalali, toFa } from './jalali.js';

const MENU = [
  { label: 'عملیات', items: [
    { hash: '#/dashboard', title: 'داشبورد', icon: 'dashboard', sub: 'نمای کلی و دسترسی سریع' },
    { hash: '#/letters/new', title: 'ایجاد نامه جدید', icon: 'letterNew', sub: 'انتخاب الگو، تکمیل پارامترها و نگارش نامه' },
    { hash: '#/archive', title: 'نامه‌های من و بایگانی', icon: 'archive', sub: 'جست‌وجو در سوابق نامه‌ها' },
  ]},
  { label: 'دفاتر', items: [
    { hash: '#/contacts', title: 'مخاطبین', icon: 'contacts', sub: 'اشخاص، شرکت‌ها، بانک‌ها و سازمان‌ها' },
    { hash: '#/signatories', title: 'امضاکنندگان و مهرها', icon: 'stamp', sub: 'مدیریت امضاکنندگان و تصاویر امضا و مهر' },
    { hash: '#/templates', title: 'الگوهای نامه', icon: 'templates', sub: 'الگوهای آماده و الگوهای اختصاصی' },
  ]},
  { label: 'ابزارها', items: [
    { hash: '#/reports', title: 'گزارش‌ها', icon: 'reports', sub: 'آمار نامه‌های صادرشده' },
    { hash: '#/settings', title: 'تنظیمات', icon: 'settings', sub: 'اطلاعات سازمان و تنظیمات برنامه' },
    { hash: '#/backup', title: 'پشتیبان‌گیری و بازیابی', icon: 'backup', sub: 'حفاظت از اطلاعات' },
  ]},
];

const ROUTES = {
  '#/dashboard': () => import('./views/dashboard.js'),
  '#/letters/new': () => import('./views/letter-wizard.js'),
  '#/letters/edit': () => import('./views/letter-wizard.js'),
  '#/letters/view': () => import('./views/letter-view.js'),
  '#/letters/print': () => import('./views/letter-print.js'),
  '#/archive': () => import('./views/archive.js'),
  '#/contacts': () => import('./views/contacts.js'),
  '#/signatories': () => import('./views/signatories.js'),
  '#/templates': () => import('./views/templates.js'),
  '#/template-edit': () => import('./views/template-builder.js'),
  '#/reports': () => import('./views/reports.js'),
  '#/settings': () => import('./views/settings.js'),
  '#/backup': () => import('./views/backup.js'),
};

export const store = { dashboard: null, templates: null, contactsCache: [] };

function renderMenu(currentHash) {
  const menu = document.getElementById('main-menu');
  menu.innerHTML = MENU.map(group => `
    <div class="menu-label">${group.label}</div>
    ${group.items.map(it => `
      <button class="menu-item ${currentHash.startsWith(it.hash) ? 'active' : ''}" data-hash="${it.hash}">
        ${icon(it.icon, 19)}<span>${it.title}</span>
        ${it.hash === '#/archive' ? '<span class="menu-badge" id="menu-drafts" style="display:none"></span>' : ''}
      </button>`).join('')}
  `).join('');
  menu.querySelectorAll('.menu-item').forEach(b => b.onclick = () => { location.hash = b.dataset.hash; });
}

export function setActive(hash) { renderMenu(hash); }

let currentController = null;
export async function navigate() {
  const hash = location.hash || '#/dashboard';
  const [base, query] = hash.split('?');
  const params = new URLSearchParams(query || '');
  const route = ROUTES[base];
  const root = document.getElementById('view-root');
  if (currentController) currentController.abort();
  currentController = new AbortController();

  const match = base.match(/^#\/letters\/edit/);
  if (!route) { location.hash = '#/dashboard'; return; }

  // عنوان صفحه
  for (const g of MENU) for (const it of g.items) {
    if (base.startsWith(it.hash)) {
      document.getElementById('page-title').textContent = it.title;
      document.getElementById('page-sub').textContent = it.sub;
    }
  }
  setActive(base);
  root.innerHTML = `<div class="skeleton" style="min-height:300px"></div>`;
  try {
    const mod = await route();
    root.innerHTML = '';
    await mod.render(root, { params, signal: currentController.signal });
  } catch (err) {
    if (err.name === 'AbortError') return;
    console.error(err);
    root.innerHTML = `<div class="card card-pad"><div class="empty">
      <h4>خطا در بارگذاری صفحه</h4><p>${err.message || 'خطای نامشخص'}</p></div></div>`;
  }
}

window.addEventListener('hashchange', navigate);

async function boot() {
  // آیکون لوگو
  document.getElementById('brand-logo').innerHTML =
    '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M4 5h16M4 9h16M4 13h10M4 17h7"/></svg>';
  document.getElementById('btn-new-letter').innerHTML = icon('letterNew', 16) + '<span>نامه جدید</span>';
  document.getElementById('btn-new-letter').onclick = () => { location.hash = '#/letters/new'; };
  document.getElementById('today-chip').innerHTML = `${icon('calendar', 15)} ${formatJalali(todayJalali(), 'long')}`;

  try {
    const h = await api.get('/api/health');
    document.getElementById('app-version').textContent = toFa(h.version.replace('.', '٫'));
    document.getElementById('service-status').innerHTML =
      `<span style="color:#34d399">●</span> سرویس فعال`;
    await refreshDraftsBadge();
  } catch {
    document.getElementById('service-status').innerHTML = '<span style="color:#f87171">●</span> قطع';
  }
  renderMenu(location.hash || '#/dashboard');
  await navigate();
}

export async function refreshDraftsBadge() {
  try {
    const r = await api.get('/api/letters?status=draft&page_size=5');
    const b = document.getElementById('menu-drafts');
    if (b && r.total > 0) { b.textContent = toFa(r.total); b.style.display = ''; }
    else if (b) b.style.display = 'none';
  } catch { /* بی‌اهمیت */ }
}

boot();
