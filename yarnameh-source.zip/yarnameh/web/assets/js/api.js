// یارنامه — کلاینت API + ابزارهای رابط کاربری (توست، مودال، فرمت‌ها)
import { toFa } from './jalali.js';

export class ApiError extends Error {
  constructor(status, data) {
    const msg = typeof data?.detail === 'string' ? data.detail
      : Array.isArray(data?.detail) ? data.detail.map(e => e.msg || '').join('، ')
      : data?.detail?.message || (data?.errors ? data.errors.join('؛ ') : 'خطای نامشخص');
    super(msg || 'خطا در ارتباط با سرویس');
    this.status = status; this.data = data;
  }
}

async function request(method, url, body, opts = {}) {
  const headers = {};
  let payload;
  if (body instanceof FormData) payload = body;
  else if (body !== undefined) { headers['Content-Type'] = 'application/json'; payload = JSON.stringify(body); }
  const resp = await fetch(url, { method, headers, body: payload, credentials: 'same-origin' });
  if (resp.status === 204) return {};
  let data = null;
  try { data = await resp.json(); } catch { /* بدون بدنه */ }
  if (!resp.ok) throw new ApiError(resp.status, data);
  return data;
}

export const api = {
  get: (url) => request('GET', url),
  post: (url, body) => request('POST', url, body),
  put: (url, body) => request('PUT', url, body),
  del: (url) => request('DELETE', url),
  upload: (url, formData) => request('POST', url, formData),
};

// ---------------- توست ----------------
export function toast(msg, type = 'success', ms = 3500) {
  const el = document.createElement('div');
  el.className = `toast toast-${type}`;
  el.textContent = msg;
  document.getElementById('toasts').appendChild(el);
  setTimeout(() => { el.style.opacity = '0'; el.style.transition = 'opacity .3s'; setTimeout(() => el.remove(), 320); }, ms);
}

// ---------------- مودال ----------------
export function openModal({ title, body, footer = '', size = '', onClose }) {
  closeModal();
  const overlay = document.createElement('div');
  overlay.className = 'modal-overlay';
  overlay.innerHTML = `<div class="modal ${size}">
    <div class="modal-head"><h3>${title}</h3>
      <button class="btn btn-ghost btn-icon modal-x">${'<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M18 6L6 18M6 6l12 12"/></svg>'}</button></div>
    <div class="modal-body">${body}</div>
    ${footer ? `<div class="modal-foot">${footer}</div>` : ''}
  </div>`;
  document.getElementById('modal-root').appendChild(overlay);
  const close = () => { overlay.remove(); onClose && onClose(); };
  overlay.querySelector('.modal-x').onclick = close;
  overlay.addEventListener('mousedown', e => { if (e.target === overlay) close(); });
  overlay.closeModal = close;
  return overlay;
}
export function closeModal() {
  const root = document.getElementById('modal-root');
  if (root.lastElementChild) root.lastElementChild.remove();
}

export function confirmDialog(title, message, confirmLabel = 'تأیید', danger = false) {
  return new Promise(resolve => {
    const m = openModal({
      title, size: '',
      body: `<p style="font-size:13.5px;line-height:2">${message}</p>`,
      footer: `<button class="btn btn-ghost" data-act="no">انصراف</button>
               <button class="btn ${danger ? 'btn-danger' : 'btn-primary'}" data-act="yes">${confirmLabel}</button>`,
      onClose: () => resolve(false),
    });
    m.querySelector('[data-act="no"]').onclick = () => { m.closeModal(); resolve(false); };
    m.querySelector('[data-act="yes"]').onclick = () => { m.closeModal(); resolve(true); };
  });
}

// ---------------- فرمت‌ها ----------------
export function fa(n) { return toFa(n); }
export function faNum(n) { return toFa(Number(n || 0).toLocaleString('en-US')); }
export function statusBadge(status) {
  const map = {
    draft: ['badge-draft', 'پیش‌نویس'], final: ['badge-final', 'ثبت‌شده'], canceled: ['badge-canceled', 'ابطال‌شده'],
  };
  const [cls, label] = map[status] || ['badge-muted', status];
  return `<span class="badge ${cls}"><span class="dot"></span>${label}</span>`;
}
export function amountInputValue(v) {
  if (!v) return '';
  const digits = String(v).replace(/[^\d]/g, '');
  return digits ? Number(digits).toLocaleString('en-US') : '';
}
export function bindAmountInputs(root) {
  root.querySelectorAll('.amount-input').forEach(inp => {
    inp.addEventListener('input', () => {
      const digits = inp.value.replace(/[^\d]/g, '');
      inp.value = digits ? Number(digits).toLocaleString('en-US') : '';
    });
  });
}
export function debounce(fn, ms) {
  let t; return (...args) => { clearTimeout(t); t = setTimeout(() => fn(...args), ms); };
}
export function esc(s) {
  return String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}
export function pagination(el, { total, page, page_size }, onPage) {
  const pages = Math.max(1, Math.ceil(total / page_size));
  el.innerHTML = `<span>${toFa(total)} مورد — صفحه ${toFa(page)} از ${toFa(pages)}</span>
    <div class="pbtns">
      <button class="btn btn-ghost btn-sm" ${page <= 1 ? 'disabled' : ''} data-p="${page - 1}">قبلی</button>
      <button class="btn btn-ghost btn-sm" ${page >= pages ? 'disabled' : ''} data-p="${page + 1}">بعدی</button>
    </div>`;
  el.querySelectorAll('[data-p]').forEach(b => b.onclick = () => onPage(+b.dataset.p));
}
export function emptyState(title, desc, actionHtml = '') {
  return `<div class="empty">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8zM14 2v6h6"/></svg>
    <h4>${title}</h4><p>${desc}</p>${actionHtml}</div>`;
}
