// یارنامه — رندر سند نامه (سربرگ، شماره/تاریخ، موضوع، متن، امضاها) — مشترک بین نمایش و چاپ
import { toFa } from './jalali.js';

function orgLine(org) {
  const parts = [org.phone && `تلفن: ${org.phone}`, org.email && `ایمیل: ${org.email}`,
    org.national_id && `شناسه ملی: ${org.national_id}`, org.address].filter(Boolean);
  return parts.join(' | ');
}

function faDate(str) {
  if (!str) return '';
  return toFa(String(str).replace(/-/g, '/'));
}

export function renderSheetHtml(letter, org, { preview = false } = {}) {
  const sizeClass = `sheet-${letter.paper_size}-${letter.orientation}`;
  const margins = { normal: '18mm 20mm', narrow: '12mm 14mm', wide: '25mm 26mm' };
  const pad = margins[letter.margin_preset] || margins.normal;
  const orgData = org || {};
  const numStr = letter.letter_number
    ? `<div>شماره: <b>${toFa(letter.letter_number)}</b></div>`
    : `<div>شماره: <b style="letter-spacing:3px">..........</b></div>`;
  const dateStr = letter.issued_date_jalali
    ? `<div>تاریخ: <b>${faDate(letter.issued_date_jalali)}</b></div>`
    : `<div>تاریخ: <b style="letter-spacing:3px">..........</b></div>`;

  const signatories = (letter.signatories || []).map(s => `
    <div class="sheet-sign ${s.stamp_image_path ? 'sheet-stamp' : ''}">
      ${s.signature_image_path ? `<img class="sig-img" src="/api/media/${s.signature_image_path.replace('files/', '')}">` : '<div style="height:14mm"></div>'}
      <div class="sig-name">${s.snapshot_name}</div>
      <div class="sig-pos">${s.snapshot_position || ''}</div>
      ${s.stamp_image_path ? `<img class="stamp-img" src="/api/media/${s.stamp_image_path.replace('files/', '')}">` : ''}
    </div>`).join('');

  return `<div class="sheet ${sizeClass}" style="--sheet-pad:${pad}">
    <div class="sheet-inner">
      <div class="sheet-header">
        <div class="sheet-org">
          <div class="sheet-org-name">${orgData.name || 'نام سازمان (تنظیمات)'}</div>
          <div class="sheet-org-info">${orgLine(orgData)}</div>
        </div>
        ${orgData.logo_path ? `<img class="sheet-logo" src="/api/media/${orgData.logo_path.replace('files/', '')}">` : ''}
      </div>
      <div class="sheet-meta">${numStr}${dateStr}</div>
      <div class="sheet-subject">موضوع: ${letter.subject || '—'}</div>
      <div class="sheet-body">${letter.body_html || ''}</div>
      ${letter.attachments?.length ? `<div class="sheet-attach"><b>پیوست‌ها:</b>
        ${letter.attachments.map((a, i) => `${i + 1}) ${a.file_name}`).join('&nbsp;&nbsp;')}</div>` : ''}
      ${signatories ? `<div class="sheet-signs">${signatories}</div>` : ''}
    </div>
  </div>`;
}

export function printCssFor(letter) {
  const size = letter.paper_size === 'A5' ? 'A5' : 'A4';
  const orient = letter.orientation === 'landscape' ? 'landscape' : 'portrait';
  const margins = { normal: '15mm 18mm', narrow: '10mm 12mm', wide: '22mm 24mm' };
  const m = margins[letter.margin_preset] || margins.normal;
  return `@page { size: ${size} ${orient}; margin: ${m}; }`;
}
