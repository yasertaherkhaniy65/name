// یارنامه — داشبورد اصلی
import { api, faNum, statusBadge, emptyState, toast } from '../api.js';
import { icon } from '../icons.js';
import { toFa, formatJalaliStr } from '../jalali.js';
import { refreshDraftsBadge } from '../main.js';

export async function render(root) {
  const [d, org] = await Promise.all([api.get('/api/dashboard'), api.get('/api/organization')]);

  root.innerHTML = `
  <div class="col">
    <div class="card card-pad row-between" style="background:linear-gradient(135deg,var(--navy-900),var(--navy-700));border:none;color:#fff">
      <div>
        <div style="font-size:18px;font-weight:700;margin-bottom:4px">خوش آمدید ${d.org_name ? 'در ' + d.org_name : ''}</div>
        <div style="font-size:13px;color:#b9c9e0">امروز ${formatJalaliStr(d.today_jalali, 'long')} — وضعیت آخرین پشتیبان‌گیری: ${d.last_backup_at ? toFa(d.last_backup_at) : '<span style="color:#fbbf24">هنوز پشتیبان تهیه نشده</span>'}</div>
      </div>
      <button class="btn btn-accent" id="dash-new" style="background:#3b82f6">${icon('letterNew', 17)} ایجاد نامه جدید</button>
    </div>

    <div class="stat-grid">
      ${statCard('navy', 'archive', faNum(d.total_final), 'کل نامه‌های ثبت‌شده', "#/archive?status=final")}
      ${statCard('blue', 'calendar', faNum(d.month_letters), 'ثبت‌شده در ماه جاری', "#/archive")}
      ${statCard('amber', 'edit', faNum(d.drafts), 'پیش‌نویس‌ها', "#/archive?status=draft")}
      ${statCard('green', 'contacts', faNum(d.contacts), 'مخاطبین فعال', '#/contacts')}
    </div>

    <div class="grid-main-aside">
      <div class="card">
        <div class="card-head"><h3>${icon('clock', 17)} آخرین نامه‌ها</h3>
          <a class="link small" href="#/archive">مشاهده بایگانی</a></div>
        ${d.last_letters.length ? `<div class="table-wrap"><table class="tbl">
          <thead><tr><th>شماره</th><th>موضوع</th><th>مخاطب</th><th>تاریخ</th><th>وضعیت</th></tr></thead>
          <tbody>${d.last_letters.map(l => `
            <tr style="cursor:pointer" onclick="location.hash='#/letters/view?id=${l.id}'">
              <td class="nowrap b">${l.letter_number ? toFa(l.letter_number) : '<span class="muted">—</span>'}</td>
              <td style="max-width:280px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${l.subject || 'بدون موضوع'}</td>
              <td>${l.contact_name || '<span class="muted">—</span>'}</td>
              <td class="nowrap muted">${l.issued_date_jalali ? formatJalaliStr(l.issued_date_jalali) : toFa(l.created_at.slice(0, 10))}</td>
              <td>${statusBadge(l.status)}</td>
            </tr>`).join('')}
          </tbody></table></div>`
        : emptyState('هنوز نامه‌ای ثبت نشده است', 'با انتخاب یکی از ۳۰ الگوی آماده، اولین نامه رسمی خود را در چند دقیقه صادر کنید.',
          '<button class="btn btn-primary" onclick="location.hash=\'#/letters/new\'">ایجاد نامه جدید</button>')}
      </div>
      <div class="col">
        <div class="card">
          <div class="card-head"><h3>${icon('templates', 17)} الگوهای پرکاربرد</h3></div>
          <div class="card-pad" style="padding-top:10px">
            ${d.top_templates.length ? d.top_templates.map(t => `
              <div class="row-between" style="padding:9px 0;border-bottom:1px solid var(--line);cursor:pointer"
                   onclick="location.hash='#/letters/new?template=${t.id}'">
                <div><div style="font-size:13px;font-weight:600">${t.title}</div>
                <div class="small muted">${t.category}</div></div>
                <span class="badge badge-accent">${toFa(t.used)} بار</span>
              </div>`).join('')
            : `<div class="small muted">پس از صدور نامه‌ها، پرکاربردترین الگوها اینجا نمایش داده می‌شوند.</div>`}
          </div>
        </div>
        <div class="card">
          <div class="card-head"><h3>${icon('search', 17)} جست‌وجوی سریع</h3></div>
          <div class="card-pad">
            <input class="input" id="quick-search" placeholder="شماره نامه، موضوع یا مخاطب…"
                   onkeydown="if(event.key==='Enter')location.hash='#/archive?q='+encodeURIComponent(this.value)">
          </div>
        </div>
      </div>
    </div>
  </div>`;

  document.getElementById('dash-new').onclick = () => { location.hash = '#/letters/new'; };
  refreshDraftsBadge();
}

function statCard(tint, ic, num, label, href) {
  const map = { navy: 'tint-navy', blue: 'tint-blue', amber: 'tint-amber', green: 'tint-green' };
  return `<a class="stat-card" href="${href}">
    <div class="stat-icon ${map[tint]}">${icon(ic, 22)}</div>
    <div><div class="stat-num">${num}</div><div class="stat-label">${label}</div></div></a>`;
}
