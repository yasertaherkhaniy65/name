// یارنامه — گزارش‌ها
import { api, faNum } from '../api.js';
import { icon } from '../icons.js';
import { toFa, MONTHS } from '../jalali.js';

export async function render(root) {
  const yearSel = new Date().getFullYear();
  const r = await api.get(`/api/reports`);
  const max = Math.max(...r.by_month.map(m => m.count), 1);
  const jyNow = r.year;
  const statusMap = { draft: 'پیش‌نویس', final: 'ثبت‌شده', canceled: 'ابطال‌شده' };

  root.innerHTML = `<div class="col">
    <div class="card">
      <div class="card-head"><h3>${icon('reports', 18)} گزارش نامه‌های ثبت‌شده — سال ${toFa(jyNow)}</h3></div>
      <div class="card-pad">
        <div class="chart-row" style="display:flex;align-items:flex-end;gap:10px;height:220px;padding:10px 4px">
          ${r.by_month.map(m => `
            <div style="flex:1;display:flex;flex-direction:column;align-items:center;gap:6px;height:100%;justify-content:flex-end">
              <span class="small b" style="color:var(--navy-800)">${m.count ? toFa(m.count) : ''}</span>
              <div style="width:70%;max-width:44px;background:linear-gradient(180deg,var(--accent),var(--navy-700));
                border-radius:6px 6px 0 0;height:${Math.round(m.count / max * 150) || 2}px;transition:height .4s" title="${m.count} نامه"></div>
              <span class="small muted">${MONTHS[m.month - 1].slice(0, 4)}</span>
            </div>`).join('')}
        </div>
      </div>
    </div>
    <div class="grid-3">
      <div class="card">
        <div class="card-head"><h3>بر اساس دسته‌بندی</h3></div>
        <div class="card-pad" style="padding-top:8px">
          ${r.by_category.length ? r.by_category.map(c => `
            <div class="row-between" style="padding:7px 0;border-bottom:1px solid var(--line)">
              <span class="small">${c.cat}</span><span class="badge badge-accent">${toFa(c.c)}</span></div>`).join('')
          : '<div class="small muted">داده‌ای موجود نیست</div>'}
        </div>
      </div>
      <div class="card">
        <div class="card-head"><h3>مخاطبین پرتکرار</h3></div>
        <div class="card-pad" style="padding-top:8px">
          ${r.by_contact.length ? r.by_contact.map(c => `
            <div class="row-between" style="padding:7px 0;border-bottom:1px solid var(--line)">
              <span class="small" style="max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${c.name}</span>
              <span class="badge badge-muted">${toFa(c.c)}</span></div>`).join('')
          : '<div class="small muted">داده‌ای موجود نیست</div>'}
        </div>
      </div>
      <div class="card">
        <div class="card-head"><h3>وضعیت نامه‌ها</h3></div>
        <div class="card-pad" style="padding-top:8px">
          ${r.by_status.map(s => `
            <div class="row-between" style="padding:7px 0;border-bottom:1px solid var(--line)">
              <span class="small">${statusMap[s.status] || s.status}</span><span class="badge badge-muted">${toFa(s.c)}</span></div>`).join('')}
          <div class="divider"></div>
          <div class="row-between"><span class="small b">مجموع سال‌های قبل</span>
            <span class="small muted">${r.by_year.map(y => `${toFa(y.y)}: ${toFa(y.c)}`).join(' — ') || '—'}</span></div>
        </div>
      </div>
    </div>
  </div>`;
}
