// یارنامه — تنظیمات (سازمان + هوش مصنوعی + رویدادها)
import { api, toast, esc } from '../api.js';
import { icon } from '../icons.js';
import { toFa } from '../jalali.js';

export async function render(root) {
  const [org, ai, logs] = await Promise.all([
    api.get('/api/organization'), api.get('/api/ai/status'), api.get('/api/audit?limit=50'),
  ]);

  root.innerHTML = `<div class="grid-main-aside">
    <div class="col">
      <div class="card">
        <div class="card-head"><h3>${icon('building', 17)} اطلاعات سازمان (سربرگ نامه‌ها)</h3></div>
        <div class="card-pad">
          <div class="form-grid">
            <div><label class="label">نام سازمان / شرکت <span class="req">*</span></label>
              <input class="input" id="o-name" value="${esc(org.name || '')}"></div>
            <div><label class="label">شکل حقوقی</label>
              <input class="input" id="o-legal" value="${esc(org.legal_form || '')}" placeholder="شرکت سهامی خاص و …"></div>
            <div><label class="label">شناسه ملی</label>
              <input class="input" id="o-national" value="${esc(org.national_id || '')}" inputmode="numeric"></div>
            <div><label class="label">شماره ثبت</label>
              <input class="input" id="o-reg" value="${esc(org.registration_no || '')}"></div>
            <div><label class="label">شماره اقتصادی</label>
              <input class="input" id="o-economic" value="${esc(org.economic_code || '')}"></div>
            <div><label class="label">تلفن</label>
              <input class="input" id="o-phone" value="${esc(org.phone || '')}"></div>
            <div><label class="label">ایمیل</label>
              <input class="input" id="o-email" value="${esc(org.email || '')}" dir="ltr"></div>
            <div><label class="label">وب‌سایت</label>
              <input class="input" id="o-web" value="${esc(org.website || '')}" dir="ltr"></div>
            <div class="full"><label class="label">نشانی</label>
              <textarea class="textarea" id="o-address" style="min-height:60px">${esc(org.address || '')}</textarea></div>
            <div><label class="label">کد پستی</label>
              <input class="input" id="o-postal" value="${esc(org.postal_code || '')}" inputmode="numeric"></div>
            <div><label class="label">لوگوی سازمان</label>
              <div class="row" style="gap:8px">
                <input class="input" id="o-logo" value="${esc(org.logo_path || '')}" disabled placeholder="فایل انتخاب نشده" style="flex:1">
                <button class="btn btn-ghost btn-sm" id="o-logo-btn">${icon('upload', 13)}</button>
                ${org.logo_path ? `<img src="/api/media/${org.logo_path.replace('files/', '')}" style="height:36px">` : ''}
              </div></div>
            <div><label class="label">مهر سازمانی</label>
              <div class="row" style="gap:8px">
                <input class="input" id="o-stamp" value="${esc(org.stamp_path || '')}" disabled placeholder="فایل انتخاب نشده" style="flex:1">
                <button class="btn btn-ghost btn-sm" id="o-stamp-btn">${icon('upload', 13)}</button>
                ${org.stamp_path ? `<img src="/api/media/${org.stamp_path.replace('files/', '')}" style="height:38px">` : ''}
              </div></div>
          </div>
          <div class="mt-2"><button class="btn btn-primary" id="o-save">${icon('save', 15)} ذخیره اطلاعات سازمان</button></div>
        </div>
      </div>
      <div class="card">
        <div class="card-head"><h3>${icon('clock', 16)} آخرین رویدادها</h3></div>
        <div class="card-pad" style="padding-top:6px;max-height:300px;overflow:auto">
          ${logs.map(l => `<div class="row-between" style="padding:6px 0;border-bottom:1px solid var(--line)">
            <span class="small">${esc(actionLabel(l.action))}</span>
            <span class="small muted">${toFa((l.created_at || '').slice(0, 16).replace('T', ' '))}</span></div>`).join('') || '<div class="small muted">رویدادی ثبت نشده</div>'}
        </div>
      </div>
    </div>
    <div class="col">
      <div class="card">
        <div class="card-head"><h3>${icon('ai', 17)} هوش مصنوعی (GLM)</h3>
          ${ai.enabled ? '<span class="badge badge-final">فعال</span>' : '<span class="badge badge-muted">تنظیم نشده</span>'}</div>
        <div class="card-pad">
          <div class="col" style="gap:12px">
            <div><label class="label">کلید API</label>
              <input class="input" id="ai-key" type="password" placeholder="${ai.enabled ? '•••••••• (برای تغییر پر کنید)' : 'کلید GLM را وارد کنید'}" dir="ltr"></div>
            <div><label class="label">مدل</label>
              <input class="input" id="ai-model" value="${esc(ai.model || 'glm-4-flash')}" dir="ltr"></div>
            <div><label class="label">نشانی سرویس</label>
              <input class="input" id="ai-endpoint" value="${esc(ai.endpoint || 'https://open.bigmodel.cn/api/paas/v4/chat/completions')}" dir="ltr"></div>
            <button class="btn btn-primary" id="ai-save">ذخیره تنظیمات AI</button>
            <div class="help">کلید فقط در دیتابیس محلی ذخیره و هرگز به مرورگر ارسال نمی‌شود. در نبود اینترنت یا کلید، سایر بخش‌های برنامه عادی کار می‌کنند.</div>
          </div>
        </div>
      </div>
      <div class="card card-pad" style="background:var(--card-2)">
        <h4 style="font-size:13px;margin-bottom:8px">محل ذخیره داده‌ها</h4>
        <div class="small muted" id="data-dir">—</div>
        <div class="help mt-1">دیتابیس، تصاویر و پشتیبان‌ها خارج از پوشه نصب برنامه نگهداری می‌شوند و با به‌روزرسانی حذف نمی‌شوند.</div>
      </div>
    </div>
  </div>`;

  api.get('/api/health').then(h => { root.querySelector('#data-dir').textContent = h.data_dir; });

  root.querySelector('#o-save').onclick = async () => {
    try {
      await api.put('/api/organization', {
        name: root.querySelector('#o-name').value.trim(),
        legal_form: root.querySelector('#o-legal').value,
        national_id: root.querySelector('#o-national').value.trim(),
        economic_code: root.querySelector('#o-economic').value.trim(),
        registration_no: root.querySelector('#o-reg').value,
        address: root.querySelector('#o-address').value,
        postal_code: root.querySelector('#o-postal').value.trim(),
        phone: root.querySelector('#o-phone').value.trim(),
        email: root.querySelector('#o-email').value.trim(),
        website: root.querySelector('#o-web').value.trim(),
        logo_path: root.querySelector('#o-logo').value,
        stamp_path: root.querySelector('#o-stamp').value,
      });
      toast('اطلاعات سازمان ذخیره شد');
    } catch (err) { toast(err.message, 'error', 6000); }
  };

  async function pickImage(kind, pathInput) {
    const inp = document.createElement('input');
    inp.type = 'file'; inp.accept = 'image/png,image/jpeg';
    inp.onchange = async () => {
      const fd = new FormData(); fd.append('file', inp.files[0]);
      try {
        const r = await api.upload(`/api/uploads?kind=${kind}`, fd);
        pathInput.value = r.stored_path;
        toast('تصویر آپلود شد — برای اعمال، ذخیره کنید');
      } catch (err) { toast(err.message, 'error'); }
    };
    inp.click();
  }
  root.querySelector('#o-logo-btn').onclick = () => pickImage('logo', root.querySelector('#o-logo'));
  root.querySelector('#o-stamp-btn').onclick = () => pickImage('stamp', root.querySelector('#o-stamp'));

  root.querySelector('#ai-save').onclick = async () => {
    try {
      const r = await api.put('/api/ai/config', {
        api_key: root.querySelector('#ai-key').value.trim(),
        model: root.querySelector('#ai-model').value.trim(),
        endpoint: root.querySelector('#ai-endpoint').value.trim(),
      });
      toast(r.enabled ? 'هوش مصنوعی فعال شد' : 'تنظیمات ذخیره شد (کلید خالی است)');
      setTimeout(() => location.reload(), 800);
    } catch (err) { toast(err.message, 'error'); }
  };
}

function actionLabel(a) {
  return {
    'letter.create': 'ایجاد نامه', 'letter.finalize': 'ثبت نهایی نامه', 'letter.cancel': 'ابطال نامه',
    'letter.regenerate': 'بازتولید متن نامه', 'letter.copy': 'کپی نامه',
    'contact.create': 'ثبت مخاطب', 'contact.update': 'ویرایش مخاطب', 'contact.delete': 'حذف مخاطب',
    'template.create': 'ایجاد الگو', 'template.update': 'ویرایش الگو', 'template.delete': 'حذف الگو', 'template.duplicate': 'کپی الگو',
    'org.update': 'ویرایش اطلاعات سازمان', 'backup.create': 'تهیه نسخه پشتیبان', 'backup.restore': 'بازیابی پشتیبان',
    'ai.config': 'تنظیم هوش مصنوعی', 'ai.draft': 'تولید متن با AI',
    'signatory.create': 'ثبت امضاکننده', 'signatory.update': 'ویرایش امضاکننده', 'signatory.delete': 'حذف امضاکننده', 'signatory.image': 'آپلود تصویر امضا/مهر',
  }[a] || a;
}
