// یارنامه — نمایش جزئیات نامه + نسخه‌ها
import { api, toast, confirmDialog, esc, statusBadge, openModal, closeModal } from '../api.js';
import { icon } from '../icons.js';
import { toFa, formatJalaliStr } from '../jalali.js';
import { renderSheetHtml } from '../sheet.js';

export async function render(root, { params }) {
  const id = +params.get('id');
  let l;
  try { l = await api.get(`/api/letters/${id}`); }
  catch { root.innerHTML = '<div class="card card-pad">نامه یافت نشد</div>'; return; }

  root.innerHTML = `
  <div class="row-between mb-2">
    <div class="row">
      <button class="btn btn-ghost btn-sm" onclick="location.hash='#/archive'">${icon('chevronR', 14)} بایگانی</button>
      ${statusBadge(l.status)}
    </div>
    <div class="row">
      ${l.status === 'draft' ? `<button class="btn btn-primary" id="lv-edit">${icon('edit', 15)} ادامه ویرایش</button>` : ''}
      <button class="btn btn-ghost" id="lv-print">${icon('print', 15)} چاپ / PDF</button>
      <button class="btn btn-ghost" id="lv-copy">${icon('copy', 15)} نامه جدید از روی این</button>
      ${l.status === 'final' ? `<button class="btn btn-danger" id="lv-cancel">${icon('ban', 15)} ابطال</button>` : ''}
    </div>
  </div>
  <div class="grid-main-aside">
    <div class="card">
      <div class="card-head"><h3>${esc(l.subject) || 'بدون موضوع'}</h3>
        <span class="chip">${l.letter_number ? 'شماره: <b>' + toFa(l.letter_number) + '</b>' : 'بدون شماره (پیش‌نویس)'}</span></div>
      <div class="card-pad">
        <div class="paper-wrap" id="sheet-host"></div>
      </div>
    </div>
    <div class="col">
      <div class="card card-pad">
        <h4 style="font-size:13px;margin-bottom:10px">مشخصات</h4>
        <div class="col small" style="gap:8px">
          ${row('الگوی مبنا', esc(l.template_title_snapshot || '—'))}
          ${row('مخاطب', esc(l.contact_name || l.contact_snapshot?.name || '—'))}
          ${row('تاریخ صدور', l.issued_date_jalali ? formatJalaliStr(l.issued_date_jalali) : '—')}
          ${row('اندازه کاغذ', l.paper_size + (l.orientation === 'landscape' ? ' افقی' : ' عمودی'))}
          ${row('آخرین ویرایش', toFa(l.updated_at?.slice(0, 16).replace('T', ' ')))}
          ${l.status === 'canceled' ? row('علت ابطال', esc(l.cancel_reason || '—')) : ''}
        </div>
      </div>
      ${l.signatories?.length ? `<div class="card card-pad">
        <h4 style="font-size:13px;margin-bottom:10px">امضاکنندگان</h4>
        ${l.signatories.map(s => `<div class="row" style="padding:6px 0;border-bottom:1px solid var(--line)">
          <div class="avatar">${esc(s.snapshot_name.slice(0, 2))}</div>
          <div class="small"><b>${esc(s.snapshot_name)}</b><br><span class="muted">${esc(s.snapshot_position)}</span></div>
        </div>`).join('')}
      </div>` : ''}
      <div class="card">
        <div class="card-head"><h3 style="font-size:13px">${icon('clock', 14)} نسخه‌ها (${toFa(l.versions.length)})</h3></div>
        <div class="card-pad" style="padding-top:8px">
          ${l.versions.map(v => `<div class="row-between" style="padding:7px 0;border-bottom:1px solid var(--line)">
            <div class="small"><b>نسخه ${toFa(v.version_no)}</b> — ${esc(v.note || '')}<br><span class="muted">${toFa(v.created_at?.slice(0, 16).replace('T', ' '))}</span></div>
            <button class="btn btn-ghost btn-sm" data-ver="${v.id}">${icon('eye', 13)}</button>
          </div>`).join('')}
        </div>
      </div>
    </div>
  </div>`;

  // نمایش سند
  const host = root.querySelector('#sheet-host');
  const org = await api.get('/api/organization');
  host.innerHTML = renderSheetHtml(l, org, { preview: l.status !== 'final' });

  root.querySelector('#lv-print').onclick = () => { location.hash = `#/letters/print?id=${l.id}`; };
  const editBtn = root.querySelector('#lv-edit');
  if (editBtn) editBtn.onclick = () => { location.hash = `#/letters/edit?id=${l.id}`; };
  root.querySelector('#lv-copy').onclick = async () => {
    const r = await api.post(`/api/letters/${l.id}/copy`);
    toast('پیش‌نویس جدید ساخته شد'); location.hash = `#/letters/edit?id=${r.id}`;
  };
  const cancelBtn = root.querySelector('#lv-cancel');
  if (cancelBtn) cancelBtn.onclick = async () => {
    const reason = prompt('علت ابطال نامه:');
    if (!reason || reason.trim().length < 3) return toast('علت ابطال الزامی است', 'warn');
    await api.post(`/api/letters/${l.id}/cancel`, { reason: reason.trim() });
    toast('نامه ابطال شد', 'warn'); render(root, { params });
  };
  root.querySelectorAll('[data-ver]').forEach(b => b.onclick = async () => {
    const v = await api.get(`/api/letters/${l.id}/versions/${b.dataset.ver}`);
    openModal({
      title: `نسخه ${toFa(v.version_no)} — ${esc(v.note || '')}`, size: 'modal-lg',
      body: `<div style="border:1px solid var(--line);border-radius:10px;padding:18px;font-size:14px;line-height:2.1;direction:rtl;text-align:right;max-height:60vh;overflow:auto">${v.body_html}</div>`,
      footer: `<button class="btn btn-ghost" id="ver-close">بستن</button>`,
    });
    document.getElementById('ver-close').onclick = closeModal;
  });

  function row(k, v) { return `<div class="row-between"><span class="muted">${k}</span><span class="b">${v}</span></div>`; }
}
