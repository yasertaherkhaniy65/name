// یارنامه — مدیریت مخاطبین
import { api, toast, openModal, closeModal, confirmDialog, esc, pagination, emptyState, debounce } from '../api.js';
import { icon } from '../icons.js';
import { toFa } from '../jalali.js';

const KINDS = [
  ['person', 'شخص'], ['company', 'شرکت'], ['bank', 'بانک'],
  ['government', 'اداره / نهاد دولتی'], ['organization', 'سازمان'], ['other', 'سایر'],
];
const kindLabel = k => (KINDS.find(x => x[0] === k) || ['', k])[1];

export async function render(root, { params }) {
  let page = 1, q = params.get('q') || '', kind = '', active = '';
  root.innerHTML = `<div class="col">
    <div class="card">
      <div class="card-head">
        <h3>${icon('contacts', 18)} فهرست مخاطبین</h3>
        <button class="btn btn-primary" id="btn-add">${icon('plus', 16)} مخاطب جدید</button>
      </div>
      <div class="card-pad" style="padding-bottom:10px">
        <div class="search-bar">
          <input class="input search-grow" id="f-q" placeholder="جست‌وجو: نام، شرکت، تلفن، کد…" value="${esc(q)}">
          <select class="select" id="f-kind"><option value="">همه انواع</option>
            ${KINDS.map(([v, t]) => `<option value="${v}">${t}</option>`).join('')}</select>
          <select class="select" id="f-active"><option value="">فعال و غیرفعال</option>
            <option value="1">فقط فعال</option><option value="0">فقط غیرفعال</option></select>
        </div>
      </div>
      <div id="list"></div>
      <div class="pager" id="pager"></div>
    </div>
  </div>`;

  const listEl = root.querySelector('#list'), pagerEl = root.querySelector('#pager');
  const fq = root.querySelector('#f-q'), fkind = root.querySelector('#f-kind'), factive = root.querySelector('#f-active');

  async function load() {
    listEl.innerHTML = '<div class="skeleton"></div>';
    const r = await api.get(`/api/contacts?q=${encodeURIComponent(q)}&kind=${kind}&active=${active}&page=${page}&page_size=25`);
    if (!r.items.length) {
      listEl.innerHTML = emptyState(q || kind ? 'موردی یافت نشد' : 'هنوز مخاطبی ثبت نشده است',
        'مخاطبین (اشخاص، شرکت‌ها، بانک‌ها، ادارات) را ثبت کنید تا هنگام صدور نامه با یک انتخاب در متن قرار گیرند.');
      pagerEl.innerHTML = '';
      return;
    }
    listEl.innerHTML = `<div class="table-wrap"><table class="tbl">
      <thead><tr><th>نام</th><th>نوع</th><th>سمت / شرکت</th><th>تلفن</th><th>وضعیت</th><th></th></tr></thead>
      <tbody>${r.items.map(c => `
        <tr>
          <td><div class="b">${esc(c.name)}</div>${c.customer_no ? `<div class="small muted">کد: ${esc(c.customer_no)}</div>` : ''}</td>
          <td><span class="badge badge-muted">${kindLabel(c.kind)}</span></td>
          <td class="small">${esc(c.company_name || c.position || '—')}</td>
          <td class="nowrap small">${toFa(c.phone || '—')}</td>
          <td>${c.is_active ? '<span class="badge badge-final">فعال</span>' : '<span class="badge badge-canceled">غیرفعال</span>'}</td>
          <td><div class="actions">
            <button class="btn btn-ghost btn-sm" data-view="${c.id}" title="جزئیات">${icon('eye', 14)}</button>
            <button class="btn btn-ghost btn-sm" data-edit="${c.id}" title="ویرایش">${icon('edit', 14)}</button>
            <button class="btn btn-danger btn-sm" data-del="${c.id}" data-name="${esc(c.name)}" title="حذف">${icon('trash', 14)}</button>
          </div></td>
        </tr>`).join('')}</tbody></table></div>`;
    pagination(pagerEl, r, p => { page = p; load(); });
    listEl.querySelectorAll('[data-edit]').forEach(b => b.onclick = () => editContact(+b.dataset.edit));
    listEl.querySelectorAll('[data-view]').forEach(b => b.onclick = () => viewContact(+b.dataset.view));
    listEl.querySelectorAll('[data-del]').forEach(b => b.onclick = () => delContact(+b.dataset.del, b.dataset.name));
  }

  fq.addEventListener('input', debounce(() => { q = fq.value; page = 1; load(); }, 350));
  fkind.onchange = () => { kind = fkind.value; page = 1; load(); };
  factive.onchange = () => { active = factive.value; page = 1; load(); };
  root.querySelector('#btn-add').onclick = () => editContact(null);

  async function delContact(id, name) {
    try {
      await api.del(`/api/contacts/${id}`);
      toast(`مخاطب «${name}» حذف شد`);
      load();
    } catch (err) {
      if (err.status === 409) {
        const ok = await confirmDialog('مخاطب استفاده‌شده',
          `${err.data?.detail?.message || 'این مخاطب در نامه‌ها استفاده شده است'}.<br>
           حذف مخاطب سابقه نامه‌ها را خراب نمی‌کند، اما برای حفظ سوابق پیشنهاد می‌شود فقط <b>غیرفعال</b> شود.`,
          'غیرفعال کردن مخاطب', true);
        if (ok) {
          const r = await api.del(`/api/contacts/${id}?force=1`);
          toast(r.message || 'مخاطب غیرفعال شد', 'warn');
          load();
        }
      } else toast(err.message, 'error');
    }
  }

  async function viewContact(id) {
    const c = await api.get(`/api/contacts/${id}`);
    openModal({
      title: 'جزئیات مخاطب',
      body: `<div class="form-grid">
        ${detail('نوع', kindLabel(c.kind))}${detail('نام', c.name)}
        ${detail('شرکت', c.company_name)}${detail('عنوان خطاب', c.salutation)}
        ${detail('سمت', c.position)}${detail('شناسه/کد ملی', c.national_id)}
        ${detail('شماره اقتصادی', c.economic_code)}${detail('شماره پرونده/مشتری', c.customer_no)}
        ${detail('تلفن', c.phone)}${detail('ایمیل', c.email)}
        ${detail('کد پستی', c.postal_code)}${detail('وضعیت', c.is_active ? 'فعال' : 'غیرفعال')}
        <div class="full">${detail('نشانی', c.address)}</div>
        ${c.notes ? `<div class="full">${detail('توضیحات', c.notes)}</div>` : ''}
      </div>`,
      footer: `<button class="btn btn-primary" id="md-edit">ویرایش</button><button class="btn btn-ghost" id="md-close">بستن</button>`,
    });
    document.getElementById('md-close').onclick = closeModal;
    document.getElementById('md-edit').onclick = () => { closeModal(); editContact(id); };
  }

  function detail(label, value) {
    return `<div><div class="label">${label}</div><div style="font-size:13px">${esc(value || '—')}</div></div>`;
  }

  async function editContact(id) {
    const c = id ? await api.get(`/api/contacts/${id}`) : {};
    const m = openModal({
      title: id ? 'ویرایش مخاطب' : 'ثبت مخاطب جدید', size: 'modal-lg',
      body: `<div class="form-grid">
        <div><label class="label">نوع مخاطب <span class="req">*</span></label>
          <select class="select" id="c-kind">${KINDS.map(([v, t]) => `<option value="${v}" ${c.kind === v ? 'selected' : ''}>${t}</option>`).join('')}</select></div>
        <div><label class="label">نام شخص یا سازمان <span class="req">*</span></label>
          <input class="input" id="c-name" value="${esc(c.name || '')}" placeholder="مثال: بانک ملت — شعبه ولیعصر"></div>
        <div><label class="label">نام شرکت</label><input class="input" id="c-company" value="${esc(c.company_name || '')}"></div>
        <div><label class="label">عنوان خطاب</label><input class="input" id="c-salutation" value="${esc(c.salutation || '')}" placeholder="مثال: جناب آقای دکتر"></div>
        <div><label class="label">سمت</label><input class="input" id="c-position" value="${esc(c.position || '')}"></div>
        <div><label class="label">شناسه ملی / کد ملی</label><input class="input" id="c-national" value="${esc(c.national_id || '')}" inputmode="numeric"></div>
        <div><label class="label">شماره اقتصادی</label><input class="input" id="c-economic" value="${esc(c.economic_code || '')}" inputmode="numeric"></div>
        <div><label class="label">شماره پرونده / مشتری</label><input class="input" id="c-customer" value="${esc(c.customer_no || '')}"></div>
        <div><label class="label">تلفن</label><input class="input" id="c-phone" value="${esc(c.phone || '')}" inputmode="tel"></div>
        <div><label class="label">ایمیل</label><input class="input" id="c-email" value="${esc(c.email || '')}" dir="ltr"></div>
        <div class="full"><label class="label">نشانی</label><textarea class="textarea" id="c-address" style="min-height:64px">${esc(c.address || '')}</textarea></div>
        <div><label class="label">کد پستی</label><input class="input" id="c-postal" value="${esc(c.postal_code || '')}" inputmode="numeric"></div>
        <div><label class="label">وضعیت</label>
          <label class="row" style="gap:10px;padding:8px 0"><span class="toggle">
            <input type="checkbox" id="c-active" ${c.is_active !== false ? 'checked' : ''}><span class="track"></span><span class="thumb"></span></span>
            <span class="small">مخاطب فعال باشد</span></label></div>
        <div class="full"><label class="label">توضیحات</label><input class="input" id="c-notes" value="${esc(c.notes || '')}"></div>
      </div>
      <div id="dup-warn" class="mt-2" style="display:none"></div>`,
      footer: `<button class="btn btn-primary" id="c-save">${icon('check', 15)} ذخیره مخاطب</button>
               <button class="btn btn-ghost" id="c-cancel">انصراف</button>`,
    });
    let confirmedDup = false;
    const nameInput = m.querySelector('#c-name');
    nameInput.addEventListener('blur', async () => {
      const n = nameInput.value.trim();
      if (n.length < 3) return;
      const r = await api.get(`/api/contacts/similar?name=${encodeURIComponent(n)}&exclude_id=${id || 0}`);
      const warn = m.querySelector('#dup-warn');
      if (r.items.length) {
        warn.style.display = '';
        warn.innerHTML = `<div class="form-section" style="border-color:var(--warning);background:var(--warning-soft)">
          <h4 style="color:var(--warning)">${icon('alert', 15)} هشدار مخاطب مشابه</h4>
          <div class="small">${r.items.map(x => `«${esc(x.name)}»`).join('، ')} از قبل ثبت شده است. در صورت اطمینان از تکراری نبودن، ادامه دهید.</div></div>`;
      } else warn.style.display = 'none';
    });
    m.querySelector('#c-cancel').onclick = m.closeModal;
    m.querySelector('#c-save').onclick = async () => {
      const payload = {
        kind: m.querySelector('#c-kind').value,
        name: nameInput.value.trim(),
        company_name: m.querySelector('#c-company').value,
        salutation: m.querySelector('#c-salutation').value,
        position: m.querySelector('#c-position').value,
        national_id: m.querySelector('#c-national').value.trim(),
        economic_code: m.querySelector('#c-economic').value.trim(),
        customer_no: m.querySelector('#c-customer').value.trim(),
        phone: m.querySelector('#c-phone').value.trim(),
        email: m.querySelector('#c-email').value.trim(),
        address: m.querySelector('#c-address').value,
        postal_code: m.querySelector('#c-postal').value.trim(),
        notes: m.querySelector('#c-notes').value,
        is_active: m.querySelector('#c-active').checked,
      };
      if (payload.name.length < 2) return toast('نام مخاطب الزامی است', 'warn');
      try {
        if (id) { await api.put(`/api/contacts/${id}`, payload); toast('مخاطب ویرایش شد'); }
        else { await api.post('/api/contacts', payload); toast('مخاطب ثبت شد'); }
        m.closeModal(); load();
      } catch (err) { toast(err.message, 'error', 5000); }
    };
  }
}
