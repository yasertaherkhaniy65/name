// یارنامه — امضاکنندگان و مهرها
import { api, toast, openModal, closeModal, confirmDialog, esc, emptyState } from '../api.js';
import { icon } from '../icons.js';
import { toFa } from '../jalali.js';

export async function render(root) {
  root.innerHTML = `<div class="col">
    <div class="card">
      <div class="card-head">
        <div><h3>${icon('stamp', 18)} امضاکنندگان و مهرها</h3>
          <div class="small muted">تصاویر امضا و مهر در محل امن دیتا ذخیره می‌شوند و جایگزین امضای دیجیتال معتبر نیستند.</div></div>
        <button class="btn btn-primary" id="btn-add">${icon('plus', 16)} امضاکننده جدید</button>
      </div>
      <div id="list"></div>
    </div>
  </div>`;

  const listEl = root.querySelector('#list');
  root.querySelector('#btn-add').onclick = () => editOne(null);

  async function load() {
    const items = await api.get('/api/signatories');
    if (!items.length) {
      listEl.innerHTML = emptyState('امضاکننده‌ای ثبت نشده است',
        'نام، سمت و تصویر امضای هر امضاکننده را ثبت کنید تا هنگام صدور نامه به‌صورت خودکار در متن و صفحه چاپ درج شود.');
      return;
    }
    listEl.innerHTML = `<div class="table-wrap"><table class="tbl">
      <thead><tr><th>نام</th><th>سمت</th><th>واحد</th><th>امضا</th><th>مهر</th><th>وضعیت</th><th></th></tr></thead>
      <tbody>${items.map(s => `
        <tr>
          <td class="b">${esc(s.full_name)}</td>
          <td>${esc(s.position)}</td>
          <td class="small">${esc(s.unit || '—')}</td>
          <td>${s.signature_image_path ? `<img src="/api/media/${s.signature_image_path.replace('files/', '')}" style="height:26px;filter:contrast(1.05)">` : '<span class="muted small">—</span>'}</td>
          <td>${s.stamp_image_path ? `<img src="/api/media/${s.stamp_image_path.replace('files/', '')}" style="height:30px">` : '<span class="muted small">—</span>'}</td>
          <td>${s.is_active ? '<span class="badge badge-final">فعال</span>' : '<span class="badge badge-canceled">غیرفعال</span>'}</td>
          <td><div class="actions">
            <button class="btn btn-ghost btn-sm" data-edit="${s.id}">${icon('edit', 14)} ویرایش</button>
            <button class="btn btn-danger btn-sm" data-del="${s.id}">${icon('trash', 14)}</button>
          </div></td>
        </tr>`).join('')}</tbody></table></div>`;
    listEl.querySelectorAll('[data-edit]').forEach(b => b.onclick = () => editOne(+b.dataset.edit));
    listEl.querySelectorAll('[data-del]').forEach(b => b.onclick = async () => {
      if (await confirmDialog('حذف امضاکننده', 'این امضاکننده حذف شود؟ در نامه‌های قبلی، امضای ثبت‌شده حفظ می‌شود.', 'حذف', true)) {
        await api.del(`/api/signatories/${b.dataset.del}`);
        toast('امضاکننده حذف شد'); load();
      }
    });
  }

  async function editOne(id) {
    const data = id ? (await api.get('/api/signatories')).find(x => x.id === id) || {} : {};
    const m = openModal({
      title: id ? 'ویرایش امضاکننده' : 'ثبت امضاکننده جدید', size: 'modal-lg',
      body: `<div class="form-grid">
        <div><label class="label">نام و نام خانوادگی <span class="req">*</span></label>
          <input class="input" id="s-name" value="${esc(data.full_name || '')}"></div>
        <div><label class="label">سمت سازمانی <span class="req">*</span></label>
          <input class="input" id="s-pos" value="${esc(data.position || '')}" placeholder="مثال: مدیرعامل"></div>
        <div><label class="label">واحد سازمانی</label><input class="input" id="s-unit" value="${esc(data.unit || '')}"></div>
        <div><label class="label">ترتیب نمایش</label><input class="input" id="s-order" type="number" value="${data.sort_order ?? 0}"></div>
        <div><label class="label">تصویر امضا</label>
          <div class="row" style="gap:8px">
            <input class="input" id="s-sig-path" value="${esc(data.signature_image_path || '')}" disabled placeholder="فایل انتخاب نشده" style="flex:1">
            <button class="btn btn-ghost btn-sm" id="s-sig-btn">${icon('upload', 14)} انتخاب</button>
            <div id="s-sig-prev">${data.signature_image_path ? `<img src="/api/media/${data.signature_image_path.replace('files/', '')}" style="height:34px">` : ''}</div>
          </div></div>
        <div><label class="label">تصویر مهر (اختیاری)</label>
          <div class="row" style="gap:8px">
            <input class="input" id="s-stamp-path" value="${esc(data.stamp_image_path || '')}" disabled placeholder="فایل انتخاب نشده" style="flex:1">
            <button class="btn btn-ghost btn-sm" id="s-stamp-btn">${icon('upload', 14)} انتخاب</button>
            <div id="s-stamp-prev">${data.stamp_image_path ? `<img src="/api/media/${data.stamp_image_path.replace('files/', '')}" style="height:38px">` : ''}</div>
          </div></div>
        <div><label class="label">وضعیت</label>
          <label class="row" style="gap:10px;padding:8px 0"><span class="toggle">
            <input type="checkbox" id="s-active" ${data.is_active !== false ? 'checked' : ''}><span class="track"></span><span class="thumb"></span></span>
            <span class="small">فعال</span></label></div>
        <div class="full"><label class="label">توضیحات</label><input class="input" id="s-notes" value="${esc(data.notes || '')}"></div>
      </div>`,
      footer: `<button class="btn btn-primary" id="s-save">${icon('check', 15)} ذخیره</button>
               <button class="btn btn-ghost" id="s-cancel">انصراف</button>`,
    });
    let sigPath = data.signature_image_path || '', stampPath = data.stamp_image_path || '';

    async function uploadImage(kind, pathInput, prevEl) {
      const inp = document.createElement('input');
      inp.type = 'file'; inp.accept = 'image/png,image/jpeg';
      inp.onchange = async () => {
        const fd = new FormData(); fd.append('file', inp.files[0]);
        try {
          const r = await api.upload(`/api/signatories/${id || 0}/image?kind=${kind}`, fd);
          if (kind === 'signature') sigPath = r.path; else stampPath = r.path;
          pathInput.value = r.path;
          prevEl.innerHTML = `<img src="${r.url}" style="height:36px">`;
          toast('تصویر آپلود شد');
          if (!id) toast('پس از ذخیره امضاکننده، تصویر به آن متصل می‌شود', 'info');
        } catch (err) { toast(err.message, 'error'); }
      };
      inp.click();
    }
    m.querySelector('#s-sig-btn').onclick = () => uploadImage('signature', m.querySelector('#s-sig-path'), m.querySelector('#s-sig-prev'));
    m.querySelector('#s-stamp-btn').onclick = () => uploadImage('stamp', m.querySelector('#s-stamp-path'), m.querySelector('#s-stamp-prev'));
    m.querySelector('#s-cancel').onclick = m.closeModal;
    m.querySelector('#s-save').onclick = async () => {
      const payload = {
        full_name: m.querySelector('#s-name').value.trim(),
        position: m.querySelector('#s-pos').value.trim(),
        unit: m.querySelector('#s-unit').value.trim(),
        sort_order: +m.querySelector('#s-order').value || 0,
        signature_image_path: sigPath, stamp_image_path: stampPath,
        is_active: m.querySelector('#s-active').checked,
        notes: m.querySelector('#s-notes').value,
      };
      if (!payload.full_name || !payload.position) return toast('نام و سمت امضاکننده الزامی است', 'warn');
      try {
        if (id) await api.put(`/api/signatories/${id}`, payload);
        else await api.post('/api/signatories', payload);
        toast('ذخیره شد'); m.closeModal(); load();
      } catch (err) { toast(err.message, 'error', 5000); }
    };
  }
  await load();
}
