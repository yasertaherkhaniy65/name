// یارنامه — طراح الگو: متن نامه + تعریف پارامترهای اختصاصی
import { api, toast, esc } from '../api.js';
import { icon } from '../icons.js';
import { createEditor } from '../editor.js';

const TYPES = [
  ['text', 'متن کوتاه'], ['textarea', 'متن چندخطی'], ['number', 'عدد'], ['amount', 'مبلغ'],
  ['jalali_date', 'تاریخ شمسی'], ['select', 'فهرست انتخابی'], ['multiselect', 'فهرست چندانتخابی'],
  ['contact', 'انتخاب مخاطب'], ['signatory', 'انتخاب امضاکننده'], ['org', 'انتخاب سازمان'],
  ['id_no', 'شماره و شناسه'], ['bool', 'بله یا خیر'], ['phone', 'تلفن و اطلاعات تماس'],
  ['attachments_list', 'فهرست پیوست‌ها'], ['notes', 'توضیحات تکمیلی'],
];

export async function render(root, { params }) {
  const id = params.get('id') ? +params.get('id') : null;
  const t = id ? await api.get(`/api/templates/${id}`) : {
    title: '', category: 'اداری و تجاری', description: '', body_html: '<p>با سلام و احترام؛</p>\n<p></p>',
    paper_size: 'A4', orientation: 'portrait', margin_preset: 'normal',
    default_signatory_id: 0, is_active: true, fields: [],
  };
  let fields = (t.fields || []).map(f => ({ ...f, is_required: !!f.is_required }));

  root.innerHTML = `
  <div class="row-between mb-2">
    <div><div style="font-size:16px;font-weight:700">${id ? 'ویرایش الگو' : 'طراحی الگوی جدید'}</div>
      <div class="small muted">پارامترهای هر الگو مستقل است؛ در متن با قالب <code>{{نام_سیستمی}}</code> استفاده می‌شوند.</div></div>
    <div class="row">
      <button class="btn btn-ghost" id="t-cancel">انصراف</button>
      <button class="btn btn-primary" id="t-save">${icon('save', 16)} ذخیره الگو</button>
    </div>
  </div>
  <div class="grid-main-aside">
    <div class="col">
      <div class="card card-pad">
        <div class="form-grid">
          <div><label class="label">عنوان الگو <span class="req">*</span></label>
            <input class="input" id="t-title" value="${esc(t.title)}" placeholder="مثال: درخواست گواهی بانکی"></div>
          <div><label class="label">دسته‌بندی</label>
            <input class="input" id="t-cat" value="${esc(t.category)}" list="cat-list">
            <datalist id="cat-list">
              <option>بانکی و مالی</option><option>منابع انسانی</option>
              <option>مالیاتی و حسابداری</option><option>اداری و تجاری</option>
            </datalist></div>
          <div class="full"><label class="label">توضیحات</label>
            <input class="input" id="t-desc" value="${esc(t.description || '')}"></div>
        </div>
      </div>
      <div class="card">
        <div class="card-head"><h3>متن اولیه نامه</h3>
          <span class="hint">از پارامترها در متن استفاده کنید — مثال: <code>{{company_name}}</code></span></div>
        <div class="card-pad" id="body-editor"></div>
      </div>
      <div class="card">
        <div class="card-head">
          <h3>پارامترهای اختصاصی الگو (${toFa(fields.length)})</h3>
          <button class="btn btn-soft btn-sm" id="f-add">${icon('plus', 14)} پارامتر جدید</button>
        </div>
        <div id="fields-list" class="card-pad" style="padding-top:8px"></div>
      </div>
    </div>
    <div class="col">
      <div class="card card-pad">
        <h4 style="margin-bottom:12px;font-size:13.5px">تنظیمات چاپ</h4>
        <div class="col" style="gap:12px">
          <div><label class="label">اندازه کاغذ پیش‌فرض</label>
            <select class="select" id="t-paper"><option value="A4" ${t.paper_size === 'A4' ? 'selected' : ''}>A4</option>
              <option value="A5" ${t.paper_size === 'A5' ? 'selected' : ''}>A5</option></select></div>
          <div><label class="label">جهت کاغذ</label>
            <select class="select" id="t-orient"><option value="portrait" ${t.orientation !== 'landscape' ? 'selected' : ''}>عمودی</option>
              <option value="landscape" ${t.orientation === 'landscape' ? 'selected' : ''}>افقی</option></select></div>
          <div><label class="label">حاشیه</label>
            <select class="select" id="t-margin">
              <option value="normal" ${t.margin_preset === 'normal' ? 'selected' : ''}>عادی (۱۸ میلی‌متر)</option>
              <option value="narrow" ${t.margin_preset === 'narrow' ? 'selected' : ''}>کم (۱۲ میلی‌متر)</option>
              <option value="wide" ${t.margin_preset === 'wide' ? 'selected' : ''}>زیاد (۲۵ میلی‌متر)</option></select></div>
          <div><label class="label">امضاکننده پیش‌فرض</label>
            <select class="select" id="t-sig"><option value="0">— بدون پیش‌فرض —</option></select></div>
          <label class="row" style="gap:10px"><span class="toggle">
            <input type="checkbox" id="t-active" ${t.is_active !== false ? 'checked' : ''}><span class="track"></span><span class="thumb"></span></span>
            <span class="small">الگوی فعال</span></label>
        </div>
      </div>
      <div class="card card-pad" style="background:var(--card-2)">
        <h4 style="margin-bottom:10px;font-size:13px">${icon('info', 15)} راهنما</h4>
        <ul class="small muted" style="padding-right:16px;line-height:2.2">
          <li>نام سیستمی فقط حروف کوچک لاتین، عدد و _</li>
          <li>فیلد «مخاطب» متغیرهای وابسته تولید می‌کند: <code>{{key_address}}</code>، <code>{{key_phone}}</code> و …</li>
          <li>حذف یا تغییر الگو هرگز نامه‌های صادرشده را تغییر نمی‌دهد</li>
        </ul>
      </div>
    </div>
  </div>`;

  const editor = createEditor(document.getElementById('body-editor'), {
    initialHtml: t.body_html,
    onChange: () => { /* ذخیره هنگام ثبت کل */ },
  });

  // امضاکنندگان
  const sigs = await api.get('/api/signatories?active=1');
  const sigSel = root.querySelector('#t-sig');
  sigSel.innerHTML += sigs.map(s => `<option value="${s.id}" ${t.default_signatory_id === s.id ? 'selected' : ''}>${esc(s.full_name)} — ${esc(s.position)}</option>`).join('');

  // ---------- فیلدها ----------
  function renderFields() {
    const el = root.querySelector('#fields-list');
    if (!fields.length) {
      el.innerHTML = `<div class="small muted" style="padding:10px 0">هنوز پارامتری تعریف نشده است. پارامترها فیلدهای فرم هنگام صدور نامه را می‌سازند.</div>`;
      return;
    }
    el.innerHTML = fields.map((f, i) => `
      <div class="form-section" style="margin-bottom:10px">
        <div class="row" style="gap:8px;flex-wrap:wrap">
          <input class="input f-label" data-i="${i}" value="${esc(f.label)}" placeholder="عنوان نمایشی" style="flex:2;min-width:150px">
          <input class="input f-key" data-i="${i}" value="${esc(f.field_key)}" placeholder="نام_سیستمی" dir="ltr" style="flex:1.4;min-width:130px" ${f.id ? 'disabled' : ''}>
          <select class="select f-type" data-i="${i}" style="width:150px">
            ${TYPES.map(([v, l]) => `<option value="${v}" ${f.field_type === v ? 'selected' : ''}>${l}</option>`).join('')}</select>
          <label class="row small" style="gap:5px;white-space:nowrap" title="الزامی"><input type="checkbox" class="f-req" data-i="${i}" ${f.is_required ? 'checked' : ''}> الزامی</label>
          <button class="btn btn-ghost btn-sm f-up" data-i="${i}" title="بالا">↑</button>
          <button class="btn btn-ghost btn-sm f-down" data-i="${i}" title="پایین">↓</button>
          <button class="btn btn-danger btn-sm f-del" data-i="${i}" title="حذف">${icon('trash', 13)}</button>
        </div>
        <div class="row mt-1" style="gap:8px;flex-wrap:wrap">
          <input class="input f-group" data-i="${i}" value="${esc(f.group_name || '')}" placeholder="گروه‌بندی" style="width:150px">
          <input class="input f-default" data-i="${i}" value="${esc(f.default_value || '')}" placeholder="مقدار پیش‌فرض" style="width:170px">
          <input class="input f-help" data-i="${i}" value="${esc(f.help_text || '')}" placeholder="متن راهنما" style="flex:1;min-width:180px">
        </div>
        ${(f.field_type === 'select' || f.field_type === 'multiselect') ? `
        <div class="mt-1"><label class="label small">گزینه‌ها (هر سطر یک گزینه)</label>
          <textarea class="textarea f-options" data-i="${i}" style="min-height:56px">${esc((f.options || []).join('\n'))}</textarea></div>` : ''}
        ${f.field_type === 'contact' || f.field_type === 'signatory' ? `
          <div class="help mt-1">${icon('info', 12)} ورود دستی هم فعال خواهد بود؛ متغیرهای وابسته در دسترس‌اند.</div>` : ''}
      </div>`).join('');

    el.querySelectorAll('.f-label,.f-key,.f-type,.f-group,.f-default,.f-help,.f-options').forEach(inp => {
      inp.addEventListener('change', () => {
        const i = +inp.dataset.i, f = fields[i];
        if (inp.classList.contains('f-label')) f.label = inp.value;
        if (inp.classList.contains('f-key')) f.field_key = inp.value.toLowerCase().replace(/[^a-z0-9_]/g, '_');
        if (inp.classList.contains('f-type')) { f.field_type = inp.value; renderFields(); }
        if (inp.classList.contains('f-group')) f.group_name = inp.value;
        if (inp.classList.contains('f-default')) f.default_value = inp.value;
        if (inp.classList.contains('f-help')) f.help_text = inp.value;
        if (inp.classList.contains('f-options')) f.options = inp.value.split('\n').map(x => x.trim()).filter(Boolean);
      });
    });
    el.querySelectorAll('.f-req').forEach(c => c.addEventListener('change', () => { fields[+c.dataset.i].is_required = c.checked; }));
    el.querySelectorAll('.f-del').forEach(b => b.onclick = () => { fields.splice(+b.dataset.i, 1); renderFields(); });
    el.querySelectorAll('.f-up,.f-down').forEach(b => b.onclick = () => {
      const i = +b.dataset.i, j = b.classList.contains('f-up') ? i - 1 : i + 1;
      if (j < 0 || j >= fields.length) return;
      [fields[i], fields[j]] = [fields[j], fields[i]]; renderFields();
    });
  }
  root.querySelector('#f-add').onclick = () => {
    fields.push({ field_key: `field_${fields.length + 1}`, label: '', field_type: 'text', is_required: false, options: [] });
    renderFields();
    root.querySelector('#fields-list').lastElementChild?.scrollIntoView({ behavior: 'smooth' });
  };
  renderFields();

  root.querySelector('#t-cancel').onclick = () => { location.hash = '#/templates'; };
  root.querySelector('#t-save').onclick = async () => {
    const payload = {
      title: root.querySelector('#t-title').value.trim(),
      category: root.querySelector('#t-cat').value.trim() || 'اداری و تجاری',
      description: root.querySelector('#t-desc').value,
      body_html: editor.getHtml(),
      paper_size: root.querySelector('#t-paper').value,
      orientation: root.querySelector('#t-orient').value,
      margin_preset: root.querySelector('#t-margin').value,
      default_signatory_id: +root.querySelector('#t-sig').value || null,
      is_active: root.querySelector('#t-active').checked,
      fields: fields.filter(f => f.label && f.field_key),
    };
    if (!payload.title) return toast('عنوان الگو الزامی است', 'warn');
    if (payload.fields.length && !/\{\{/.test(payload.body_html)) {
      const ok = confirm('در متن الگو هیچ متغیری ({{...}}) استفاده نشده است. ادامه می‌دهید؟');
      if (!ok) return;
    }
    try {
      if (id) await api.put(`/api/templates/${id}`, payload);
      else await api.post('/api/templates', payload);
      toast('الگو ذخیره شد');
      location.hash = '#/templates';
    } catch (err) { toast(err.message, 'error', 6000); }
  };
}
