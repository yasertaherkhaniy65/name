// یارنامه — جادوگر ایجاد نامه: الگو ← پارامترهای پویا ← ویرایش آزاد متن ← ثبت نهایی
import { api, toast, openModal, closeModal, confirmDialog, esc, amountInputValue, bindAmountInputs, debounce } from '../api.js';
import { icon } from '../icons.js';
import { toFa, todayJalali, formatJalali, jalaliInput, bindJalaliInput, parseJalaliStr } from '../jalali.js';
import { createEditor } from '../editor.js';
import { refreshDraftsBadge } from '../main.js';

const STEP_TITLES = ['انتخاب الگو', 'تکمیل پارامترها', 'ویرایش متن', 'ثبت و چاپ'];

export async function render(root, { params }) {
  const editId = params.get('id') ? +params.get('id') : null;
  const preTemplate = params.get('template') ? +params.get('template') : null;
  let step = 1;
  let template = null;          // الگوی انتخابی (با فیلدها)
  let paramsData = {};          // مقادیر پارامترها
  let bodyHtml = '';            // متن فعلی
  let letter = null;            // نامه ذخیره‌شده (پیش‌نویس)
  let subject = '', contactId = 0, signatoryIds = [];
  let generatedOnce = false, dirty = false;
  let paper = 'A4', orientation = 'portrait', margin = 'normal';
  let editor = null;

  root.innerHTML = `
    <div class="steps no-print" id="steps"></div>
    <div id="wizard-body"></div>`;

  const stepsEl = root.querySelector('#steps'), body = root.querySelector('#wizard-body');

  function renderSteps() {
    stepsEl.innerHTML = STEP_TITLES.map((t, i) => {
      const n = i + 1;
      const cls = n === step ? 'active' : n < step ? 'done' : '';
      return `<div class="step ${cls}"><span class="step-num">${n < step ? '✓' : toFa(n)}</span>
        <span class="step-title">${t}</span></div>${n < 4 ? `<span class="step-line ${n < step ? '' : ''}"></span>` : ''}`;
    }).join('');
  }

  // ================= مرحله ۱: انتخاب الگو =================
  async function step1() {
    step = 1; renderSteps();
    body.innerHTML = `<div class="col">
      <div class="search-bar mb-2">
        <input class="input search-grow" id="tpl-q" placeholder="جست‌وجوی الگو…">
        <select class="select" id="tpl-cat"><option value="">همه دسته‌ها</option></select>
      </div>
      <div id="tpl-grid" class="grid-3"></div>
    </div>`;
    const grid = body.querySelector('#tpl-grid'), qEl = body.querySelector('#tpl-q'), catEl = body.querySelector('#tpl-cat');
    const cats = await api.get('/api/templates/categories');
    catEl.innerHTML += cats.map(c => `<option>${esc(c)}</option>`).join('');

    async function load() {
      grid.innerHTML = '<div class="skeleton" style="grid-column:1/-1;min-height:200px"></div>';
      const items = await api.get(`/api/templates?q=${encodeURIComponent(qEl.value)}&category=${encodeURIComponent(catEl.value)}&active=1`);
      grid.innerHTML = items.length ? items.map(t => `
        <div class="card card-pad tpl-card" data-id="${t.id}" style="cursor:pointer;transition:all .15s">
          <div class="row-between">
            <div class="b" style="font-size:13.5px">${esc(t.title)}</div>
            <span class="badge badge-muted">${esc(t.category)}</span>
          </div>
          <div class="small muted" style="margin-top:6px;min-height:36px">${esc(t.description || '')}</div>
          <div class="row-between mt-1">
            <span class="chip">${icon('templates', 12)} ${toFa(t.field_count)} پارامتر</span>
            <span class="link small">انتخاب ${icon('chevronL', 13)}</span>
          </div>
        </div>`).join('')
        : `<div class="small muted">الگویی یافت نشد.</div>`;
      grid.querySelectorAll('.tpl-card').forEach(c => c.onclick = () => chooseTemplate(+c.dataset.id));
    }
    qEl.addEventListener('input', debounce(load, 300));
    catEl.onchange = load;
    await load();
    if (preTemplate) chooseTemplate(preTemplate);
  }

  async function chooseTemplate(tid) {
    template = await api.get(`/api/templates/${tid}`);
    if (letter && letter.template_id !== tid && letter.status === 'draft') {
      // تغییر الگو در پیش‌نویس موجود
      letter.template_id = tid; letter.template_title_snapshot = template.title;
    }
    paper = template.paper_size || 'A4'; orientation = template.orientation || 'portrait'; margin = template.margin_preset || 'normal';
    if (template.default_signatory_id) signatoryIds = [template.default_signatory_id];
    subject = template.title;
    step2();
  }

  // ================= مرحله ۲: فرم پویا از پارامترهای الگو =================
  function step2() {
    step = 2; renderSteps();
    const groups = {};
    (template.fields || []).forEach(f => { (f.group_name || 'اطلاعات نامه').split('').length && (groups[f.group_name || 'اطلاعات نامه'] = groups[f.group_name || 'اطلاعات نامه'] || []).push(f); });

    body.innerHTML = `
    <div class="card">
      <div class="card-head">
        <div><h3>${icon('templates', 17)} ${esc(template.title)}</h3>
          <div class="small muted">این فرم فقط از پارامترهای همین الگو ساخته شده است.</div></div>
        <button class="btn btn-ghost btn-sm" id="back-1">${icon('chevronR', 14)} تغییر الگو</button>
      </div>
      <div class="card-pad">
        <div class="form-grid mb-2">
          <div class="full"><label class="label">موضوع نامه <span class="req">*</span></label>
            <input class="input" id="w-subject" value="${esc(subject)}" placeholder="موضوع رسمی نامه"></div>
        </div>
        ${Object.entries(groups).map(([g, fs]) => `
          <div class="form-section"><h4>${esc(g)}</h4>
            <div class="form-grid">${fs.map(f => fieldHtml(f)).join('')}</div>
          </div>`).join('')}
        <div class="form-section"><h4>امضاکنندگان نامه</h4>
          <div id="sig-picker" class="row" style="gap:8px;flex-wrap:wrap"></div>
          <div class="help mt-1">امضاکنندگان انتخابی با نام، سمت، امضا و مهر در نامه درج می‌شوند.</div>
        </div>
      </div>
      <div class="modal-foot" style="border-radius:0">
        <button class="btn btn-primary" id="w-generate">${icon('sparkle', 16)} تولید متن نامه</button>
        ${aiStatus ? `<button class="btn btn-soft" id="w-ai-extract">${icon('ai', 15)} استخراج هوشمند از متن</button>` : ''}
      </div>
    </div>`;

    body.querySelector('#back-1').onclick = step1;
    bindFieldEvents(body, () => {
      // به‌روزرسانی وابستگان هنگام تغییر مخاطب
      updateDependents();
    });
    renderSigPicker();
    bindAmountInputs(body);
    bindJalaliInput(body);

    body.querySelector('#w-generate').onclick = generateAndEdit;
    if (aiStatus) body.querySelector('#w-ai-extract').onclick = aiExtract;
  }

  let aiStatus = false;
  api.get('/api/ai/status').then(s => { aiStatus = s.enabled; }).catch(() => {});

  function fieldHtml(f) {
    const v = paramsData[f.field_key] ?? f.default_value ?? '';
    const req = f.is_required ? '<span class="req">*</span>' : '';
    const help = f.help_text ? `<div class="help">${esc(f.help_text)}</div>` : '';
    switch (f.field_type) {
      case 'textarea': case 'notes': case 'attachments_list':
        return `<div><label class="label">${esc(f.label)} ${req}</label>
          <textarea class="textarea w-field" data-key="${f.field_key}" placeholder="${f.field_type === 'attachments_list' ? 'هر سطر یک پیوست' : ''}">${esc(v)}</textarea>${help}</div>`;
      case 'select':
        return `<div><label class="label">${esc(f.label)} ${req}</label>
          <select class="select w-field" data-key="${f.field_key}"><option value="">— انتخاب کنید —</option>
          ${(f.options || []).map(o => `<option ${v === o ? 'selected' : ''}>${esc(o)}</option>`).join('')}</select>${help}</div>`;
      case 'multiselect':
        return `<div><label class="label">${esc(f.label)} ${req}</label>
          <div class="w-field" data-key="${f.field_key}" data-multi="1" style="border:1.5px solid var(--line-strong);border-radius:10px;padding:8px 12px;max-height:130px;overflow:auto">
          ${(f.options || []).map(o => `<label class="row small" style="gap:6px;padding:2px 0"><input type="checkbox" value="${esc(o)}" ${(paramsData[f.field_key + '__multi'] || []).includes(o) ? 'checked' : ''}> ${esc(o)}</label>`).join('')}</div>${help}</div>`;
      case 'contact':
        return `<div><label class="label">${esc(f.label)} ${req}</label>
          <div class="row" style="gap:6px">
            <input class="input w-field" data-key="${f.field_key}" data-contact="1" value="${esc(contactName(v))}" readonly placeholder="انتخاب از مخاطبین" style="flex:1;cursor:pointer">
            <button type="button" class="btn btn-ghost btn-sm w-contact-pick" data-key="${f.field_key}">${icon('search', 14)}</button>
            <button type="button" class="btn btn-ghost btn-sm w-contact-manual" data-key="${f.field_key}" title="ورود دستی">✎</button>
          </div>
          <div class="w-contact-info small muted" data-key="${f.field_key}" style="margin-top:4px"></div>${help}</div>`;
      case 'signatory':
        return `<div><label class="label">${esc(f.label)} ${req}</label>
          <select class="select w-field" data-key="${f.field_key}"><option value="">— انتخاب —</option>
          ${window.__sigOptions.map(s => `<option value="${s.id}" ${+v === s.id ? 'selected' : ''}>${esc(s.full_name)} — ${esc(s.position)}</option>`).join('')}</select>${help}</div>`;
      case 'org':
        return `<div><label class="label">${esc(f.label)}</label>
          <input class="input" value="${esc(window.__orgName || 'سازمان پیش‌فرض (تنظیمات)')}" readonly>${help}</div>`;
      case 'amount':
        return `<div><label class="label">${esc(f.label)} ${req}</label>
          <input class="input amount-input w-field" data-key="${f.field_key}" value="${amountInputValue(v)}" inputmode="numeric" dir="ltr" style="text-align:right">${help}</div>`;
      case 'jalali_date':
        return `<div><label class="label">${esc(f.label)} ${req}</label>
          <div class="row" style="gap:6px">
            <input class="input jdate-input w-field" data-key="${f.field_key}" value="${esc(v)}" placeholder="۱۴۰۵/۰۸/۰۳" style="flex:1" autocomplete="off">
            <button type="button" class="btn btn-ghost btn-icon jdate-btn" tabindex="-1" title="تقویم"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"><path d="M8 2v4M16 2v4M3 10h18M5 4h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2z"/></svg></button>
          </div>${help}</div>`;
      case 'bool':
        return `<div><label class="label">${esc(f.label)}</label>
          <label class="row" style="gap:8px;padding:9px 0"><span class="toggle">
            <input type="checkbox" class="w-field" data-key="${f.field_key}" data-bool="1" ${v && v !== '0' ? 'checked' : ''}>
            <span class="track"></span><span class="thumb"></span></span><span class="small">${esc(f.label)}</span></label></div>`;
      default: // text, number, id_no, phone
        return `<div><label class="label">${esc(f.label)} ${req}</label>
          <input class="input w-field" data-key="${f.field_key}" value="${esc(v)}" ${f.field_type === 'number' || f.field_type === 'id_no' ? 'inputmode="numeric"' : ''}>${help}</div>`;
    }
  }

  function contactName(cid) {
    const c = window.__contactsCache.find(x => x.id === +cid);
    return c ? c.name : '';
  }

  async function loadLookups() {
    if (!window.__contactsCache?.length) {
      const r = await api.get('/api/contacts?page_size=100&active=1');
      window.__contactsCache = r.items;
    }
    window.__sigOptions = await api.get('/api/signatories?active=1');
    const org = await api.get('/api/organization');
    window.__orgName = org.name || '';
  }

  function bindFieldEvents(scope, onChange) {
    scope.querySelectorAll('.w-field').forEach(inp => {
      inp.addEventListener('input', () => {
        const key = inp.dataset.key;
        if (inp.dataset.multi) {
          paramsData[key + '__multi'] = [...inp.querySelectorAll('input:checked')].map(x => x.value);
        } else if (inp.dataset.bool) {
          paramsData[key] = inp.checked ? '1' : '0';
        } else if (inp.dataset.contact) {
          // readonly — انتخاب با دکمه
        } else {
          paramsData[key] = inp.value;
        }
        if (generatedOnce) dirty = true;
        onChange && onChange(key);
      });
      inp.addEventListener('change', () => {
        const key = inp.dataset.key;
        if (inp.dataset.multi) {
          paramsData[key + '__multi'] = [...inp.querySelectorAll('input:checked')].map(x => x.value);
        } else if (inp.dataset.bool) {
          paramsData[key] = inp.checked ? '1' : '0';
        } else if (!inp.dataset.contact) {
          paramsData[key] = inp.value;
        }
        if (generatedOnce) dirty = true;
        onChange && onChange(key);
      });
    });
    scope.querySelectorAll('.w-contact-pick').forEach(btn => btn.onclick = () => pickContactModal(btn.dataset.key));
    scope.querySelectorAll('.w-contact-manual').forEach(btn => btn.onclick = () => {
      const key = btn.dataset.key;
      const manual = prompt('نام مخاطب را دستی وارد کنید:');
      if (manual !== null) {
        paramsData[key] = ''; paramsData[key + '__manual'] = manual;
        scope.querySelector(`.w-field[data-key="${key}"]`).value = manual;
        scope.querySelector(`.w-contact-info[data-key="${key}"]`).textContent = 'ورود دستی';
        if (generatedOnce) dirty = true;
      }
    });
    // نمایش اطلاعات وابسته مخاطب انتخاب‌شده
    scope.querySelectorAll('.w-field[data-contact]').forEach(inp => updateDependentInfo(inp.dataset.key, scope));
  }

  function updateDependentInfo(key, scope = body) {
    const info = scope.querySelector(`.w-contact-info[data-key="${key}"]`);
    if (!info) return;
    const cid = paramsData[key];
    const c = window.__contactsCache.find(x => x.id === +cid);
    info.textContent = c ? [c.company_name, c.position, c.address].filter(Boolean).join(' — ') : (paramsData[key + '__manual'] ? 'ورود دستی' : '');
  }
  function updateDependents() {
    body.querySelectorAll('.w-field[data-contact]').forEach(inp => updateDependentInfo(inp.dataset.key));
  }

  async function pickContactModal(key) {
    const m = openModal({
      title: 'انتخاب مخاطب', size: 'modal-lg',
      body: `<input class="input mb-2" id="pk-q" placeholder="جست‌وجو در مخاطبین…">
             <div id="pk-list" style="max-height:380px;overflow:auto"></div>
             <div class="divider"></div>
             <button class="btn btn-ghost btn-sm" id="pk-manual">${icon('edit', 13)} ورود دستی نام</button>`,
    });
    const listEl = m.querySelector('#pk-list');
    async function loadList(q = '') {
      const r = await api.get(`/api/contacts?q=${encodeURIComponent(q)}&active=1&page_size=50`);
      listEl.innerHTML = r.items.map(c => `
        <div class="row" style="padding:9px 10px;border-bottom:1px solid var(--line);cursor:pointer;border-radius:8px" data-id="${c.id}">
          <div class="avatar">${esc(c.name.slice(0, 2))}</div>
          <div style="flex:1"><div class="b" style="font-size:13px">${esc(c.name)}</div>
            <div class="small muted">${esc([c.company_name, c.position].filter(Boolean).join(' — ') || '—')}</div></div>
          ${c.address ? `<span class="small muted">${icon('building', 13)}</span>` : ''}
        </div>`).join('') || '<div class="small muted" style="padding:16px">یافت نشد</div>';
      listEl.querySelectorAll('[data-id]').forEach(row => row.onclick = () => {
        const c = r.items.find(x => x.id === +row.dataset.id);
        paramsData[key] = String(c.id); delete paramsData[key + '__manual'];
        const inp = body.querySelector(`.w-field[data-key="${key}"]`);
        if (inp) inp.value = c.name;
        m.closeModal(); updateDependents();
      });
    }
    m.querySelector('#pk-q').addEventListener('input', debounce(() => loadList(m.querySelector('#pk-q').value), 300));
    await loadList();
    m.querySelector('#pk-manual').onclick = () => {
      const manual = prompt('نام مخاطب را دستی وارد کنید:');
      if (manual !== null) {
        paramsData[key] = ''; paramsData[key + '__manual'] = manual;
        const inp = body.querySelector(`.w-field[data-key="${key}"]`);
        if (inp) inp.value = manual;
        m.closeModal(); updateDependentInfo(key);
      }
    };
  }

  function renderSigPicker() {
    const el = body.querySelector('#sig-picker');
    if (!el) return;
    el.innerHTML = window.__sigOptions.map(s => `
      <label class="chip" style="cursor:pointer;${signatoryIds.includes(s.id) ? 'background:var(--accent-soft);border-color:var(--accent);color:var(--accent)' : ''}">
        <input type="checkbox" value="${s.id}" style="display:none" ${signatoryIds.includes(s.id) ? 'checked' : ''}>
        ${icon('stamp', 13)} ${esc(s.full_name)} <span class="small">(${esc(s.position)})</span>
      </label>`).join('') || '<span class="small muted">امضاکننده‌ای ثبت نشده است — از منوی «امضاکنندگان و مهرها» اضافه کنید.</span>';
    el.querySelectorAll('input').forEach(cb => cb.onchange = () => {
      const id = +cb.value;
      if (cb.checked) { if (!signatoryIds.includes(id)) signatoryIds.push(id); }
      else signatoryIds = signatoryIds.filter(x => x !== id);
      renderSigPicker();
    });
  }

  async function aiExtract() {
    const desc = prompt('متن آزاد حاوی اطلاعات نامه را وارد کنید (یا خلاصه درخواست را بنویسید):');
    if (!desc) return;
    toast('در حال استخراج پارامترها…', 'info');
    try {
      const r = await api.post('/api/ai/extract-params', { text: desc, template_id: template.id });
      Object.assign(paramsData, r.values);
      toast('پارامترها استخراج شد — مقادیر را بررسی کنید');
      step2();
    } catch (err) { toast(err.message, 'error', 5000); }
  }

  // ================= تولید متن و رفتن به ویرایشگر =================
  async function generateAndEdit() {
    subject = body.querySelector('#w-subject').value.trim();
    if (!subject) return toast('موضوع نامه الزامی است', 'warn');
    // جمع‌آوری مقادیر از فرم
    body.querySelectorAll('.w-field').forEach(inp => { /* مقادیر در رویدادها جمع شده‌اند */ });
    try {
      const r = await api.post('/api/letters/generate', { template_id: template.id, params: paramsData });
      bodyHtml = r.body_html;
      generatedOnce = true; dirty = false;
      step3(true);
    } catch (err) {
      const errs = err.data?.detail?.errors;
      if (errs) toast(errs.join('؛ '), 'error', 6000);
      else toast(err.message, 'error', 6000);
    }
  }

  // ================= مرحله ۳: ویرایشگر آزاد =================
  let autosaveTimer = null;
  function step3(fresh = false) {
    step = 3; renderSteps();
    body.innerHTML = `
    <div class="grid-main-aside">
      <div class="card">
        <div class="card-head">
          <h3>${icon('edit', 17)} متن نامه</h3>
          <div class="row">
            <span class="progress-note" id="save-note">—</span>
            <button class="btn btn-ghost btn-sm" id="back-2">${icon('chevronR', 14)} پارامترها</button>
          </div>
        </div>
        <div class="card-pad">
          <div class="mb-2"><label class="label">موضوع نامه</label>
            <input class="input" id="e-subject" value="${esc(subject)}"></div>
          <div id="editor-host"></div>
        </div>
      </div>
      <div class="col">
        <div class="card card-pad">
          <h4 style="font-size:13.5px;margin-bottom:10px">${icon('templates', 15)} پارامترها</h4>
          <div class="small muted mb-2" id="param-summary">${toFa(Object.keys(collectParams()).length)} پارامتر تکمیل شده</div>
          <button class="btn btn-ghost btn-sm" id="edit-params" style="width:100%">ویرایش پارامترها</button>
          ${dirty || !generatedOnce ? '' : `<button class="btn btn-soft btn-sm mt-1" id="regen-btn" style="width:100%">${icon('refresh', 14)} بازتولید متن از پارامترها</button>`}
        </div>
        <div class="card card-pad">
          <button class="btn btn-primary" id="to-step4" style="width:100%">${icon('send', 16)} ادامه — ثبت نهایی و چاپ</button>
          <div class="help mt-1">در ثبت نهایی، شماره رسمی صادر و متن قفل می‌شود.</div>
        </div>
        <div class="card card-pad">
          <h4 style="font-size:13.5px;margin-bottom:10px">${icon('ai', 15)} دستیار نگارش</h4>
          ${aiStatus ? `
            <button class="btn btn-ghost btn-sm" id="ai-formal" style="width:100%;text-align:right;margin-bottom:6px">رسمی‌سازی متن انتخابی/کل</button>
            <button class="btn btn-ghost btn-sm" id="ai-grammar" style="width:100%;text-align:right">اصلاح نگارش</button>`
          : `<div class="small muted">سرویس هوش مصنوعی تنظیم نشده است.<br><a class="link" href="#/settings">تنظیم کلید API</a></div>`}
        </div>
      </div>
    </div>`;

    editor = createEditor(body.querySelector('#editor-host'), {
      initialHtml: bodyHtml,
      onChange: (html, forceSave) => {
        bodyHtml = html;
        dirty = true;
        scheduleAutosave();
        if (forceSave) saveDraft(true);
      },
    });
    body.querySelector('#e-subject').addEventListener('input', e => { subject = e.target.value; scheduleAutosave(); });
    body.querySelector('#back-2').onclick = () => step2();
    body.querySelector('#edit-params').onclick = () => step2();
    body.querySelector('#to-step4').onclick = async () => { if (dirty) await saveDraft(false); step4(); };
    const regenBtn = body.querySelector('#regen-btn');
    if (regenBtn) regenBtn.onclick = regenerateConfirm;

    if (aiStatus) {
      body.querySelector('#ai-formal').onclick = () => aiRewrite('formal');
      body.querySelector('#ai-grammar').onclick = () => aiRewrite('grammar');
    }

    async function aiRewrite(mode) {
      const text = editor.getHtml().replace(/<[^>]*>/g, ' ').slice(0, 15000);
      toast('در حال پردازش با هوش مصنوعی…', 'info', 10000);
      try {
        const r = await api.post('/api/ai/rewrite', { text, mode });
        if (await confirmDialog('اعمال نتیجه هوش مصنوعی',
          'متن بازنویسی‌شده جایگزین متن فعلی شود؟ (متن فعلی در نسخه‌ها حفظ می‌شود)', 'جایگزین')) {
          bodyHtml = `<p>${r.text.replace(/\n+/g, '</p><p>')}</p>`;
          editor.setHtml(bodyHtml);
          dirty = true; scheduleAutosave();
        }
      } catch (err) { toast(err.message, 'error', 5000); }
    }

    async function regenerateConfirm() {
      const ok = await confirmDialog('بازتولید متن',
        'با بازتولید، متن فعلی با متن ساخته‌شده از پارامترهای جدید جایگزین می‌شود.<br><b>نسخه فعلی در سوابق حفظ می‌شود.</b> ادامه می‌دهید؟', 'بازتولید متن');
      if (!ok) return;
      try {
        const r = await api.post(`/api/letters/${letter.id}/regenerate`, { template_id: template.id, params: collectParams() });
        bodyHtml = r.body_html; paramsData = { ...paramsData, ...r.params };
        editor.setHtml(bodyHtml); dirty = false;
        toast('متن بازتولید شد — نسخه قبلی در سوابق ذخیره شد');
      } catch (err) { toast(err.message, 'error'); }
    }

    if (fresh && !letter) saveDraft();
    else if (letter) body.querySelector('#save-note').textContent = 'پیش‌نویس شماره ' + letter.id;
  }

  function collectParams() {
    return paramsData;
  }

  function scheduleAutosave() {
    const note = document.getElementById('save-note');
    if (note) { note.className = 'progress-note saving'; note.textContent = 'ذخیره خودکار…'; }
    clearTimeout(autosaveTimer);
    autosaveTimer = setTimeout(() => saveDraft(false), 2500);
  }

  async function saveDraft(showToast) {
    try {
      if (!letter) {
        const r = await api.post('/api/letters', {
          template_id: template?.id || 0, subject: subject || template?.title || 'نامه بدون موضوع',
          contact_id: firstContactId(), body_html: bodyHtml, params: collectParams(),
          paper_size: paper, orientation, margin_preset: margin, signatory_ids: signatoryIds,
        });
        letter = await api.get(`/api/letters/${r.id}`);
      } else {
        await api.put(`/api/letters/${letter.id}`, {
          template_id: letter.template_id || template?.id || 0, subject,
          contact_id: letter.contact_id || firstContactId(), body_html: bodyHtml,
          params: collectParams(), paper_size: paper, orientation, margin_preset: margin,
          signatory_ids: signatoryIds,
        });
        letter.subject = subject;
      }
      dirty = false;
      const note = document.getElementById('save-note');
      if (note) { note.className = 'progress-note saved'; note.textContent = 'ذخیره شد ✓ ' + toFa(new Date().toLocaleTimeString('fa-IR').slice(0, 5)); }
      if (showToast) toast('پیش‌نویس ذخیره شد');
      refreshDraftsBadge();
    } catch (err) {
      const note = document.getElementById('save-note');
      if (note) { note.className = 'progress-note'; note.textContent = 'خطا در ذخیره'; }
      if (showToast) toast(err.message, 'error');
    }
  }

  function firstContactId() {
    const contactField = (template?.fields || []).find(f => f.field_type === 'contact');
    return contactField ? (+paramsData[contactField.field_key] || 0) : 0;
  }

  // ================= مرحله ۴: ثبت نهایی و چاپ =================
  async function step4() {
    step = 4; renderSteps();
    if (!letter) await saveDraft(false);
    const seqs = await api.get('/api/sequences');
    const today = formatJalali(todayJalali());
    body.innerHTML = `
    <div class="grid-main-aside">
      <div class="card">
        <div class="card-head"><h3>${icon('send', 17)} ثبت نهایی نامه</h3></div>
        <div class="card-pad">
          <div class="form-grid">
            <div><label class="label">شماره‌گذار</label>
              <select class="select" id="fin-seq">${seqs.filter(s => s.is_active).map(s =>
                `<option value="${s.id}">${esc(s.name)} — نمونه: ${toFa(s.preview)}</option>`).join('')}</select>
              <div class="help">شماره فقط در زمان ثبت نهایی صادر و هرگز تکرار نمی‌شود.</div></div>
            <div><label class="label">تاریخ صدور</label>
              ${jalaliInput(`id="fin-date" value="${today}"`)}</div>
            <div><label class="label">اندازه کاغذ</label>
              <select class="select" id="fin-paper"><option value="A4" ${paper === 'A4' ? 'selected' : ''}>A4</option><option value="A5" ${paper === 'A5' ? 'selected' : ''}>A5</option></select></div>
            <div><label class="label">جهت</label>
              <select class="select" id="fin-orient"><option value="portrait" ${orientation === 'portrait' ? 'selected' : ''}>عمودی</option><option value="landscape" ${orientation === 'landscape' ? 'selected' : ''}>افقی</option></select></div>
            <div><label class="label">حاشیه</label>
              <select class="select" id="fin-margin">
                <option value="normal" ${margin === 'normal' ? 'selected' : ''}>عادی</option>
                <option value="narrow" ${margin === 'narrow' ? 'selected' : ''}>کم</option>
                <option value="wide" ${margin === 'wide' ? 'selected' : ''}>زیاد</option></select></div>
          </div>
          <div class="divider"></div>
          <div class="row">
            <button class="btn btn-primary" id="fin-btn">${icon('send', 16)} ثبت نهایی و دریافت شماره</button>
            <button class="btn btn-ghost" id="fin-preview">${icon('eye', 16)} پیش‌نمایش چاپ</button>
            <button class="btn btn-ghost" id="fin-back">بازگشت به ویرایشگر</button>
          </div>
        </div>
      </div>
      <div class="card card-pad" style="background:var(--card-2)">
        <h4 style="font-size:13px;margin-bottom:8px">${icon('info', 14)} نکته</h4>
        <p class="small muted">پس از ثبت نهایی، متن نامه تغییرناپذیر می‌شود. در صورت نیاز به اصلاح، نامه را ابطال و نسخه جدید بسازید.</p>
      </div>
    </div>`;

    bindJalaliInput(body);
    body.querySelector('#fin-back').onclick = () => step3();
    body.querySelector('#fin-preview').onclick = () => {
      paper = body.querySelector('#fin-paper').value; orientation = body.querySelector('#fin-orient').value;
      margin = body.querySelector('#fin-margin').value;
      location.hash = `#/letters/print?id=${letter.id}&preview=1`;
    };
    body.querySelector('#fin-btn').onclick = async () => {
      const issueDate = body.querySelector('#fin-date').value;
      const parsedIssue = parseJalaliStr(issueDate);
      if (!parsedIssue) return toast('تاریخ صدور معتبر نیست', 'warn');
      const issueAscii = `${parsedIssue.jy}/${String(parsedIssue.jm).padStart(2, '0')}/${String(parsedIssue.jd).padStart(2, '0')}`;
      paper = body.querySelector('#fin-paper').value; orientation = body.querySelector('#fin-orient').value;
      margin = body.querySelector('#fin-margin').value;
      if (dirty) await saveDraft(false);
      try {
        const r = await api.post(`/api/letters/${letter.id}/finalize`, {
          sequence_id: +body.querySelector('#fin-seq').value, issue_date: issueAscii,
        });
        toast(`نامه با شماره ${toFa(r.letter_number)} ثبت شد`);
        refreshDraftsBadge();
        letter = await api.get(`/api/letters/${letter.id}`);
        finalizeSuccess(r);
      } catch (err) { toast(err.message, 'error', 6000); }
    };
  }

  function finalizeSuccess(result) {
    body.innerHTML = `<div class="card" style="text-align:center;padding:50px 20px">
      <div style="width:64px;height:64px;border-radius:50%;background:var(--success-soft);color:var(--success);
        display:flex;align-items:center;justify-content:center;margin:0 auto 16px;font-size:30px">✓</div>
      <h3 style="font-size:17px;margin-bottom:8px">نامه با موفقیت ثبت شد</h3>
      <div class="row" style="justify-content:center;gap:10px;margin:14px 0">
        <span class="chip">شماره نامه: <b>${toFa(result.letter_number)}</b></span>
        <span class="chip">تاریخ: ${toFa(result.issued_date_jalali)}</span>
      </div>
      <div class="row" style="justify-content:center;gap:10px">
        <button class="btn btn-primary" onclick="location.hash='#/letters/print?id=${letter.id}'">${icon('print', 15)} چاپ / ذخیره PDF</button>
        <button class="btn btn-ghost" onclick="location.hash='#/archive'">مشاهده بایگانی</button>
        <button class="btn btn-ghost" onclick="location.hash='#/letters/new'">نامه جدید</button>
      </div>
    </div>`;
  }

  // ================= بازیابی پیش‌نویس موجود =================
  if (editId) {
    letter = await api.get(`/api/letters/${editId}`);
    if (letter.status !== 'draft') { location.hash = `#/letters/view?id=${editId}`; return; }
    await loadLookups();
    template = letter.template_id ? await api.get(`/api/templates/${letter.template_id}`) : null;
    paramsData = letter.parameters || {};
    bodyHtml = letter.body_html;
    subject = letter.subject;
    contactId = letter.contact_id || 0;
    paper = letter.paper_size; orientation = letter.orientation; margin = letter.margin_preset;
    signatoryIds = (letter.signatories || []).map(s => s.signatory_id).filter(Boolean);
    generatedOnce = true;
    if (!template) { step1(); return; }
    step3();
  } else {
    await loadLookups();
    await step1();
  }
}
