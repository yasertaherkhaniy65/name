// یارنامه — فهرست الگوهای نامه
import { api, toast, confirmDialog, esc, emptyState } from '../api.js';
import { icon } from '../icons.js';
import { toFa } from '../jalali.js';

export async function render(root) {
  root.innerHTML = `<div class="col">
    <div class="card">
      <div class="card-head">
        <div><h3>${icon('templates', 18)} الگوهای نامه</h3>
          <div class="small muted">هر الگو پارامترهای اختصاصی خود را دارد؛ هنگام صدور نامه فقط فرم همان الگو نمایش داده می‌شود.</div></div>
        <button class="btn btn-primary" id="btn-add">${icon('plus', 16)} الگوی جدید</button>
      </div>
      <div class="card-pad" style="padding-bottom:10px">
        <div class="search-bar">
          <input class="input search-grow" id="f-q" placeholder="جست‌وجوی الگو…">
          <select class="select" id="f-cat"><option value="">همه دسته‌ها</option></select>
        </div>
      </div>
      <div id="list"></div>
    </div>
  </div>`;

  const listEl = root.querySelector('#list');
  const cats = await api.get('/api/templates/categories');
  root.querySelector('#f-cat').innerHTML += cats.map(c => `<option>${esc(c)}</option>`).join('');

  async function load() {
    const q = root.querySelector('#f-q').value, cat = root.querySelector('#f-cat').value;
    const items = await api.get(`/api/templates?q=${encodeURIComponent(q)}&category=${encodeURIComponent(cat)}`);
    if (!items.length) {
      listEl.innerHTML = emptyState('الگویی یافت نشد', 'الگوی جدید بسازید یا از الگوهای آماده اولیه استفاده کنید.');
      return;
    }
    // گروه‌بندی بر اساس دسته
    const groups = {};
    items.forEach(t => { (groups[t.category] = groups[t.category] || []).push(t); });
    listEl.innerHTML = Object.entries(groups).map(([cat, list]) => `
      <div>
        <div style="padding:10px 22px;background:var(--card-2);font-size:12px;font-weight:700;color:var(--navy-800);border-bottom:1px solid var(--line)">${esc(cat)}</div>
        <div class="table-wrap"><table class="tbl"><tbody>
          ${list.map(t => `
            <tr>
              <td style="width:44%">
                <div class="b" style="cursor:pointer" onclick="location.hash='#/letters/new?template=${t.id}'">${esc(t.title)} ${t.is_system ? '<span class="badge badge-muted">آماده</span>' : ''}</div>
                <div class="small muted">${esc(t.description || '')}</div>
              </td>
              <td class="small nowrap">${toFa(t.field_count)} پارامتر</td>
              <td class="small nowrap">${toFa(t.usage_count)} نامه</td>
              <td>${t.is_active ? '<span class="badge badge-final">فعال</span>' : '<span class="badge badge-canceled">غیرفعال</span>'}</td>
              <td><div class="actions">
                <button class="btn btn-accent btn-sm" onclick="location.hash='#/letters/new?template=${t.id}'">${icon('letterNew', 14)} نامه جدید</button>
                <button class="btn btn-ghost btn-sm" data-edit="${t.id}">${icon('edit', 14)}</button>
                <button class="btn btn-ghost btn-sm" data-copy="${t.id}" title="کپی الگو">${icon('copy', 14)}</button>
                <button class="btn btn-danger btn-sm" data-del="${t.id}" title="حذف">${icon('trash', 14)}</button>
              </div></td>
            </tr>`).join('')}
        </tbody></table></div>
      </div>`).join('');

    listEl.querySelectorAll('[data-edit]').forEach(b => b.onclick = () => { location.hash = `#/template-edit?id=${b.dataset.edit}`; });
    listEl.querySelectorAll('[data-copy]').forEach(b => b.onclick = async () => {
      await api.post(`/api/templates/${b.dataset.copy}/duplicate`);
      toast('کپی الگو ساخته شد'); load();
    });
    listEl.querySelectorAll('[data-del]').forEach(b => b.onclick = async () => {
      try {
        if (await confirmDialog('حذف الگو', 'الگو حذف شود؟ متن نامه‌های قبلاً صادرشده مستقل از الگو ذخیره شده و تغییری نمی‌کند.', 'حذف', true)) {
          await api.del(`/api/templates/${b.dataset.del}`);
          toast('الگو حذف شد'); load();
        }
      } catch (err) {
        if (err.status === 409) {
          const ok = await confirmDialog('الگوی استفاده‌شده',
            `${err.data?.detail?.message || 'این الگو در نامه‌ها استفاده شده است'}.<br>برای حفظ سوابق، الگو غیرفعال شود؟`, 'غیرفعال کردن');
          if (ok) {
            const t = (await api.get(`/api/templates/${b.dataset.del}`));
            await api.put(`/api/templates/${b.dataset.del}`, { ...t, is_active: false });
            toast('الگو غیرفعال شد', 'warn'); load();
          }
        } else toast(err.message, 'error');
      }
    });
  }
  root.querySelector('#f-q').addEventListener('input', load);
  root.querySelector('#f-cat').onchange = load;
  root.querySelector('#btn-add').onclick = () => { location.hash = '#/template-edit'; };
  await load();
}
