// یارنامه — بایگانی نامه‌ها با جست‌وجو و فیلتر
import { api, toast, esc, statusBadge, pagination, emptyState } from '../api.js';
import { icon } from '../icons.js';
import { toFa, toEn, formatJalaliStr, jalaliInput, bindJalaliInput } from '../jalali.js';

export async function render(root, { params }) {
  let page = 1;
  const q0 = params.get('q') || '', status0 = params.get('status') || '';
  root.innerHTML = `<div class="card">
    <div class="card-head">
      <h3>${icon('archive', 18)} نامه‌های من و بایگانی</h3>
      <button class="btn btn-accent" onclick="location.hash='#/letters/new'">${icon('letterNew', 15)} نامه جدید</button>
    </div>
    <div class="card-pad" style="padding-bottom:10px">
      <div class="search-bar">
        <input class="input search-grow" id="a-q" value="${esc(q0)}" placeholder="جست‌وجو: شماره، موضوع، متن، مخاطب…">
        <select class="select" id="a-status">
          <option value="">همه وضعیت‌ها</option>
          <option value="draft" ${status0 === 'draft' ? 'selected' : ''}>پیش‌نویس</option>
          <option value="final" ${status0 === 'final' ? 'selected' : ''}>ثبت‌شده</option>
          <option value="canceled" ${status0 === 'canceled' ? 'selected' : ''}>ابطال‌شده</option>
        </select>
        <select class="select" id="a-year"><option value="">همه سال‌ها</option></select>
        ${jalaliInput('id="a-from" placeholder="از تاریخ"')}
        ${jalaliInput('id="a-to" placeholder="تا تاریخ"')}
        <button class="btn btn-ghost" id="a-reset">${icon('refresh', 14)}</button>
      </div>
    </div>
    <div id="a-list"></div>
    <div class="pager" id="a-pager"></div>
  </div>`;

  const listEl = root.querySelector('#a-list'), pagerEl = root.querySelector('#a-pager');
  const qEl = root.querySelector('#a-q'), statusEl = root.querySelector('#a-status'),
    yearEl = root.querySelector('#a-year'), fromEl = root.querySelector('#a-from'), toEl = root.querySelector('#a-to');

  // سال‌های موجود
  try {
    const r = await api.get('/api/reports');
    const years = r.by_year.map(y => y.y).filter(Boolean);
    yearEl.innerHTML += years.map(y => `<option value="${y}">${toFa(y)}</option>`).join('');
  } catch { /* بی‌اهمیت */ }
  bindJalaliInput(root);

  async function load() {
    listEl.innerHTML = '<div class="skeleton"></div>';
    const q = encodeURIComponent(qEl.value.trim());
    const from = toEn(fromEl.value).replace(/\//g, '-'), to = toEn(toEl.value).replace(/\//g, '-');
    const r = await api.get(`/api/letters?q=${q}&status=${statusEl.value}&year=${yearEl.value}&from_jalali=${from}&to_jalali=${to}&page=${page}&page_size=20`);
    if (!r.items.length) {
      listEl.innerHTML = emptyState('نامه‌ای یافت نشد', 'جست‌وجو یا فیلترها را تغییر دهید، یا نامه جدیدی صادر کنید.');
      pagerEl.innerHTML = '';
      return;
    }
    listEl.innerHTML = `<div class="table-wrap"><table class="tbl">
      <thead><tr><th>شماره</th><th>موضوع</th><th>مخاطب</th><th>تاریخ</th><th>وضعیت</th><th></th></tr></thead>
      <tbody>${r.items.map(l => `
        <tr>
          <td class="nowrap"><div class="b">${l.letter_number ? toFa(l.letter_number) : '—'}</div>
            ${l.template_title_snapshot ? `<div class="small muted">${esc(l.template_title_snapshot)}</div>` : ''}</td>
          <td style="max-width:300px"><div style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;cursor:pointer" class="link"
              onclick="location.hash='#/letters/view?id=${l.id}'">${esc(l.subject || 'بدون موضوع')}</div></td>
          <td class="small">${esc(l.contact_name || '—')}</td>
          <td class="nowrap small muted">${l.issued_date_jalali ? formatJalaliStr(l.issued_date_jalali) : toFa(l.created_at.slice(0, 10))}</td>
          <td>${statusBadge(l.status)}</td>
          <td><div class="actions">
            <button class="btn btn-ghost btn-sm" onclick="location.hash='#/letters/view?id=${l.id}'" title="مشاهده">${icon('eye', 14)}</button>
            ${l.status === 'draft' ? `<button class="btn btn-ghost btn-sm" onclick="location.hash='#/letters/edit?id=${l.id}'" title="ویرایش">${icon('edit', 14)}</button>` : ''}
            <button class="btn btn-ghost btn-sm" onclick="location.hash='#/letters/print?id=${l.id}'" title="چاپ">${icon('print', 14)}</button>
          </div></td>
        </tr>`).join('')}</tbody></table></div>`;
    pagination(pagerEl, r, p => { page = p; load(); });
  }

  let timer;
  qEl.addEventListener('input', () => { clearTimeout(timer); timer = setTimeout(() => { page = 1; load(); }, 350); });
  [statusEl, yearEl].forEach(el => el.onchange = () => { page = 1; load(); });
  [fromEl, toEl].forEach(el => el.addEventListener('change', () => { page = 1; load(); }));
  root.querySelector('#a-reset').onclick = () => {
    qEl.value = ''; statusEl.value = ''; yearEl.value = ''; fromEl.value = ''; toEl.value = '';
    page = 1; load();
  };
  await load();
}
