// یارنامه — صفحه چاپ و ذخیره PDF (از طریق چاپگر مرورگر)
import { api, toast, esc } from '../api.js';
import { icon } from '../icons.js';
import { renderSheetHtml, printCssFor } from '../sheet.js';

export async function render(root, { params }) {
  const id = +params.get('id');
  const previewOnly = params.get('preview') === '1';
  const l = await api.get(`/api/letters/${id}`);
  const org = await api.get('/api/organization');

  root.innerHTML = `
  <style id="print-page-css">${printCssFor(l)}</style>
  <div class="row-between mb-2 no-print">
    <div class="row">
      <button class="btn btn-ghost btn-sm" onclick="location.hash='#/letters/view?id=${l.id}'">${icon('chevronR', 14)} بازگشت</button>
      <span class="chip">کاغذ ${l.paper_size} ${l.orientation === 'landscape' ? 'افقی' : 'عمودی'}</span>
      <span class="chip">حاشیه ${l.margin_preset === 'narrow' ? 'کم' : l.margin_preset === 'wide' ? 'زیاد' : 'عادی'}</span>
    </div>
    <div class="row">
      <select class="select" id="pr-size" style="width:auto">
        <option value="A4" ${l.paper_size === 'A4' ? 'selected' : ''}>A4</option>
        <option value="A5" ${l.paper_size === 'A5' ? 'selected' : ''}>A5</option></select>
      <select class="select" id="pr-orient" style="width:auto">
        <option value="portrait" ${l.orientation === 'portrait' ? 'selected' : ''}>عمودی</option>
        <option value="landscape" ${l.orientation === 'landscape' ? 'selected' : ''}>افقی</option></select>
      <select class="select" id="pr-margin" style="width:auto">
        <option value="normal" ${l.margin_preset === 'normal' ? 'selected' : ''}>حاشیه عادی</option>
        <option value="narrow" ${l.margin_preset === 'narrow' ? 'selected' : ''}>حاشیه کم</option>
        <option value="wide" ${l.margin_preset === 'wide' ? 'selected' : ''}>حاشیه زیاد</option></select>
      <button class="btn btn-ghost" id="pr-apply">${icon('refresh', 15)} اعمال</button>
      <button class="btn btn-primary" id="pr-print">${icon('print', 15)} چاپ / ذخیره PDF</button>
    </div>
  </div>
  <div class="paper-wrap" id="print-host"></div>`;

  const host = root.querySelector('#print-host');
  function draw() {
    host.innerHTML = renderSheetHtml(l, org, { preview: l.status !== 'final' });
  }
  draw();

  root.querySelector('#pr-apply').onclick = () => {
    l.paper_size = root.querySelector('#pr-size').value;
    l.orientation = root.querySelector('#pr-orient').value;
    l.margin_preset = root.querySelector('#pr-margin').value;
    document.getElementById('print-page-css').textContent = printCssFor(l);
    draw();
  };
  root.querySelector('#pr-print').onclick = () => {
    // قبل از چاپ، حالت پیش‌نویس را با نقطه‌چین واقعی نمایش بده
    window.print();
  };

  if (!previewOnly) {
    setTimeout(() => toast('برای ذخیره PDF در پنجره چاپ، گزینه «Save as PDF / ذخیره به‌صورت PDF» را انتخاب کنید', 'info', 6000), 400);
  }
}
