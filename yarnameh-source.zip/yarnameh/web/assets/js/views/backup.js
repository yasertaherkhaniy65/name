// یارنامه — پشتیبان‌گیری و بازیابی
import { api, toast, confirmDialog, esc } from '../api.js';
import { icon } from '../icons.js';
import { toFa, formatJalaliStr, todayJalali } from '../jalali.js';

export async function render(root) {
  const r = await api.get('/api/backup/list');
  root.innerHTML = `<div class="grid-main-aside">
    <div class="card">
      <div class="card-head"><h3>${icon('backup', 18)} نسخه‌های پشتیبان</h3>
        <button class="btn btn-primary" id="bk-new">${icon('plus', 15)} تهیه نسخه پشتیبان</button></div>
      <div class="card-pad row-between" style="background:var(--card-2);border-bottom:1px solid var(--line)">
        <span class="small muted">آخرین پشتیبان‌گیری: <b>${r.last_backup_at ? toFa(r.last_backup_at) : 'هنوز انجام نشده'}</b></span>
        <span class="small muted" dir="ltr" style="font-size:11px">${esc(r.backups_dir)}</span>
      </div>
      <div id="bk-list"></div>
    </div>
    <div class="card card-pad" style="background:var(--card-2)">
      <h4 style="font-size:13.5px;margin-bottom:10px">${icon('info', 15)} راهنمای پشتیبان</h4>
      <ul class="small muted" style="padding-right:16px;line-height:2.3">
        <li>هر پشتیبان شامل دیتابیس، تصاویر امضا/مهر، لوگو و پیوست‌ها است.</li>
        <li>از روش رسمی Backup در SQLite استفاده می‌شود؛ فایل پشتیبان همیشه سازگار و کامل است.</li>
        <li>در زمان بازیابی، ابتدا به‌طور خودکار از وضعیت فعلی پشتیبان ایمنی گرفته می‌شود.</li>
        <li>فایل پشتیبان را می‌توانید دانلود و در محل امن نگهداری کنید.</li>
      </ul>
    </div>
  </div>`;

  const listEl = root.querySelector('#bk-list');
  function drawList(items) {
    if (!items.length) {
      listEl.innerHTML = '<div class="small muted" style="padding:24px;text-align:center">هنوز نسخه پشتیبانی تهیه نشده است.</div>';
      return;
    }
    listEl.innerHTML = `<div class="table-wrap"><table class="tbl">
      <thead><tr><th>فایل</th><th>حجم</th><th>زمان</th><th></th></tr></thead>
      <tbody>${items.map(b => `
        <tr>
          <td class="small" dir="ltr">${esc(b.file_name)}</td>
          <td class="small nowrap">${toFa((b.size / 1024 / 1024).toFixed(2))} MB</td>
          <td class="small muted nowrap">${toFa(b.created_at)}</td>
          <td><div class="actions">
            <a class="btn btn-ghost btn-sm" href="/api/backup/download/${encodeURIComponent(b.file_name)}">${icon('download', 13)} دانلود</a>
            <button class="btn btn-danger btn-sm" data-restore="${esc(b.file_name)}">${icon('refresh', 13)} بازیابی</button>
          </div></td>
        </tr>`).join('')}</tbody></table></div>`;
    listEl.querySelectorAll('[data-restore]').forEach(b => b.onclick = () => restore(b.dataset.restore));
  }
  drawList(r.items);

  root.querySelector('#bk-new').onclick = async () => {
    toast('در حال تهیه نسخه پشتیبان…', 'info');
    try {
      const res = await api.post('/api/backup/create');
      toast(`پشتیبان «${res.file_name}» ساخته شد`);
      const r2 = await api.get('/api/backup/list');
      drawList(r2.items);
    } catch (err) { toast(err.message, 'error'); }
  };

  async function restore(fileName) {
    const ok = await confirmDialog('بازیابی نسخه پشتیبان',
      `اطلاعات فعلی با محتوای «${esc(fileName)}» جایگزین می‌شود.<br>
       قبل از جایگزینی، به‌طور خودکار از وضعیت فعلی پشتیبان ایمنی گرفته می‌شود.<br>
       <b>پس از بازیابی، برنامه را مجدداً راه‌اندازی کنید.</b>`,
      'بازیابی کن', true);
    if (!ok) return;
    try {
      const res = await api.post('/api/backup/restore', { file_name: fileName });
      toast(res.message || 'بازیابی انجام شد', 'success', 6000);
      if (res.safety_backup) toast(`پشتیبان ایمنی: ${res.safety_backup}`, 'info', 8000);
      setTimeout(() => location.reload(), 2500);
    } catch (err) { toast(err.message, 'error', 6000); }
  }
}
