// یارنامه — تبدیل تاریخ شمسی (پورت JS الگوریتم استاندارد jalaali) + تقویم انتخابی
const BREAKS = [-61, 9, 38, 199, 426, 686, 756, 818, 1111, 1181, 1210, 1635, 2060, 2097, 2192, 2262, 2324, 2394, 2456, 3178];
const div = (a, b) => ~~(a / b);
const mod = (a, b) => a - ~~(a / b) * b;

function jalCal(jy) {
  const bl = BREAKS.length, gy = jy + 621;
  let leapJ = -14, jp = BREAKS[0], jm, jump;
  if (jy < jp || jy >= BREAKS[bl - 1]) throw new Error('سال نامعتبر: ' + jy);
  for (let i = 1; i < bl; i++) {
    jm = BREAKS[i]; jump = jm - jp;
    if (jy < jm) break;
    leapJ = leapJ + div(jump, 33) * 8 + div(mod(jump, 33), 4);
    jp = jm;
  }
  let n = jy - jp;
  leapJ = leapJ + div(n, 33) * 8 + div(mod(n, 33) + 3, 4);
  const leapG = div(gy, 4) - div((div(gy, 100) + 1) * 3, 4) - 150;
  const march = 20 + leapJ - leapG;
  if (jump - n < 6) n = n - jump + div(jump + 4, 33) * 33;
  let leap = mod(mod(n + 1, 33) - 1, 4);
  if (leap === -1) leap = 4;
  return { leap, gy, march };
}
function g2d(gy, gm, gd) {
  let d = div((gy + div(gm - 8, 6) + 100100) * 1461, 4) + div(153 * mod(gm + 9, 12) + 2, 5) + gd - 34840408;
  d = d - div(div(gy + 100100 + div(gm - 8, 6), 100) * 3, 4) + 752;
  return d;
}
function d2g(jdn) {
  let j = 4 * jdn + 139361631;
  j = j + div(div(4 * jdn + 183187720, 146097) * 3, 4) * 4 - 3908;
  const i = div(mod(j, 1461), 4) * 5 + 308;
  const gd = div(mod(i, 153), 5) + 1;
  const gm = mod(div(i, 153), 12) + 1;
  const gy = div(j, 1461) - 100100 + div(8 - gm, 6);
  return { gy, gm, gd };
}
export function toJalali(gy, gm, gd) {
  const jdn = g2d(gy, gm, gd), gy2 = d2g(jdn).gy;
  let jy = gy2 - 621;
  const r = jalCal(jy), jdn1f = g2d(gy2, 3, r.march);
  let k = jdn - jdn1f;
  if (k >= 0) {
    if (k <= 185) return { jy, jm: 1 + div(k, 31), jd: mod(k, 31) + 1 };
    k -= 186;
  } else { jy -= 1; k += 179; if (r.leap === 1) k += 1; }
  return { jy, jm: 7 + div(k, 30), jd: mod(k, 30) + 1 };
}
export function toGregorian(jy, jm, jd) {
  const r = jalCal(jy);
  return d2g(g2d(r.gy, 3, r.march) + (jm - 1) * 31 - div(jm, 7) * (jm - 7) + jd - 1);
}
export function isLeapJalali(jy) { return jalCal(jy).leap === 0; }
export function monthLength(jy, jm) {
  if (jm <= 6) return 31;
  if (jm <= 11) return 30;
  return isLeapJalali(jy) ? 30 : 29;
}
export const MONTHS = ['فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور', 'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'];
export const WEEKDAYS = ['ش', 'ی', 'د', 'س', 'چ', 'پ', 'ج'];
export const FA_DIGITS = '۰۱۲۳۴۵۶۷۸۹';
export const toFa = s => String(s).replace(/\d/g, d => FA_DIGITS[d]);
export const toEn = s => String(s).replace(/[۰-۹]/g, d => FA_DIGITS.indexOf(d));

export function todayJalali() {
  const t = new Date();
  return toJalali(t.getFullYear(), t.getMonth() + 1, t.getDate());
}
export function formatJalali({ jy, jm, jd }, style = 'numeric') {
  if (style === 'long') return `${toFa(jd)} ${MONTHS[jm - 1]} ${toFa(jy)}`;
  return toFa(`${jy}/${String(jm).padStart(2, '0')}/${String(jd).padStart(2, '0')}`);
}
export function formatJalaliStr(str, style = 'numeric') {
  const p = parseJalaliStr(str);
  return p ? formatJalali(p, style) : '';
}
export function parseJalaliStr(s) {
  if (!s) return null;
  const parts = toEn(s).trim().replace(/-/g, '/').split('/');
  if (parts.length !== 3) return null;
  const jy = +parts[0], jm = +parts[1], jd = +parts[2];
  if (!jy || jy < 1300 || jy > 1500 || !(jm >= 1 && jm <= 12) || !(jd >= 1) || jd > monthLength(jy, jm)) return null;
  return { jy, jm, jd };
}
export function weekdayOf({ jy, jm, jd }) {
  const g = toGregorian(jy, jm, jd);
  return (new Date(g.gy, g.gm - 1, g.gd).getDay() + 1) % 7; // ۰=شنبه
}

// ---------------- تقویم انتخابی ----------------
let openPicker = null;
export function closePicker() {
  if (openPicker) { openPicker.remove(); openPicker = null; document.removeEventListener('click', onDocClick, true); }
}
function onDocClick(e) {
  if (openPicker && !openPicker.contains(e.target) && e.target !== openPicker._anchor) closePicker();
}
export function showDatePicker(anchor, current, onPick) {
  closePicker();
  const init = parseJalaliStr(current) || todayJalali();
  let view = { jy: init.jy, jm: init.jm };
  const el = document.createElement('div');
  el.className = 'jdp';
  el._anchor = anchor;
  document.body.appendChild(el);
  openPicker = el;
  setTimeout(() => document.addEventListener('click', onDocClick, true), 0);

  function position() {
    const r = anchor.getBoundingClientRect();
    el.style.visibility = 'hidden'; el.style.display = 'block';
    const w = 252, h = el.offsetHeight || 300;
    let left = r.left - (w - r.width) / 2, top = r.bottom + 6;
    if (left < 8) left = 8;
    if (left + w > innerWidth - 8) left = innerWidth - w - 8;
    if (top + h > innerHeight - 8) top = r.top - h - 6;
    el.style.left = left + 'px'; el.style.top = top + 'px'; el.style.visibility = 'visible';
  }
  function render() {
    const t = todayJalali();
    const days = monthLength(view.jy, view.jm);
    const firstWd = weekdayOf({ jy: view.jy, jm: view.jm, jd: 1 });
    let cells = '';
    for (let i = 0; i < firstWd; i++) cells += '<button class="jdp-day empty-cell" disabled></button>';
    for (let d = 1; d <= days; d++) {
      const isToday = t.jy === view.jy && t.jm === view.jm && t.jd === d;
      const isSel = init.jy === view.jy && init.jm === view.jm && init.jd === d;
      cells += `<button class="jdp-day${isToday ? ' today' : ''}${isSel ? ' selected' : ''}" data-d="${d}">${toFa(d)}</button>`;
    }
    el.innerHTML = `
      <div class="jdp-head">
        <button class="jdp-nav" data-nav="prev">${'&#8250;'}</button>
        <span class="jdp-title">${MONTHS[view.jm - 1]} ${toFa(view.jy)}</span>
        <button class="jdp-nav" data-nav="next">${'&#8249;'}</button>
      </div>
      <div class="jdp-grid">${WEEKDAYS.map(w => `<span class="jdp-wd">${w}</span>`).join('')}${cells}</div>
      <div class="jdp-foot">
        <button class="btn btn-ghost btn-sm" data-act="today">امروز</button>
        <button class="btn btn-ghost btn-sm" data-act="clear">پاک کردن</button>
      </div>`;
    el.querySelector('[data-nav="prev"]').onclick = () => { view.jm--; if (view.jm < 1) { view.jm = 12; view.jy--; } render(); };
    el.querySelector('[data-nav="next"]').onclick = () => { view.jm++; if (view.jm > 12) { view.jm = 1; view.jy++; } render(); };
    el.querySelectorAll('[data-d]').forEach(b => b.onclick = () => {
      const picked = { jy: view.jy, jm: view.jm, jd: +b.dataset.d };
      closePicker(); onPick(formatJalali(picked), picked);
    });
    el.querySelector('[data-act="today"]').onclick = () => { closePicker(); onPick(formatJalali(t), t); };
    el.querySelector('[data-act="clear"]').onclick = () => { closePicker(); onPick('', null); };
    position();
  }
  render();
}

// ورودی تاریخ شمسی با دکمه تقویم
export function jalaliInput(attrs = '') {
  return `<div class="row" style="gap:6px">
    <input class="input jdate-input" ${attrs} placeholder="۱۴۰۵/۰۸/۰۳" autocomplete="off" style="flex:1">
    <button type="button" class="btn btn-ghost btn-icon jdate-btn" tabindex="-1" title="تقویم">${/*calendar*/
      '<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"><path d="M8 2v4M16 2v4M3 10h18M5 4h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2z"/></svg>'}</button>
  </div>`;
}
export function bindJalaliInput(root) {
  root.querySelectorAll('.jdate-btn').forEach(btn => {
    const input = btn.parentElement.querySelector('.jdate-input');
    btn.addEventListener('click', e => {
      e.stopPropagation();
      showDatePicker(btn, input.value, (str) => {
        input.value = str;
        input.dispatchEvent(new Event('input', { bubbles: true }));
        input.dispatchEvent(new Event('change', { bubbles: true }));
      });
    });
  });
}
