// یارنامه — ویرایشگر متن نامه (contenteditable کامل با ابزارهای اداری)
// پشتیبانی: بولد/ایتالیک/زیرخط، ترازبندی، فونت و اندازه، فاصله خطوط، فهرست، جدول، عنوان، خط جداکننده، تصویر، بازگشت/تکرار
import { api, toast } from './api.js';

const FONTS = ['وزیرمتن', 'Tahoma', 'B Nazanin', 'IRANSans', 'Arial', 'Times New Roman'];
const SIZES = [{ v: '2', t: 'کوچک' }, { v: '3', t: 'معمولی' }, { v: '4', t: 'بزرگ' }, { v: '5', t: 'بزرگ‌تر' }, { v: '6', t: 'عنوان' }];
const LINE_HEIGHTS = [{ v: '1.7', t: 'فشرده' }, { v: '2', t: 'معمولی' }, { v: '2.4', t: 'باز' }, { v: '2.8', t: 'خیلی باز' }];

function cmd(name, val = null) {
  document.execCommand('styleWithCSS', false, true);
  document.execCommand(name, false, val);
}
function selectionHtml() {
  const sel = window.getSelection();
  if (!sel.rangeCount || sel.isCollapsed) return '';
  const div = document.createElement('div');
  div.appendChild(sel.getRangeAt(0).cloneContents());
  return div.innerHTML;
}
function wrapSelection(styles) {
  const html = selectionHtml();
  if (!html) return;
  cmd('insertHTML', `<span style="${styles}">${html}</span>`);
}
function selectedBlocks(area) {
  const sel = window.getSelection();
  if (!sel.rangeCount) return [];
  let node = sel.getRangeAt(0).startContainer;
  const blocks = [];
  const collect = (el) => {
    if (!el || el === area) return;
    if (/^(P|DIV|H1|H2|H3|H4|LI|TD|TH|BLOCKQUOTE)$/.test(el.tagName)) blocks.push(el);
    el.querySelectorAll?.('p,div,h1,h2,h3,h4,li,td,th,blockquote').forEach(t => {
      if (sel.getRangeAt(0).intersectsNode(t)) blocks.push(t);
    });
  };
  collect(node.nodeType === 3 ? node.parentElement : node);
  if (!blocks.length) blocks.push(area);
  return [...new Set(blocks)];
}

export function createEditor(container, { initialHtml = '', onChange = null, placeholder = '' } = {}) {
  container.innerHTML = `
    <div class="editor-shell">
      <div class="editor-toolbar no-print">
        <button class="tb-btn" data-cmd="undo" title="بازگشت (Ctrl+Z)">↷</button>
        <button class="tb-btn" data-cmd="redo" title="تکرار (Ctrl+Y)">↶</button>
        <span class="tb-sep"></span>
        <button class="tb-btn" data-cmd="bold" title="ضخیم"><b>B</b></button>
        <button class="tb-btn" data-cmd="italic" title="مورب"><i>I</i></button>
        <button class="tb-btn" data-cmd="underline" title="زیرخط"><u>U</u></button>
        <button class="tb-btn" data-cmd="strikeThrough" title="خط‌خورده"><s>S</s></button>
        <span class="tb-sep"></span>
        <select class="tb-select" data-tool="font" title="نوع فونت">
          <option value="">فونت</option>${FONTS.map(f => `<option value="${f}">${f}</option>`).join('')}
        </select>
        <select class="tb-select" data-tool="size" title="اندازه فونت">
          <option value="">اندازه</option>${SIZES.map(s => `<option value="${s.v}">${s.t}</option>`).join('')}
        </select>
        <select class="tb-select" data-tool="lh" title="فاصله خطوط">
          <option value="">فاصله خط</option>${LINE_HEIGHTS.map(s => `<option value="${s.v}">${s.t}</option>`).join('')}
        </select>
        <span class="tb-sep"></span>
        <button class="tb-btn" data-cmd="justifyRight" title="راست‌چین">⇥</button>
        <button class="tb-btn" data-cmd="justifyCenter" title="وسط‌چین">≡</button>
        <button class="tb-btn" data-cmd="justifyLeft" title="چپ‌چین">⇤</button>
        <button class="tb-btn" data-cmd="justifyFull" title="تراز دوطرفه">☰</button>
        <span class="tb-sep"></span>
        <button class="tb-btn" data-cmd="insertUnorderedList" title="فهرست نقطه‌ای">•</button>
        <button class="tb-btn" data-cmd="insertOrderedList" title="فهرست شماره‌دار">۱.</button>
        <span class="tb-sep"></span>
        <button class="tb-btn" data-tool="h" title="عنوان">H</button>
        <button class="tb-btn" data-tool="table" title="درج جدول">▦</button>
        <button class="tb-btn" data-tool="hr" title="خط جداکننده">—</button>
        <button class="tb-btn" data-tool="image" title="درج تصویر">▣</button>
        <span class="tb-sep"></span>
        <button class="tb-btn" data-tool="addrow" title="افزودن سطر به جدول">＋سطر</button>
        <button class="tb-btn" data-tool="addcol" title="افزودن ستون به جدول">＋ستون</button>
        <button class="tb-btn" data-tool="delrow" title="حذف سطر جدول">－سطر</button>
      </div>
      <div class="editor-area" contenteditable="true" spellcheck="false"></div>
    </div>`;
  const area = container.querySelector('.editor-area');
  if (initialHtml) area.innerHTML = initialHtml;
  else if (placeholder) area.innerHTML = `<p style="color:#94a3b8">${placeholder}</p>`;

  area.addEventListener('input', () => onChange && onChange(area.innerHTML));
  area.addEventListener('keydown', e => {
    if ((e.ctrlKey || e.metaKey) && e.key === 's') { e.preventDefault(); onChange && onChange(area.innerHTML, true); }
  });

  const tableActions = {
    addrow: () => { const td = currentCell(); if (!td) return toast('نشانگر را داخل جدول قرار دهید', 'warn'); const tr = td.parentElement.cloneNode(true); td.closest('table').appendChild(tr); fire(); },
    addcol: () => { const td = currentCell(); if (!td) return toast('نشانگر را داخل جدول قرار دهید', 'warn'); const idx = [...td.parentElement.children].indexOf(td); td.closest('table').querySelectorAll('tr').forEach(r => r.appendChild(r.children[idx]?.cloneNode(true) || document.createElement('td'))); fire(); },
    delrow: () => { const td = currentCell(); if (!td) return; const table = td.closest('table'); if (table.rows.length <= 1) { table.remove(); } else td.parentElement.remove(); fire(); },
  };
  function currentCell() {
    const sel = window.getSelection();
    if (!sel.rangeCount) return null;
    let n = sel.getRangeAt(0).startContainer;
    while (n && n.tagName !== 'TD' && n.tagName !== 'TH') n = n.parentElement;
    return n;
  }
  function fire() { onChange && onChange(area.innerHTML); }

  container.querySelector('.editor-toolbar').addEventListener('click', e => {
    const btn = e.target.closest('.tb-btn'); if (!btn) return;
    area.focus();
    const c = btn.dataset.cmd, tool = btn.dataset.tool;
    if (c) { cmd(c); fire(); return; }
    if (tool === 'h') { cmd('formatBlock', 'h3'); fire(); }
    else if (tool === 'hr') { cmd('insertHorizontalRule'); fire(); }
    else if (tool === 'image') { pickImage(area, fire); }
    else if (tool === 'table') {
      cmd('insertHTML', `<table><tr><th>عنوان</th><th>عنوان</th></tr><tr><td>&nbsp;</td><td>&nbsp;</td></tr><tr><td>&nbsp;</td><td>&nbsp;</td></tr></table><p></p>`);
      fire();
    }
    else if (tableActions[tool]) tableActions[tool]();
  });

  container.querySelector('.editor-toolbar').addEventListener('change', e => {
    const t = e.target.dataset.tool;
    area.focus();
    if (t === 'font' && e.target.value) { cmd('fontName', e.target.value); fire(); }
    else if (t === 'size' && e.target.value) { wrapSelection(`font-size:${{ '2': '12px', '3': '15px', '4': '18px', '5': '21px', '6': '25px' }[e.target.value]}`); fire(); }
    else if (t === 'lh' && e.target.value) { selectedBlocks(area).forEach(b => b.style.lineHeight = e.target.value); fire(); }
    e.target.value = '';
  });

  async function pickImage(area, fire) {
    const inp = document.createElement('input');
    inp.type = 'file'; inp.accept = 'image/png,image/jpeg';
    inp.onchange = async () => {
      if (!inp.files[0]) return;
      const fd = new FormData(); fd.append('file', inp.files[0]);
      try {
        const r = await api.upload('/api/uploads?kind=inline', fd);
        cmd('insertHTML', `<img src="${r.url}" style="max-width:100%">`);
        fire();
      } catch (err) { toast(err.message, 'error'); }
    };
    inp.click();
  }

  return {
    getHtml: () => area.innerHTML,
    setHtml: (h) => { area.innerHTML = h; },
    focus: () => area.focus(),
  };
}
