"""
یارنامه — اجرای نسخه توسعه (سرویس + مرورگر، بدون پنجره راه‌انداز).
استفاده: python run_dev.py [--port 8765]
"""
import argparse
import threading
import time
import webbrowser

import uvicorn

from app import config


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=config.DEFAULT_PORT)
    parser.add_argument("--no-browser", action="store_true")
    args = parser.parse_args()
    config.write_config({"port": args.port})

    if not args.no_browser:
        threading.Timer(1.8, lambda: webbrowser.open(f"http://127.0.0.1:{args.port}/")).start()

    uvicorn.run("app.main:app", host="127.0.0.1", port=args.port, log_level="info")


if __name__ == "__main__":
    main()
