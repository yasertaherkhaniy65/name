"""
یارنامه — اتصال SQLite، سیستم Migration کنترل‌شده و الگوی تراکنش امن.
- WAL برای همزمانی مطمئن
- کلیدهای خارجی همیشه فعال
- Migration ها در تراکنش جداگانه اجرا و در جدول schema_migrations ثبت می‌شوند.
"""
from __future__ import annotations

import sqlite3
from contextlib import contextmanager

from . import config

MIGRATIONS: list[tuple[int, str]] = [
    (1, """
CREATE TABLE IF NOT EXISTS organizations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    legal_form TEXT,
    national_id TEXT,
    economic_code TEXT,
    registration_no TEXT,
    address TEXT,
    postal_code TEXT,
    phone TEXT,
    email TEXT,
    website TEXT,
    logo_path TEXT,
    stamp_path TEXT,
    is_default INTEGER NOT NULL DEFAULT 1,
    is_active INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

CREATE TABLE IF NOT EXISTS contacts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    kind TEXT NOT NULL DEFAULT 'organization'
        CHECK (kind IN ('person','company','bank','government','organization','other')),
    name TEXT NOT NULL,
    company_name TEXT,
    salutation TEXT,
    position TEXT,
    national_id TEXT,
    economic_code TEXT,
    customer_no TEXT,
    address TEXT,
    postal_code TEXT,
    phone TEXT,
    email TEXT,
    notes TEXT,
    is_active INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE INDEX IF NOT EXISTS idx_contacts_name ON contacts(name);
CREATE INDEX IF NOT EXISTS idx_contacts_kind ON contacts(kind);

CREATE TABLE IF NOT EXISTS signatories (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    full_name TEXT NOT NULL,
    position TEXT NOT NULL,
    unit TEXT,
    signature_image_path TEXT,
    stamp_image_path TEXT,
    sort_order INTEGER NOT NULL DEFAULT 0,
    is_active INTEGER NOT NULL DEFAULT 1,
    notes TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

CREATE TABLE IF NOT EXISTS templates (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    category TEXT NOT NULL DEFAULT 'اداری و تجاری',
    description TEXT,
    body_html TEXT NOT NULL DEFAULT '',
    paper_size TEXT NOT NULL DEFAULT 'A4' CHECK (paper_size IN ('A4','A5')),
    orientation TEXT NOT NULL DEFAULT 'portrait' CHECK (orientation IN ('portrait','landscape')),
    margin_preset TEXT NOT NULL DEFAULT 'normal',
    org_id INTEGER REFERENCES organizations(id) ON DELETE SET NULL,
    default_signatory_id INTEGER REFERENCES signatories(id) ON DELETE SET NULL,
    is_system INTEGER NOT NULL DEFAULT 0,
    is_active INTEGER NOT NULL DEFAULT 1,
    sort_order INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE INDEX IF NOT EXISTS idx_templates_category ON templates(category);

CREATE TABLE IF NOT EXISTS template_fields (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    template_id INTEGER NOT NULL REFERENCES templates(id) ON DELETE CASCADE,
    field_key TEXT NOT NULL,
    label TEXT NOT NULL,
    field_type TEXT NOT NULL DEFAULT 'text',
    is_required INTEGER NOT NULL DEFAULT 0,
    default_value TEXT,
    help_text TEXT,
    group_name TEXT,
    options_json TEXT,
    validation_regex TEXT,
    source_type TEXT NOT NULL DEFAULT 'manual',
    sort_order INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    UNIQUE (template_id, field_key)
);
CREATE INDEX IF NOT EXISTS idx_template_fields_template ON template_fields(template_id);

CREATE TABLE IF NOT EXISTS number_sequences (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    prefix TEXT NOT NULL DEFAULT '',
    number_width INTEGER NOT NULL DEFAULT 4,
    separator TEXT NOT NULL DEFAULT '-',
    include_year INTEGER NOT NULL DEFAULT 1,
    year_prefix INTEGER NOT NULL DEFAULT 0,
    reset_yearly INTEGER NOT NULL DEFAULT 1,
    current_number INTEGER NOT NULL DEFAULT 0,
    last_year INTEGER,
    is_active INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

CREATE TABLE IF NOT EXISTS letters (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    letter_number TEXT UNIQUE,
    number_sequence_id INTEGER REFERENCES number_sequences(id) ON DELETE SET NULL,
    letter_year INTEGER,
    subject TEXT NOT NULL DEFAULT '',
    contact_id INTEGER REFERENCES contacts(id) ON DELETE SET NULL,
    template_id INTEGER REFERENCES templates(id) ON DELETE SET NULL,
    template_title_snapshot TEXT,
    body_html TEXT NOT NULL DEFAULT '',
    parameters_json TEXT NOT NULL DEFAULT '{}',
    contact_snapshot_json TEXT,
    status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','final','canceled')),
    paper_size TEXT NOT NULL DEFAULT 'A4' CHECK (paper_size IN ('A4','A5')),
    orientation TEXT NOT NULL DEFAULT 'portrait' CHECK (orientation IN ('portrait','landscape')),
    margin_preset TEXT NOT NULL DEFAULT 'normal',
    org_id INTEGER REFERENCES organizations(id) ON DELETE SET NULL,
    issued_date_iso TEXT,
    issued_date_jalali TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    finalized_at TEXT,
    canceled_at TEXT,
    cancel_reason TEXT,
    manually_edited INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_letters_status ON letters(status);
CREATE INDEX IF NOT EXISTS idx_letters_number ON letters(letter_number);
CREATE INDEX IF NOT EXISTS idx_letters_subject ON letters(subject);
CREATE INDEX IF NOT EXISTS idx_letters_year ON letters(letter_year);

CREATE TABLE IF NOT EXISTS letter_versions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    letter_id INTEGER NOT NULL REFERENCES letters(id) ON DELETE CASCADE,
    version_no INTEGER NOT NULL,
    body_html TEXT NOT NULL,
    parameters_json TEXT,
    note TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    UNIQUE (letter_id, version_no)
);
CREATE INDEX IF NOT EXISTS idx_letter_versions_letter ON letter_versions(letter_id);

CREATE TABLE IF NOT EXISTS letter_signatories (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    letter_id INTEGER NOT NULL REFERENCES letters(id) ON DELETE CASCADE,
    signatory_id INTEGER REFERENCES signatories(id) ON DELETE SET NULL,
    snapshot_name TEXT NOT NULL,
    snapshot_position TEXT NOT NULL,
    signature_image_path TEXT,
    stamp_image_path TEXT,
    sort_order INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_letter_signatories_letter ON letter_signatories(letter_id);

CREATE TABLE IF NOT EXISTS attachments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    letter_id INTEGER NOT NULL REFERENCES letters(id) ON DELETE CASCADE,
    file_name TEXT NOT NULL,
    stored_path TEXT NOT NULL,
    mime_type TEXT,
    file_size INTEGER NOT NULL DEFAULT 0,
    uploaded_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE INDEX IF NOT EXISTS idx_attachments_letter ON attachments(letter_id);

CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT,
    updated_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

CREATE TABLE IF NOT EXISTS audit_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    action TEXT NOT NULL,
    entity_type TEXT,
    entity_id INTEGER,
    details_json TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE INDEX IF NOT EXISTS idx_audit_created ON audit_logs(created_at);
"""),
]

# ------------------------------- اتصال -------------------------------

def connect(db_file=None) -> sqlite3.Connection:
    path = str(db_file or config.db_path())
    conn = sqlite3.connect(path, timeout=15, isolation_level=None,
                           check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA journal_mode = WAL")
    conn.execute("PRAGMA synchronous = NORMAL")
    return conn


@contextmanager
def transaction(conn: sqlite3.Connection):
    """تراکنش امن — در صورت خطا کل عملیات بازگردانی می‌شود."""
    conn.execute("BEGIN IMMEDIATE")
    try:
        yield conn
        conn.execute("COMMIT")
    except Exception:
        conn.execute("ROLLBACK")
        raise


def apply_migrations(conn: sqlite3.Connection) -> int:
    """اجرای مهاجرت‌های در انتظار؛ خروجی: نسخه فعلی اسکیمای دیتابیس."""
    conn.execute("""
        CREATE TABLE IF NOT EXISTS schema_migrations (
            version INTEGER PRIMARY KEY,
            applied_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
        )
    """)
    current = conn.execute("SELECT COALESCE(MAX(version),0) v FROM schema_migrations").fetchone()["v"]
    applied = 0
    for version, sql in MIGRATIONS:
        if version <= current:
            continue
        # executescript تراکنش صریح را می‌بندد؛ بنابراین BEGIN/COMMIT داخل خود اسکریپت قرار می‌گیرد
        conn.executescript(
            "BEGIN;\n" + sql +
            f"\nINSERT INTO schema_migrations (version) VALUES ({version});\nCOMMIT;")
        applied += 1
    return conn.execute("SELECT COALESCE(MAX(version),0) v FROM schema_migrations").fetchone()["v"]


def check_integrity(db_file=None) -> bool:
    conn = connect(db_file)
    try:
        row = conn.execute("PRAGMA integrity_check").fetchone()
        return row[0] == "ok"
    finally:
        conn.close()
