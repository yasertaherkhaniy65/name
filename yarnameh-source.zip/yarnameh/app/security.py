"""
یارنامه — لایه امنیت سرویس محلی.
- سرویس فقط روی 127.0.0.1 گوش می‌دهد (در main.py)
- کنترل Host و Origin برای درخواست‌های تغییردهنده داده (ضد CSRF)
- الزام Content-Type: application/json برای درخواست‌های JSON
- پاک‌سازی امن HTML نامه‌ها (حذف اسکریپت/رویدادهای خطرناک)
- اعتبارسنجی فایل‌های آپلودی (امضا/مهر/لوگو/پیوست) و محافظت در برابر Path Traversal
"""
from __future__ import annotations

import re
from html.parser import HTMLParser

ALLOWED_HOSTS = {"127.0.0.1", "localhost"}
SAFE_TAGS = {
    "p", "br", "div", "span", "b", "strong", "i", "em", "u", "s", "sub", "sup",
    "ul", "ol", "li", "table", "thead", "tbody", "tr", "td", "th",
    "h1", "h2", "h3", "h4", "h5", "h6", "blockquote", "hr", "a", "img", "font",
}
VOID_TAGS = {"br", "hr", "img"}
DROP_TAGS = {"script", "style", "iframe", "object", "embed", "form", "link", "meta", "base"}
SAFE_STYLE_RE = re.compile(
    r"^(?:[a-zA-Z-]+\s*:\s*[a-zA-Z0-9#.,%\s()\-'\"!_/]+;?\s*)+$"
)
DANGEROUS_STYLE_RE = re.compile(r"(expression\s*\(|javascript\s*:|url\s*\(\s*['\"]?\s*data\s*:)", re.I)
URL_RE = re.compile(r"^(https?:|/api/media/)", re.I)
IMAGE_URL_RE = re.compile(r"^(/api/media/[a-z]+/[a-f0-9]{32}\.(?:png|jpe?g))$", re.I)
NUMBER_RE = re.compile(r"^\d+$")


class _Sanitizer(HTMLParser):
    """پاک‌ساز HTML محدود برای متن نامه‌ها — متن آزاد ویرایش‌شده کاربر قبل از ذخیره پاک می‌شود."""

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.out: list[str] = []
        self.open_stack: list[str] = []

    def handle_starttag(self, tag, attrs):
        if tag in DROP_TAGS:
            # محتوای تگ‌های خطرناک به‌کلی نادیده گرفته می‌شود
            if tag not in VOID_TAGS:
                self.open_stack.append(("__drop__", tag))
            return
        if tag not in SAFE_TAGS:
            return
        clean_attrs = []
        for k, v in attrs:
            if k == "style":
                if v and SAFE_STYLE_RE.match(v.strip()) and not DANGEROUS_STYLE_RE.search(v):
                    clean_attrs.append(("style", v))
            elif k in ("href", "src"):
                if v and URL_RE.match(v.strip()) and "javascript:" not in v.lower():
                    clean_attrs.append((k, v))
            elif k == "alt":
                if v:
                    clean_attrs.append((k, v.replace('"', "'")[:120]))
        attr_str = "".join(f' {k}="{v}"' for k, v in clean_attrs)
        if tag in VOID_TAGS:
            self.out.append(f"<{tag}{attr_str}>")
        else:
            self.out.append(f"<{tag}{attr_str}>")
            self.open_stack.append((tag, tag))

    def handle_startendtag(self, tag, attrs):
        if tag in VOID_TAGS:
            self.handle_starttag(tag, attrs)
        elif tag in SAFE_TAGS:
            self.handle_starttag(tag, attrs)
            self.handle_endtag(tag)

    def handle_endtag(self, tag):
        if tag in VOID_TAGS or tag in DROP_TAGS or tag not in SAFE_TAGS:
            return
        # بستن ترتیبی: تا رسیدن به تگ بازشده، تگ‌های باز را می‌بندیم
        for i in range(len(self.open_stack) - 1, -1, -1):
            name, _ = self.open_stack[i]
            if name == tag:
                for j in range(len(self.open_stack) - 1, i - 1, -1):
                    closing = self.open_stack.pop()[0]
                    if closing != "__drop__":
                        self.out.append(f"</{closing}>")
                break

    def handle_data(self, data):
        if all(n == "__drop__" for n, _ in self.open_stack):
            return
        self.out.append(data)

    def result(self) -> str:
        while self.open_stack:
            closing = self.open_stack.pop()[0]
            if closing != "__drop__":
                self.out.append(f"</{closing}>")
        return "".join(self.out)


def sanitize_html(html: str) -> str:
    if not html:
        return ""
    s = _Sanitizer()
    s.feed(html)
    return s.result()


def sanitize_text(value: str | None, max_len: int = 4000) -> str:
    """متن ساده — تگ‌ها حذف و طول محدود می‌شود."""
    if not value:
        return ""
    text = re.sub(r"<[^>]*>", "", str(value))
    text = text.replace("\x00", "").strip()
    return text[:max_len]


# ------------------------ اعتبارسنجی فایل‌ها ------------------------

MAGIC_SIGNATURES = {
    b"\x89PNG\r\n\x1a\n": ".png",
    b"\xff\xd8\xff": ".jpg",
}
ALLOWED_ATTACHMENT_EXT = {".png", ".jpg", ".jpeg", ".pdf", ".zip"}
PDF_MAGIC = b"%PDF"


def detect_image_ext(head: bytes) -> str | None:
    for magic, ext in MAGIC_SIGNATURES.items():
        if head.startswith(magic):
            return ext
    return None


def is_valid_pdf(head: bytes) -> bool:
    return head.startswith(PDF_MAGIC)


def safe_media_name(kind: str, name: str) -> bool:
    """فقط الگوی نام امن media مجاز است — محافظت کامل در برابر Path Traversal."""
    return bool(re.fullmatch(rf"{re.escape(kind)}/[a-f0-9]{{32}}\.(?:png|jpe?g|pdf|zip)", f"{kind}/{name}"))


def filename_is_safe(name: str) -> bool:
    return bool(name) and not re.search(r"[\\/:*?\"<>|]|\.\.", name) and len(name) <= 150
