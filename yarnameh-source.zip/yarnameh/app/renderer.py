"""
یارنامه — موتور پارامترهای پویا و رندر متن نامه.
- جایگزینی امن متغیرها: مقدار هر پارامتر قبل از درج در HTML فرار (escape) می‌شود
- پارامترهای وابسته: فیلد از نوع contact/signatory/org متغیرهای فرعی تولید می‌کند
  (مثلاً {{receiver}} → {{receiver_address}}، {{receiver_phone}}، ...)
- اجرای ورودی کاربر به‌عنوان کد هرگز رخ نمی‌دهد (بدون eval، بدون HTML خام از مقدارها)
"""
from __future__ import annotations

import html
import json
import re
import sqlite3

from .security import sanitize_text
from .jdate import format_jalali, today_jalali

VAR_RE = re.compile(r"\{\{\s*([a-zA-Z0-9_]+)\s*\}\}")

CONTACT_ATTRS = ("name", "kind", "company_name", "salutation", "position", "national_id",
                 "economic_code", "customer_no", "address", "postal_code", "phone", "email")
SIGNATORY_ATTRS = ("full_name", "position", "unit")


class FieldError(Exception):
    def __init__(self, field_label: str, message: str):
        self.field_label = field_label
        super().__init__(message)


def _escape_value(v: str, multiline: bool = False) -> str:
    """فرار امن مقدار + تبدیل خط جدید به <br> در فیلدهای چندخطی."""
    esc = html.escape(str(v), quote=False).replace('"', "&quot;")
    if multiline:
        esc = esc.replace("\r\n", "\n").replace("\n", "<br>")
    return esc


def _format_amount(raw: str) -> str:
    digits = re.sub(r"[^\d]", "", str(raw))
    if not digits:
        return ""
    return f"{int(digits):,}"


def _format_number_fa(raw: str) -> str:
    digits = re.sub(r"[^\d]", "", str(raw))
    return digits


def build_value_map(conn: sqlite3.Connection, template: dict, params: dict,
                    for_finalize: bool = False) -> dict[str, str]:
    """
    ساخت نقشه کامل متغیر → مقدار امن (HTML).
    شامل: پارامترهای الگو + متغیرهای وابسته مخاطب/امضاکننده/سازمان + متغیرهای سیستمی.
    """
    values: dict[str, str] = {}
    fields = {f["field_key"]: f for f in template.get("fields", [])}

    for key, f in fields.items():
        ftype = f.get("field_type", "text")
        raw = params.get(key, f.get("default_value") or "")
        raw = "" if raw is None else str(raw)

        if ftype == "contact":
            contact = None
            if raw:
                try:
                    cid = int(raw)
                except ValueError:
                    cid = 0
                row = conn.execute("SELECT * FROM contacts WHERE id=?", (cid,)).fetchone()
                contact = dict(row) if row else None
            if contact:
                values[key] = _escape_value(contact["name"])
                for attr in CONTACT_ATTRS:
                    values[f"{key}_{attr}"] = _escape_value(contact.get(attr) or "", multiline=attr == "address")
                values[f"{key}_contact_line"] = _escape_value(
                    "، ".join(x for x in [contact.get("address"), contact.get("postal_code"),
                                           contact.get("phone")] if x))
            else:
                manual = str(params.get(f"{key}__manual", "") or "")
                values[key] = _escape_value(manual, multiline=True)
                for attr in CONTACT_ATTRS:
                    values[f"{key}_{attr}"] = ""
            continue

        if ftype == "signatory":
            sig = None
            if raw:
                try:
                    sid = int(raw)
                except ValueError:
                    sid = 0
                row = conn.execute("SELECT * FROM signatories WHERE id=?", (sid,)).fetchone()
                sig = dict(row) if row else None
            if sig:
                values[key] = _escape_value(sig["full_name"])
                for attr in SIGNATORY_ATTRS:
                    values[f"{key}_{attr}"] = _escape_value(sig.get(attr) or "")
            else:
                values[key] = _escape_value(str(params.get(f"{key}__manual", "") or ""))
                for attr in SIGNATORY_ATTRS:
                    values[f"{key}_{attr}"] = ""
            continue

        if ftype == "org":
            from .dal.misc import get_default_org
            org = get_default_org(conn) or {}
            values[key] = _escape_value(org.get("name", ""))
            for attr in ("name", "national_id", "economic_code", "address", "postal_code",
                         "phone", "email", "website", "registration_no"):
                values[f"{key}_{attr}"] = _escape_value(org.get(attr) or "", multiline=attr == "address")
            continue

        if ftype == "bool":
            values[key] = "بله" if str(raw).lower() in ("1", "true", "yes", "بله") else "خیر"
            continue

        if ftype == "amount":
            values[key] = _escape_value(_format_amount(raw))
            continue

        if ftype == "number" or ftype == "id_no" or ftype == "phone":
            values[key] = _escape_value(_format_number_fa(raw) or raw)
            continue

        if ftype == "jalali_date":
            from .jdate import validate_jalali_str
            parsed = validate_jalali_str(raw)
            if parsed:
                values[key] = _escape_value(format_jalali(*parsed, style="long"))
                values[f"{key}_numeric"] = _escape_value(format_jalali(*parsed, style="numeric"))
            else:
                values[key] = _escape_value(raw)
                values[f"{key}_numeric"] = _escape_value(raw)
            continue

        if ftype == "multiselect":
            opts = params.get(f"{key}__multi") or ([] if not raw else [raw])
            if isinstance(opts, str):
                try:
                    opts = json.loads(opts)
                except Exception:
                    opts = [opts]
            joined = "، ".join(str(o) for o in opts if str(o))
            values[key] = _escape_value(joined, multiline=True)
            continue

        if ftype == "attachments_list":
            values[key] = _escape_value(raw, multiline=True)
            continue

        # text / textarea / select / notes
        values[key] = _escape_value(raw, multiline=ftype in ("textarea", "notes"))

    # متغیرهای سیستمی — در پیش‌نویس با نقطه‌چین نمایش داده می‌شوند
    if for_finalize:
        values.setdefault("letter_number", "")
        values.setdefault("letter_date", "")
    else:
        values.setdefault("letter_number", "&#8230;&#8230;&#8230;")
        values.setdefault("letter_date", "&#8230;&#8230;&#8230;")

    jy, jm, jd = today_jalali()
    values.setdefault("today_jalali", _escape_value(format_jalali(jy, jm, jd, style="long")))
    return values


def validate_params(template: dict, params: dict) -> tuple[dict, list[str]]:
    """اعتبارسنجی سمت سرور پارامترها؛ خروجی: (پارامترهای پاک‌سازی‌شده، خطاها)."""
    errors: list[str] = []
    clean: dict = {}
    for f in template.get("fields", []):
        key = f["field_key"]
        ftype = f.get("field_type", "text")
        raw = params.get(key)
        raw = "" if raw is None else str(raw).strip()
        if ftype == "multiselect":
            mv = params.get(f"{key}__multi")
            if mv is not None and isinstance(mv, list):
                clean[f"{key}__multi"] = [sanitize_text(str(x), 200) for x in mv][:30]
        required = bool(f.get("is_required"))
        if required and not raw:
            # فیلد مخاطب می‌تواند مقدار دستی داشته باشد
            if ftype == "contact" and params.get(f"{key}__manual"):
                raw = str(params[f"{key}__manual"])
            elif ftype == "signatory" and params.get(f"{key}__manual"):
                raw = str(params[f"{key}__manual"])
        if required and not raw and not clean.get(f"{key}__multi"):
            errors.append(f"«{f['label']}» الزامی است")
            continue
        if not raw:
            clean[key] = str(f.get("default_value") or "")
            continue
        if f.get("validation_regex"):
            try:
                if not re.fullmatch(f["validation_regex"], raw):
                    errors.append(f"قالب «{f['label']}» صحیح نیست")
                    continue
            except re.error:
                pass
        if ftype in ("text", "select", "jalali_date"):
            if ftype == "jalali_date":
                from .jdate import validate_jalali_str
                if validate_jalali_str(raw) is None:
                    errors.append(f"تاریخ «{f['label']}» معتبر نیست")
                    continue
            clean[key] = sanitize_text(raw, 300)
        elif ftype in ("textarea", "notes", "attachments_list"):
            clean[key] = sanitize_text(raw, 5000)
        elif ftype == "number":
            clean[key] = re.sub(r"[^\d]", "", raw)[:18]
        elif ftype == "amount":
            clean[key] = re.sub(r"[^\d]", "", raw)[:18]
        elif ftype in ("id_no", "phone"):
            clean[key] = sanitize_text(raw, 40)
        elif ftype == "bool":
            clean[key] = "1" if str(raw).lower() in ("1", "true", "yes", "بله") else "0"
        elif ftype == "contact":
            manual = str(params.get(f"{key}__manual", "") or "")
            clean[f"{key}__manual"] = sanitize_text(manual, 300)
            if raw:
                try:
                    clean[key] = str(int(raw))
                except ValueError:
                    errors.append(f"مخاطب «{f['label']}» نامعتبر است")
            elif not manual and required:
                errors.append(f"«{f['label']}» الزامی است")
        elif ftype == "signatory":
            manual = str(params.get(f"{key}__manual", "") or "")
            clean[f"{key}__manual"] = sanitize_text(manual, 200)
            if raw:
                try:
                    clean[key] = str(int(raw))
                except ValueError:
                    errors.append(f"امضاکننده «{f['label']}» نامعتبر است")
        elif ftype == "org":
            clean[key] = "1"
        else:
            clean[key] = sanitize_text(raw, 1000)
    # حفظ مقدارهای اضافه‌ای که در فرم بودند ولی فیلد الگو حذف شده (برای سوابق)
    return clean, errors


def _derive_blocks(template: dict) -> dict[str, str]:
    """
    بلوک‌های شرطی: متغیرهای «KEY_block» — اگر فیلد KEY خالی باشد کل بلوک از متن حذف می‌شود.
    الگوهای آماده تعریف اختصاصی دارند (رجیستری seed)؛ برای الگوهای کاربر «عنوان فیلد: مقدار» ساخته می‌شود.
    """
    blocks = dict(template.get("blocks") or {})
    if not blocks and template.get("title"):
        from .seed import SEED_BLOCKS
        blocks = dict(SEED_BLOCKS.get(template["title"]) or {})
    for f in template.get("fields", []):
        key = f["field_key"]
        bkey = f"{key}_block"
        if bkey in blocks or f.get("is_required"):
            continue
        if f.get("field_type") in ("contact", "signatory", "org", "bool", "multiselect"):
            continue
        blocks[bkey] = f"<p>{html.escape(f['label'])}: {{{key}}}</p>"
    return blocks


def _substitute_blocks(body: str, template: dict, values: dict[str, str]) -> str:
    blocks = _derive_blocks(template)

    def block_repl(m: re.Match) -> str:
        key = m.group(1)
        if key in values:
            return values[key]
        if key in blocks:
            btpl = blocks[key]
            referenced = set(VAR_RE.findall(btpl))
            if referenced and all(values.get(k) for k in referenced):
                return VAR_RE.sub(lambda mm: values.get(mm.group(1), mm.group(0)), btpl)
            return ""
        return m.group(0)

    return VAR_RE.sub(block_repl, body)


def render_body(template: dict, values: dict[str, str]) -> str:
    """جایگزینی متغیرها و بلوک‌های شرطی در متن الگو — مقادیر از قبل امن (escape) شده‌اند."""
    body = template.get("body_html", "") or ""
    return _substitute_blocks(body, template, values)


def collect_letter_signatories(conn: sqlite3.Connection, template: dict, params: dict) -> list[dict]:
    """امضاکنندگان انتخابی نامه (بر اساس فیلدهای نوع signatory یا پیش‌فرض الگو)."""
    sigs: list[dict] = []
    seen: set[int] = set()
    for f in template.get("fields", []):
        if f.get("field_type") != "signatory":
            continue
        raw = str(params.get(f["field_key"], "") or "")
        if raw and raw.isdigit():
            sid = int(raw)
            if sid in seen:
                continue
            row = conn.execute("SELECT * FROM signatories WHERE id=? AND is_active=1", (sid,)).fetchone()
            if row:
                seen.add(sid)
                s = dict(row)
                sigs.append({
                    "signatory_id": s["id"], "snapshot_name": s["full_name"],
                    "snapshot_position": s["position"] or "",
                    "signature_image_path": s.get("signature_image_path"),
                    "stamp_image_path": s.get("stamp_image_path"),
                })
    if not sigs and template.get("default_signatory_id"):
        row = conn.execute("SELECT * FROM signatories WHERE id=?", (template["default_signatory_id"],)).fetchone()
        if row:
            s = dict(row)
            sigs.append({
                "signatory_id": s["id"], "snapshot_name": s["full_name"],
                "snapshot_position": s["position"] or "",
                "signature_image_path": s.get("signature_image_path"),
                "stamp_image_path": s.get("stamp_image_path"),
            })
    return sigs
