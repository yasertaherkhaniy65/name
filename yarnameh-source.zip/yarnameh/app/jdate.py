"""
یارنامه — تبدیل دقیق تاریخ شمسی (جلالی) به میلادی و برعکس.
پورت پایتونیِ الگوریتم استاندارد jalaali (MIT) با آزمون‌های تاریخ معلوم.
"""
from __future__ import annotations

from datetime import date

BREAKS = [-61, 9, 38, 199, 426, 686, 756, 818, 1111, 1181, 1210,
          1635, 2060, 2097, 2192, 2262, 2324, 2394, 2456, 3178]


def _div(a: int, b: int) -> int:
    return int(a / b)


def _mod(a: int, b: int) -> int:
    return a - int(a / b) * b


def _jal_cal(jy: int):
    """بازگرداندن (کبیسه بودن، سال میلادی آغاز سال جلالی، روز ۱ فروردین میلادی، nd)."""
    bl = len(BREAKS)
    gy = jy + 621
    leap_j = -14
    jp = BREAKS[0]
    if jy < jp or jy >= BREAKS[bl - 1]:
        raise ValueError(f"سال شمسی خارج از محدوده پشتیبانی است: {jy}")
    jump = 0
    for i in range(1, bl):
        jm = BREAKS[i]
        jump = jm - jp
        if jy < jm:
            break
        leap_j = leap_j + _div(jump, 33) * 8 + _div(_mod(jump, 33), 4)
        jp = jm
    n = jy - jp
    leap_j = leap_j + _div(n, 33) * 8 + _div(_mod(n, 33) + 3, 4)
    # شمارش سال‌های کبیسه میلادی تا سال gy (برای تعیین دقیق ۱ فروردین)
    leap_g = _div(gy, 4) - _div((_div(gy, 100) + 1) * 3, 4) - 150
    march = 20 + leap_j - leap_g
    if jump - n < 6:
        n = n - jump + _div(jump + 4, 33) * 33
    leap = _mod(_mod(n + 1, 33) - 1, 4)
    if leap == -1:
        leap = 4
    return leap, gy, march


def _g2d(gy: int, gm: int, gd: int) -> int:
    d = _div((gy + _div(gm - 8, 6) + 100100) * 1461, 4) \
        + _div(153 * _mod(gm + 9, 12) + 2, 5) + gd - 34840408
    d = d - _div(_div(gy + 100100 + _div(gm - 8, 6), 100) * 3, 4) + 752
    return d


def _d2g(jdn: int):
    j = 4 * jdn + 139361631
    j = j + _div(_div(4 * jdn + 183187720, 146097) * 3, 4) * 4 - 3908
    i = _div(_mod(j, 1461), 4) * 5 + 308
    gd = _div(_mod(i, 153), 5) + 1
    gm = _mod(_div(i, 153), 12) + 1
    gy = _div(j, 1461) - 100100 + _div(8 - gm, 6)
    return gy, gm, gd


def is_leap_jalali(jy: int) -> bool:
    return _jal_cal(jy)[0] == 0


def jalali_month_length(jy: int, jm: int) -> int:
    if jm <= 6:
        return 31
    if jm <= 11:
        return 30
    return 30 if is_leap_jalali(jy) else 29


def gregorian_to_jalali(gy: int, gm: int, gd: int):
    jdn = _g2d(gy, gm, gd)
    return _d2j(jdn)


def jalali_to_gregorian(jy: int, jm: int, jd: int):
    jdn = _j2d(jy, jm, jd)
    return _d2g(jdn)


def _d2j(jdn: int):
    gy = _d2g(jdn)[0]
    jy = gy - 621
    leap, _gy, march = _jal_cal(jy)
    jdn1f = _g2d(gy, 3, march)
    k = jdn - jdn1f
    if k >= 0:
        if k <= 185:
            return jy, 1 + _div(k, 31), _mod(k, 31) + 1
        k -= 186
    else:
        jy -= 1
        k += 179
        if leap == 1:
            k += 1
    return jy, 7 + _div(k, 30), _mod(k, 30) + 1


def _j2d(jy: int, jm: int, jd: int) -> int:
    leap, gy, march = _jal_cal(jy)
    return _g2d(gy, 3, march) + (jm - 1) * 31 - _div(jm, 7) * (jm - 7) + jd - 1


JALALI_MONTHS = ["فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
                 "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"]
JALALI_WEEKDAYS = ["شنبه", "یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه"]


def today_jalali() -> tuple[int, int, int]:
    t = date.today()
    return gregorian_to_jalali(t.year, t.month, t.day)


def format_jalali(jy: int, jm: int, jd: int, style: str = "long") -> str:
    """style: long = ۳ آبان ۱۴۰۵ | numeric = ۱۴۰۵/۰۸/۰۳"""
    if style == "numeric":
        return f"{jy:04d}/{jm:02d}/{jd:02d}"
    return f"{jd} {JALALI_MONTHS[jm - 1]} {jy}"


def iso_to_jalali_str(iso_date: str, style: str = "numeric") -> str:
    y, m, d = (int(x) for x in iso_date.split("-"))
    jy, jm, jd = gregorian_to_jalali(y, m, d)
    return format_jalali(jy, jm, jd, style)


def weekday_jalali(jy: int, jm: int, jd: int) -> int:
    """۰=شنبه ... ۶=جمعه"""
    gy, gm, gd = jalali_to_gregorian(jy, jm, jd)
    py_weekday = date(gy, gm, gd).weekday()  # 0=Monday
    return (py_weekday + 1) % 7


def validate_jalali_str(s: str) -> tuple[int, int, int] | None:
    """اعتبارسنجی رشته تاریخ شمسی YYYY/MM/DD یا YYYY-MM-DD؛ خروجی (jy, jm, jd) یا None."""
    s = s.strip().replace("-", "/")
    parts = s.split("/")
    if len(parts) != 3:
        return None
    try:
        jy, jm, jd = (int(p) for p in parts)
    except ValueError:
        return None
    if jy < 1300 or jy > 1500 or jm < 1 or jm > 12 or jd < 1:
        return None
    if jd > jalali_month_length(jy, jm):
        return None
    return jy, jm, jd


FA_DIGITS = "۰۱۲۳۴۵۶۷۸۹"


def to_fa_digits(s: str | int) -> str:
    return str(s).translate(str.maketrans("0123456789", FA_DIGITS))
