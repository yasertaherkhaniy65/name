"""DAL نامه‌ها: پیش‌نویس، نسخه‌های مستقل، ثبت نهایی با شماره‌گذاری تراکنشی، ابطال، کپی."""
from __future__ import annotations

import json
import sqlite3

from ..jdate import today_jalali, jalali_to_gregorian


# ------------------------------ شماره‌گذاری ------------------------------

def list_sequences(conn) -> list[dict]:
    rows = conn.execute("SELECT * FROM number_sequences ORDER BY is_active DESC, id").fetchall()
    return [dict(r) for r in rows]


def get_sequence(conn, sid: int) -> dict | None:
    row = conn.execute("SELECT * FROM number_sequences WHERE id=?", (sid,)).fetchone()
    return dict(row) if row else None


def create_sequence(conn, d: dict) -> int:
    cur = conn.execute(
        """INSERT INTO number_sequences (name, prefix, number_width, separator, include_year,
           year_prefix, reset_yearly, is_active) VALUES (?,?,?,?,?,?,?,?)""",
        (d["name"], d.get("prefix", ""), d.get("number_width", 4), d.get("separator", "-"),
         1 if d.get("include_year", True) else 0, 1 if d.get("year_prefix", False) else 0,
         1 if d.get("reset_yearly", True) else 0, 1 if d.get("is_active", True) else 0))
    return cur.lastrowid


def update_sequence(conn, sid: int, d: dict) -> bool:
    cur = conn.execute(
        """UPDATE number_sequences SET name=?, prefix=?, number_width=?, separator=?,
           include_year=?, year_prefix=?, reset_yearly=?, is_active=? WHERE id=?""",
        (d["name"], d.get("prefix", ""), d.get("number_width", 4), d.get("separator", "-"),
         1 if d.get("include_year", True) else 0, 1 if d.get("year_prefix", False) else 0,
         1 if d.get("reset_yearly", True) else 0, 1 if d.get("is_active", True) else 0, sid))
    return cur.rowcount > 0


def _build_number(seq: dict, number: int, jy: int) -> str:
    parts = []
    if seq["prefix"]:
        parts.append(seq["prefix"])
    if seq["include_year"]:
        parts.append(str(jy))
    parts.append(str(number).zfill(seq["number_width"]))
    return seq["separator"].join(parts)


def allocate_number(conn: sqlite3.Connection, seq_id: int) -> tuple[str, int]:
    """
    تخصیص شماره یکتا در تراکنش امن (BEGIN IMMEDIATE + به‌روزرسانی شرطی).
    شماره فقط در زمان ثبت نهایی صادر می‌شود؛ پیش‌نویس‌ها شماره نمی‌گیرند.
    """
    jy, _, _ = today_jalali()
    with conn:
        conn.execute("BEGIN IMMEDIATE")
        try:
            seq = conn.execute("SELECT * FROM number_sequences WHERE id=?", (seq_id,)).fetchone()
            if not seq:
                raise ValueError("شماره‌گذار یافت نشد")
            seq = dict(seq)
            current = seq["current_number"]
            if seq["reset_yearly"] and seq["last_year"] != jy:
                current = 0
            new_number = current + 1
            candidate = _build_number(seq, new_number, jy)
            # اطمینان از یکتایی (شماره ابطال‌شده‌ها هم حفظ می‌شوند و آزاد نمی‌گردند)
            while conn.execute("SELECT 1 FROM letters WHERE letter_number=?", (candidate,)).fetchone():
                new_number += 1
                candidate = _build_number(seq, new_number, jy)
            conn.execute(
                "UPDATE number_sequences SET current_number=?, last_year=? WHERE id=?",
                (new_number, jy, seq_id))
            conn.execute("COMMIT")
            return candidate, jy
        except Exception:
            conn.execute("ROLLBACK")
            raise


def sequence_preview(conn, seq_id: int) -> str:
    seq = get_sequence(conn, seq_id)
    if not seq:
        return ""
    jy, _, _ = today_jalali()
    next_no = seq["current_number"] + 1
    if seq["reset_yearly"] and seq["last_year"] != jy:
        next_no = 1
    return _build_number(seq, next_no, jy)


# ------------------------------ نامه‌ها ------------------------------

def list_letters(conn, q: str = "", status: str = "", year: str = "", contact_id: int = 0,
                 template_id: int = 0, from_jalali: str = "", to_jalali: str = "",
                 page: int = 1, page_size: int = 20) -> dict:
    where, args = [], []
    if q:
        where.append("""(subject LIKE ? OR letter_number LIKE ? OR body_html LIKE ?
                         OR contact_id IN (SELECT id FROM contacts WHERE name LIKE ?)
                         OR template_title_snapshot LIKE ?)""")
        like = f"%{q}%"
        args += [like, like, like, like, like]
    if status in ("draft", "final", "canceled"):
        where.append("status = ?")
        args.append(status)
    if year:
        where.append("letter_year = ?")
        args.append(int(year))
    if contact_id:
        where.append("contact_id = ?")
        args.append(contact_id)
    if template_id:
        where.append("template_id = ?")
        args.append(template_id)
    if from_jalali:
        where.append("issued_date_jalali >= ?")
        args.append(from_jalali)
    if to_jalali:
        where.append("issued_date_jalali <= ?")
        args.append(to_jalali)
    wsql = ("WHERE " + " AND ".join(where)) if where else ""
    total = conn.execute(f"SELECT COUNT(*) c FROM letters {wsql}", args).fetchone()["c"]
    rows = conn.execute(
        f"""SELECT l.id, l.letter_number, l.subject, l.status, l.letter_year,
                   l.issued_date_jalali, l.created_at, l.updated_at, l.paper_size,
                   l.template_id, l.template_title_snapshot, l.contact_id,
                   c.name AS contact_name, l.manually_edited
            FROM letters l LEFT JOIN contacts c ON c.id = l.contact_id {wsql}
            ORDER BY CASE l.status WHEN 'draft' THEN 0 ELSE 1 END, l.id DESC
            LIMIT ? OFFSET ?""", args + [page_size, (page - 1) * page_size]).fetchall()
    return {"items": [dict(r) for r in rows], "total": total, "page": page, "page_size": page_size}


def get_letter(conn, lid: int) -> dict | None:
    row = conn.execute(
        """SELECT l.*, c.name AS contact_name FROM letters l
           LEFT JOIN contacts c ON c.id = l.contact_id WHERE l.id=?""", (lid,)).fetchone()
    if not row:
        return None
    letter = dict(row)
    letter["parameters"] = json.loads(letter.pop("parameters_json") or "{}")
    if letter.get("contact_snapshot_json"):
        letter["contact_snapshot"] = json.loads(letter.pop("contact_snapshot_json"))
    else:
        letter.pop("contact_snapshot_json", None)
    sigs = conn.execute(
        "SELECT * FROM letter_signatories WHERE letter_id=? ORDER BY sort_order, id", (lid,)).fetchall()
    letter["signatories"] = [dict(s) for s in sigs]
    atts = conn.execute("SELECT id, file_name, stored_path, mime_type, file_size, uploaded_at "
                        "FROM attachments WHERE letter_id=?", (lid,)).fetchall()
    letter["attachments"] = [dict(a) for a in atts]
    versions = conn.execute(
        "SELECT id, version_no, note, created_at FROM letter_versions WHERE letter_id=? ORDER BY version_no DESC",
        (lid,)).fetchall()
    letter["versions"] = [dict(v) for v in versions]
    return letter


def get_version_body(conn, lid: int, vid: int) -> dict | None:
    row = conn.execute("SELECT * FROM letter_versions WHERE letter_id=? AND id=?", (lid, vid)).fetchone()
    return dict(row) if row else None


def create_letter(conn, d: dict) -> int:
    """ایجاد پیش‌نویس یا نامه؛ نسخه اولیه متن هم‌زمان ذخیره می‌شود."""
    cur = conn.execute(
        """INSERT INTO letters (subject, contact_id, template_id, template_title_snapshot, body_html,
           parameters_json, contact_snapshot_json, status, paper_size, orientation, margin_preset, org_id,
           manually_edited)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        (d.get("subject", ""), d.get("contact_id"), d.get("template_id"),
         d.get("template_title_snapshot"), d.get("body_html", ""),
         json.dumps(d.get("parameters") or {}, ensure_ascii=False),
         d.get("contact_snapshot_json"), d.get("status", "draft"),
         d.get("paper_size", "A4"), d.get("orientation", "portrait"),
         d.get("margin_preset", "normal"), d.get("org_id"), d.get("manually_edited", 0)))
    lid = cur.lastrowid
    conn.execute(
        "INSERT INTO letter_versions (letter_id, version_no, body_html, parameters_json, note) "
        "VALUES (?,1,?,?,?)",
        (lid, d.get("body_html", ""), json.dumps(d.get("parameters") or {}, ensure_ascii=False),
         d.get("version_note", "نسخه اولیه")))
    for i, s in enumerate(d.get("signatories") or []):
        conn.execute(
            """INSERT INTO letter_signatories (letter_id, signatory_id, snapshot_name, snapshot_position,
               signature_image_path, stamp_image_path, sort_order) VALUES (?,?,?,?,?,?,?)""",
            (lid, s.get("signatory_id"), s["snapshot_name"], s.get("snapshot_position", ""),
             s.get("signature_image_path"), s.get("stamp_image_path"), i))
    return lid


def update_letter(conn, lid: int, d: dict) -> bool:
    """به‌روزرسانی پیش‌نویس (ویرایش خودکار/دستی). نامه ثبت‌شده از این مسیر تغییر نمی‌کند."""
    cur = conn.execute(
        """UPDATE letters SET subject=?, contact_id=?, body_html=?, parameters_json=?,
           paper_size=?, orientation=?, margin_preset=?, manually_edited=?,
           updated_at=datetime('now','localtime') WHERE id=? AND status='draft'""",
        (d.get("subject", ""), d.get("contact_id"), d.get("body_html", ""),
         json.dumps(d.get("parameters") or {}, ensure_ascii=False),
         d.get("paper_size", "A4"), d.get("orientation", "portrait"),
         d.get("margin_preset", "normal"), d.get("manually_edited", 0), lid))
    if cur.rowcount and d.get("update_signatories"):
        conn.execute("DELETE FROM letter_signatories WHERE letter_id=?", (lid,))
        for i, s in enumerate(d.get("signatories") or []):
            conn.execute(
                """INSERT INTO letter_signatories (letter_id, signatory_id, snapshot_name, snapshot_position,
                   signature_image_path, stamp_image_path, sort_order) VALUES (?,?,?,?,?,?,?)""",
                (lid, s.get("signatory_id"), s["snapshot_name"], s.get("snapshot_position", ""),
                 s.get("signature_image_path"), s.get("stamp_image_path"), i))
    return cur.rowcount > 0


def save_version(conn, lid: int, note: str, body_html: str, parameters: dict) -> int:
    """ذخیره نسخه جدید (مثلاً قبل از بازتولید متن) — نسخه‌ها مستقل و قابل بازیابی‌اند."""
    row = conn.execute("SELECT COALESCE(MAX(version_no),0) m FROM letter_versions WHERE letter_id=?",
                       (lid,)).fetchone()
    vno = row["m"] + 1
    conn.execute(
        "INSERT INTO letter_versions (letter_id, version_no, body_html, parameters_json, note) "
        "VALUES (?,?,?,?,?)",
        (lid, vno, body_html, json.dumps(parameters or {}, ensure_ascii=False), note))
    return vno


def finalize_letter(conn, lid: int, seq_id: int, issue_jalali: tuple[int, int, int]) -> dict:
    """
    ثبت نهایی: تخصیص شماره در تراکنش، جداسازی تاریخ صدور از زمان ثبت،
    ذخیره نسخه نهایی مستقل و اسنپ‌شات مخاطب. متن نامه پس از این مرحله تغییرناپذیر است.
    """
    row = conn.execute("SELECT * FROM letters WHERE id=?", (lid,)).fetchone()
    if not row:
        raise ValueError("نامه یافت نشد")
    letter = dict(row)
    if letter["status"] != "draft":
        raise ValueError("فقط پیش‌نویس‌ها قابل ثبت نهایی هستند")
    jy, jm, jd = issue_jalali
    gy, gm, gd = jalali_to_gregorian(jy, jm, jd)
    issued_iso = f"{gy:04d}-{gm:02d}-{gd:02d}"
    # قالب خط‌تیره برای مرتب‌سازی و فیلتر واژگانی درست (۱۴۰۵-۰۸-۰۳)
    issued_jalali_str = f"{jy:04d}-{jm:02d}-{jd:02d}"

    number, year = allocate_number(conn, seq_id)
    snapshot = conn.execute(
        """SELECT json_object('name',c.name,'kind',c.kind,'company_name',c.company_name,
             'salutation',c.salutation,'position',c.position,'address',c.address,
             'postal_code',c.postal_code,'phone',c.phone,'email',c.email,
             'national_id',c.national_id,'economic_code',c.economic_code) j
           FROM contacts c WHERE c.id=?""", (letter["contact_id"],)).fetchone()
    with conn:
        conn.execute("BEGIN IMMEDIATE")
        try:
            conn.execute(
                """UPDATE letters SET status='final', letter_number=?, letter_year=?,
                   issued_date_iso=?, issued_date_jalali=?,
                   contact_snapshot_json=COALESCE(?, contact_snapshot_json),
                   finalized_at=datetime('now','localtime'),
                   updated_at=datetime('now','localtime') WHERE id=? AND status='draft'""",
                (number, year, issued_iso, issued_jalali_str, snapshot["j"] if snapshot and snapshot["j"] else None, lid))
            if conn.total_changes and conn.execute("SELECT changes() ch").fetchone()["ch"] == 0:
                raise ValueError("نامه هم‌زمان تغییر کرده است")
            conn.execute(
                "INSERT INTO letter_versions (letter_id, version_no, body_html, parameters_json, note) "
                "VALUES (?, (SELECT COALESCE(MAX(version_no),0)+1 FROM letter_versions WHERE letter_id=?), ?, ?, ?)",
                (lid, lid, letter["body_html"], letter["parameters_json"], "نسخه نهایی ثبت‌شده"))
            conn.execute("COMMIT")
        except Exception:
            conn.execute("ROLLBACK")
            raise
    return {"letter_number": number, "letter_year": year, "issued_date_jalali": issued_jalali_str}


def cancel_letter(conn, lid: int, reason: str) -> bool:
    """ابطال با ثبت علت — شماره نامه ابطال‌شده حفظ می‌شود و آزاد نمی‌گردد."""
    cur = conn.execute(
        """UPDATE letters SET status='canceled', cancel_reason=?, canceled_at=datetime('now','localtime'),
           updated_at=datetime('now','localtime') WHERE id=? AND status='final'""",
        (reason, lid))
    return cur.rowcount > 0


def copy_letter(conn, lid: int) -> int | None:
    """کپی نامه قبلی برای ایجاد نامه جدید — خروجی همیشه پیش‌نویس بدون شماره است."""
    row = conn.execute("SELECT * FROM letters WHERE id=?", (lid,)).fetchone()
    if not row:
        return None
    src = dict(row)
    sigs = conn.execute(
        "SELECT * FROM letter_signatories WHERE letter_id=? ORDER BY sort_order, id", (lid,)).fetchall()
    new_id = create_letter(conn, {
        "subject": src["subject"], "contact_id": src["contact_id"], "template_id": src["template_id"],
        "template_title_snapshot": src["template_title_snapshot"], "body_html": src["body_html"],
        "parameters": json.loads(src["parameters_json"] or "{}"),
        "contact_snapshot_json": src["contact_snapshot_json"], "status": "draft",
        "paper_size": src["paper_size"], "orientation": src["orientation"],
        "margin_preset": src["margin_preset"], "org_id": src["org_id"],
        "version_note": "کپی از نامه شماره " + (src["letter_number"] or "—"),
        "signatories": [dict(s) for s in sigs],
    })
    return new_id


def set_letter_attachments_text(conn, lid: int):
    pass  # پیوست‌ها از طریق جدول attachments مدیریت می‌شوند


def add_attachment(conn, lid: int, file_name: str, stored_path: str, mime: str, size: int) -> int:
    cur = conn.execute(
        "INSERT INTO attachments (letter_id, file_name, stored_path, mime_type, file_size) VALUES (?,?,?,?,?)",
        (lid, file_name, stored_path, mime, size))
    return cur.lastrowid


def get_attachment(conn, aid: int):
    row = conn.execute("SELECT * FROM attachments WHERE id=?", (aid,)).fetchone()
    return dict(row) if row else None


def delete_attachment(conn, aid: int) -> bool:
    cur = conn.execute("DELETE FROM attachments WHERE id=?", (aid,))
    return cur.rowcount > 0


def dashboard_stats(conn) -> dict:
    jy, jm, _ = today_jalali()
    total_final = conn.execute("SELECT COUNT(*) c FROM letters WHERE status='final'").fetchone()["c"]
    month_letters = conn.execute(
        "SELECT COUNT(*) c FROM letters WHERE status='final' AND letter_year=? AND "
        "CAST(substr(issued_date_jalali,6,2) AS INTEGER)=?", (jy, jm)).fetchone()["c"]
    drafts = conn.execute("SELECT COUNT(*) c FROM letters WHERE status='draft'").fetchone()["c"]
    canceled = conn.execute("SELECT COUNT(*) c FROM letters WHERE status='canceled'").fetchone()["c"]
    contacts = conn.execute("SELECT COUNT(*) c FROM contacts WHERE is_active=1").fetchone()["c"]
    templates = conn.execute("SELECT COUNT(*) c FROM templates WHERE is_active=1").fetchone()["c"]
    signatories = conn.execute("SELECT COUNT(*) c FROM signatories WHERE is_active=1").fetchone()["c"]
    last_letters = conn.execute(
        """SELECT l.id, l.letter_number, l.subject, l.status, l.issued_date_jalali, l.created_at,
                  c.name AS contact_name FROM letters l
           LEFT JOIN contacts c ON c.id=l.contact_id
           ORDER BY l.id DESC LIMIT 8""").fetchall()
    top_templates = conn.execute(
        """SELECT t.id, t.title, t.category, COUNT(l.id) used FROM templates t
           LEFT JOIN letters l ON l.template_id=t.id
           GROUP BY t.id HAVING used > 0 ORDER BY used DESC LIMIT 5""").fetchall()
    return {
        "today_jalali": f"{jy:04d}/{jm:02d}/{_}",
        "total_final": total_final, "month_letters": month_letters, "drafts": drafts,
        "canceled": canceled, "contacts": contacts, "templates": templates,
        "signatories": signatories,
        "last_letters": [dict(r) for r in last_letters],
        "top_templates": [dict(r) for r in top_templates],
    }


def reports(conn, year: int | None = None) -> dict:
    jy, _, _ = today_jalali()
    year = year or jy
    by_month = []
    for m in range(1, 13):
        c = conn.execute(
            "SELECT COUNT(*) c FROM letters WHERE status='final' AND letter_year=? AND "
            "CAST(substr(issued_date_jalali,6,2) AS INTEGER)=?", (year, m)).fetchone()["c"]
        by_month.append({"month": m, "count": c})
    by_category = conn.execute(
        """SELECT COALESCE(t.category,'سایر') cat, COUNT(l.id) c FROM letters l
           LEFT JOIN templates t ON t.id=l.template_id WHERE l.status='final'
           GROUP BY cat ORDER BY c DESC""").fetchall()
    by_contact = conn.execute(
        """SELECT COALESCE(c.name,'—') name, COUNT(l.id) c FROM letters l
           LEFT JOIN contacts c ON c.id=l.contact_id WHERE l.status='final'
           GROUP BY l.contact_id ORDER BY c DESC LIMIT 10""").fetchall()
    by_status = conn.execute("SELECT status, COUNT(*) c FROM letters GROUP BY status").fetchall()
    by_year = conn.execute(
        "SELECT letter_year y, COUNT(*) c FROM letters WHERE status='final' AND letter_year IS NOT NULL "
        "GROUP BY y ORDER BY y DESC LIMIT 6").fetchall()
    return {"year": year, "by_month": [dict(r) for r in by_month],
            "by_category": [dict(r) for r in by_category],
            "by_contact": [dict(r) for r in by_contact],
            "by_status": [dict(r) for r in by_status],
            "by_year": [dict(r) for r in by_year]}
