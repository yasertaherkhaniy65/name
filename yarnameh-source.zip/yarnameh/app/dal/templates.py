"""DAL الگوهای نامه و پارامترهای پویا."""
from __future__ import annotations

import json
import sqlite3

ALLOWED_FIELD_TYPES = {
    "text", "textarea", "number", "amount", "jalali_date", "select",
    "contact", "signatory", "org", "id_no", "bool", "multiselect",
    "phone", "attachments_list", "notes",
}


def list_templates(conn, q: str = "", category: str = "", active: str = "") -> list[dict]:
    where, args = [], []
    if q:
        where.append("(title LIKE ? OR description LIKE ?)")
        args += [f"%{q}%", f"%{q}%"]
    if category:
        where.append("category = ?")
        args.append(category)
    if active in ("1", "0"):
        where.append("is_active = ?")
        args.append(int(active))
    wsql = ("WHERE " + " AND ".join(where)) if where else ""
    rows = conn.execute(
        f"""SELECT t.*, (SELECT COUNT(*) FROM template_fields f WHERE f.template_id=t.id) field_count,
                   (SELECT COUNT(*) FROM letters l WHERE l.template_id=t.id) usage_count
            FROM templates t {wsql}
            ORDER BY t.is_active DESC, t.sort_order, t.category, t.title""", args).fetchall()
    return [dict(r) for r in rows]


def categories(conn) -> list[str]:
    rows = conn.execute(
        "SELECT DISTINCT category FROM templates ORDER BY category").fetchall()
    return [r["category"] for r in rows]


def get_template(conn, tid: int, with_fields: bool = True) -> dict | None:
    row = conn.execute("SELECT * FROM templates WHERE id=?", (tid,)).fetchone()
    if not row:
        return None
    t = dict(row)
    if with_fields:
        fields = conn.execute(
            "SELECT * FROM template_fields WHERE template_id=? ORDER BY sort_order, id", (tid,)).fetchall()
        t["fields"] = []
        for f in fields:
            fd = dict(f)
            fd["options"] = json.loads(fd.pop("options_json") or "[]")
            fd["is_required"] = bool(fd["is_required"])
            t["fields"].append(fd)
    return t


def _insert_fields(conn, tid: int, fields: list[dict]) -> None:
    for i, f in enumerate(fields):
        conn.execute(
            """INSERT INTO template_fields (template_id, field_key, label, field_type, is_required,
               default_value, help_text, group_name, options_json, validation_regex, source_type, sort_order)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
            (tid, f["field_key"], f["label"], f.get("field_type", "text"),
             1 if f.get("is_required") else 0, f.get("default_value"), f.get("help_text"),
             f.get("group_name"), json.dumps(f.get("options") or [], ensure_ascii=False),
             f.get("validation_regex"), f.get("source_type", "manual"), f.get("sort_order", i)))


def create_template(conn, d: dict) -> int:
    cur = conn.execute(
        """INSERT INTO templates (title, category, description, body_html, paper_size, orientation,
           margin_preset, default_signatory_id, is_system, is_active, sort_order)
           VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
        (d["title"], d.get("category", "اداری و تجاری"), d.get("description"), d.get("body_html", ""),
         d.get("paper_size", "A4"), d.get("orientation", "portrait"), d.get("margin_preset", "normal"),
         d.get("default_signatory_id"), 0, 1 if d.get("is_active", True) else 0,
         d.get("sort_order", 0)))
    tid = cur.lastrowid
    _insert_fields(conn, tid, d.get("fields") or [])
    return tid


def update_template(conn, tid: int, d: dict) -> bool:
    cur = conn.execute(
        """UPDATE templates SET title=?, category=?, description=?, body_html=?, paper_size=?,
           orientation=?, margin_preset=?, default_signatory_id=?, is_active=?, sort_order=?,
           updated_at=datetime('now','localtime') WHERE id=?""",
        (d["title"], d.get("category", "اداری و تجاری"), d.get("description"), d.get("body_html", ""),
         d.get("paper_size", "A4"), d.get("orientation", "portrait"), d.get("margin_preset", "normal"),
         d.get("default_signatory_id"), 1 if d.get("is_active", True) else 0,
         d.get("sort_order", 0), tid))
    if "fields" in d:
        conn.execute("DELETE FROM template_fields WHERE template_id=?", (tid,))
        _insert_fields(conn, tid, d.get("fields") or [])
    return cur.rowcount > 0


def duplicate_template(conn, tid: int) -> int | None:
    t = get_template(conn, tid)
    if not t:
        return None
    t = dict(t)
    t["title"] = f"{t['title']} (کپی)"
    t["is_system"] = 0
    t.pop("id")
    return create_template(conn, t)


def delete_template(conn, tid: int) -> tuple[bool, int]:
    """حذف الگو هرگز نامه‌های قبلی را تغییر نمی‌دهد (متن نامه‌ها مستقل ذخیره شده است)."""
    used = conn.execute("SELECT COUNT(*) c FROM letters WHERE template_id=?", (tid,)).fetchone()["c"]
    if used > 0:
        return False, used
    conn.execute("DELETE FROM templates WHERE id=?", (tid,))
    return True, 0


def replace_body(conn, tid: int, body_html: str) -> None:
    conn.execute("UPDATE templates SET body_html=?, updated_at=datetime('now','localtime') WHERE id=?",
                 (body_html, tid))
