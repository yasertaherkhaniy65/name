"""DAL امضاکنندگان، سازمان و تنظیمات + ثبت رویدادها (Audit)."""
from __future__ import annotations

import json
import sqlite3


# ------------------------------ امضاکنندگان ------------------------------

def list_signatories(conn, q: str = "", active: str = "") -> list[dict]:
    where, args = [], []
    if q:
        where.append("(full_name LIKE ? OR position LIKE ?)")
        args += [f"%{q}%", f"%{q}%"]
    if active in ("1", "0"):
        where.append("is_active = ?")
        args.append(int(active))
    wsql = ("WHERE " + " AND ".join(where)) if where else ""
    rows = conn.execute(
        f"SELECT * FROM signatories {wsql} ORDER BY is_active DESC, sort_order, id", args).fetchall()
    return [dict(r) for r in rows]


def get_signatory(conn, sid: int):
    row = conn.execute("SELECT * FROM signatories WHERE id=?", (sid,)).fetchone()
    return dict(row) if row else None


def create_signatory(conn, d: dict) -> int:
    cur = conn.execute(
        """INSERT INTO signatories (full_name, position, unit, signature_image_path,
           stamp_image_path, sort_order, is_active, notes) VALUES (?,?,?,?,?,?,?,?)""",
        (d["full_name"], d["position"], d.get("unit"), d.get("signature_image_path"),
         d.get("stamp_image_path"), d.get("sort_order", 0), 1 if d.get("is_active", True) else 0,
         d.get("notes")))
    return cur.lastrowid


def update_signatory(conn, sid: int, d: dict) -> bool:
    cur = conn.execute(
        """UPDATE signatories SET full_name=?, position=?, unit=?, signature_image_path=?,
           stamp_image_path=?, sort_order=?, is_active=?, notes=?,
           updated_at=datetime('now','localtime') WHERE id=?""",
        (d["full_name"], d["position"], d.get("unit"), d.get("signature_image_path"),
         d.get("stamp_image_path"), d.get("sort_order", 0), 1 if d.get("is_active", True) else 0,
         d.get("notes"), sid))
    return cur.rowcount > 0


def delete_signatory(conn, sid: int) -> bool:
    conn.execute("DELETE FROM signatories WHERE id=?", (sid,))
    return True


# ------------------------------ سازمان ------------------------------

def get_default_org(conn) -> dict | None:
    row = conn.execute("SELECT * FROM organizations WHERE is_default=1 LIMIT 1").fetchone()
    if row:
        return dict(row)
    row = conn.execute("SELECT * FROM organizations LIMIT 1").fetchone()
    return dict(row) if row else None


def upsert_default_org(conn, d: dict) -> int:
    cur = conn.execute(
        """UPDATE organizations SET name=?, legal_form=?, national_id=?, economic_code=?,
           registration_no=?, address=?, postal_code=?, phone=?, email=?, website=?,
           logo_path=?, stamp_path=?, updated_at=datetime('now','localtime') WHERE is_default=1""",
        (d["name"], d.get("legal_form"), d.get("national_id"), d.get("economic_code"),
         d.get("registration_no"), d.get("address"), d.get("postal_code"), d.get("phone"),
         d.get("email"), d.get("website"), d.get("logo_path"), d.get("stamp_path")))
    if cur.rowcount == 0:
        cur = conn.execute(
            """INSERT INTO organizations (name, legal_form, national_id, economic_code,
               registration_no, address, postal_code, phone, email, website, logo_path, stamp_path)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
            (d["name"], d.get("legal_form"), d.get("national_id"), d.get("economic_code"),
             d.get("registration_no"), d.get("address"), d.get("postal_code"), d.get("phone"),
             d.get("email"), d.get("website"), d.get("logo_path"), d.get("stamp_path")))
    return cur.lastrowid


# ------------------------------ تنظیمات ------------------------------

def get_setting(conn, key: str, default=None):
    row = conn.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
    return row["value"] if row else default


def set_setting(conn, key: str, value: str) -> None:
    conn.execute(
        """INSERT INTO settings (key, value, updated_at) VALUES (?,?,datetime('now','localtime'))
           ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at""",
        (key, value))


def all_settings(conn) -> dict:
    rows = conn.execute("SELECT key, value FROM settings").fetchall()
    return {r["key"]: r["value"] for r in rows}


# ------------------------------ Audit ------------------------------

def log_action(conn, action: str, entity_type: str = "", entity_id: int | None = None,
               details: dict | None = None) -> None:
    conn.execute(
        "INSERT INTO audit_logs (action, entity_type, entity_id, details_json) VALUES (?,?,?,?)",
        (action, entity_type, entity_id,
         json.dumps(details, ensure_ascii=False) if details else None))


def recent_logs(conn, limit: int = 100) -> list[dict]:
    rows = conn.execute(
        "SELECT * FROM audit_logs ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
    return [dict(r) for r in rows]
