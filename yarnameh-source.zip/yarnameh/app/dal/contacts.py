"""DAL مخاطبین — جست‌وجو، فیلتر، صفحه‌بندی، تشخیص موارد مشابه."""
from __future__ import annotations

import json
import sqlite3
from datetime import date

from ..jdate import gregorian_to_jalali


def _now_jalali_str() -> str:
    t = date.today()
    jy, jm, jd = gregorian_to_jalali(t.year, t.month, t.day)
    return f"{jy:04d}/{jm:02d}/{jd:02d}"


def list_contacts(conn: sqlite3.Connection, q: str = "", kind: str = "", active: str = "",
                  page: int = 1, page_size: int = 25) -> dict:
    where, args = [], []
    if q:
        where.append("(name LIKE ? OR company_name LIKE ? OR phone LIKE ? OR customer_no LIKE ? OR national_id LIKE ?)")
        like = f"%{q}%"
        args += [like, like, like, like, like]
    if kind:
        where.append("kind = ?")
        args.append(kind)
    if active in ("1", "0"):
        where.append("is_active = ?")
        args.append(int(active))
    wsql = ("WHERE " + " AND ".join(where)) if where else ""
    total = conn.execute(f"SELECT COUNT(*) c FROM contacts {wsql}", args).fetchone()["c"]
    rows = conn.execute(
        f"""SELECT * FROM contacts {wsql}
            ORDER BY is_active DESC, name COLLATE NOCASE LIMIT ? OFFSET ?""",
        args + [page_size, (page - 1) * page_size]).fetchall()
    return {"items": [dict(r) for r in rows], "total": total, "page": page, "page_size": page_size}


def get_contact(conn: sqlite3.Connection, contact_id: int):
    row = conn.execute("SELECT * FROM contacts WHERE id = ?", (contact_id,)).fetchone()
    return dict(row) if row else None


def find_similar(conn: sqlite3.Connection, name: str, exclude_id: int = 0) -> list[dict]:
    """تشخیص مخاطب تکراری/مشابه برای هشدار."""
    n = name.strip()
    if len(n) < 3:
        return []
    rows = conn.execute(
        "SELECT id, name, kind, is_active FROM contacts WHERE (name = ? OR name LIKE ?) AND id != ? LIMIT 6",
        (n, f"%{n}%", exclude_id)).fetchall()
    return [dict(r) for r in rows]


def create_contact(conn: sqlite3.Connection, data: dict) -> int:
    cur = conn.execute(
        """INSERT INTO contacts (kind, name, company_name, salutation, position, national_id,
           economic_code, customer_no, address, postal_code, phone, email, notes, is_active)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        (data["kind"], data["name"], data.get("company_name"), data.get("salutation"),
         data.get("position"), data.get("national_id"), data.get("economic_code"),
         data.get("customer_no"), data.get("address"), data.get("postal_code"),
         data.get("phone"), data.get("email"), data.get("notes"),
         1 if data.get("is_active", True) else 0))
    return cur.lastrowid


def update_contact(conn: sqlite3.Connection, contact_id: int, data: dict) -> bool:
    cur = conn.execute(
        """UPDATE contacts SET kind=?, name=?, company_name=?, salutation=?, position=?,
           national_id=?, economic_code=?, customer_no=?, address=?, postal_code=?,
           phone=?, email=?, notes=?, is_active=?, updated_at=datetime('now','localtime')
           WHERE id=?""",
        (data["kind"], data["name"], data.get("company_name"), data.get("salutation"),
         data.get("position"), data.get("national_id"), data.get("economic_code"),
         data.get("customer_no"), data.get("address"), data.get("postal_code"),
         data.get("phone"), data.get("email"), data.get("notes"),
         1 if data.get("is_active", True) else 0, contact_id))
    return cur.rowcount > 0


def set_active(conn: sqlite3.Connection, contact_id: int, active: bool) -> bool:
    cur = conn.execute("UPDATE contacts SET is_active=?, updated_at=datetime('now','localtime') WHERE id=?",
                       (1 if active else 0, contact_id))
    return cur.rowcount > 0


def delete_contact(conn: sqlite3.Connection, contact_id: int) -> tuple[bool, int]:
    """حذف کامل فقط وقتی مجاز است که نامه‌ای به مخاطب وصل نباشد؛
    حذف مخاطب استفاده‌شده هرگز سابقه نامه‌ها را خراب نمی‌کند (snapshot مستقل در نامه‌ها ذخیره شده است)."""
    used = conn.execute("SELECT COUNT(*) c FROM letters WHERE contact_id = ?", (contact_id,)).fetchone()["c"]
    if used > 0:
        return False, used
    conn.execute("DELETE FROM contacts WHERE id = ?", (contact_id,))
    return True, 0


def contact_usage_count(conn: sqlite3.Connection, contact_id: int) -> int:
    return conn.execute("SELECT COUNT(*) c FROM letters WHERE contact_id = ?", (contact_id,)).fetchone()["c"]


def snapshot_contact(conn: sqlite3.Connection, contact_id: int) -> dict | None:
    c = get_contact(conn, contact_id)
    if not c:
        return None
    return json.dumps({k: c.get(k) for k in
                       ("name", "kind", "company_name", "salutation", "position", "address",
                        "postal_code", "phone", "email", "national_id", "economic_code")},
                      ensure_ascii=False)
