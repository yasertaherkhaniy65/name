"""یارنامه — نقطه ورود سرویس FastAPI (فقط Loopback)."""
from __future__ import annotations

import logging
import traceback
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse, FileResponse
from fastapi.staticfiles import StaticFiles

from . import config, database
from .security import ALLOWED_HOSTS
from .seed import seed_if_empty

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
    handlers=[logging.FileHandler(config.data_dir() / "service.log", encoding="utf-8"),
              logging.StreamHandler()],
)
log = logging.getLogger("yarnameh")


def create_app() -> FastAPI:
    app = FastAPI(title="یارنامه", version=config.APP_VERSION, docs_url=None, redoc_url=None,
                  openapi_url=None)

    conn = database.connect()
    version = database.apply_migrations(conn)
    inserted = seed_if_empty(conn)
    log.info("Database ready (schema v%s) — seeded %s templates", version, inserted)
    app.state.conn = conn
    app.state.schema_version = version

    # ---------------- میان‌افزار امنیتی ----------------
    @app.middleware("http")
    async def security_middleware(request: Request, call_next):
        host = (request.headers.get("host") or "").split(":")[0]
        if host not in ALLOWED_HOSTS:
            return JSONResponse({"detail": "دسترسی فقط از سیستم محلی مجاز است"}, status_code=403)
        # کنترل مبدأ برای درخواست‌های تغییردهنده (ضد CSRF)
        if request.method in ("POST", "PUT", "PATCH", "DELETE"):
            origin = request.headers.get("origin") or ""
            if origin:
                o_host = origin.split("//")[-1].split(":")[0]
                if o_host not in ALLOWED_HOSTS:
                    return JSONResponse({"detail": "درخواست از مبدأ غیرمجاز رد شد"}, status_code=403)
        try:
            return await call_next(request)
        except Exception:
            log.error("Unhandled error: %s", traceback.format_exc())
            return JSONResponse({"detail": "خطای داخلی سرویس — جزئیات در فایل ثبت رویداد"}, status_code=500)

    from .routers import general, contacts, signatories, templates, letters, \
        sequences, backup, ai, files

    for router in (general.router, contacts.router, signatories.router, templates.router,
                   letters.router, sequences.router, backup.router, ai.router, files.router):
        app.include_router(router, prefix="/api")

    # ---------------- رابط کاربری استاتیک ----------------
    web = config.web_dir()
    if (web / "index.html").exists():
        app.mount("/assets", StaticFiles(directory=str(web / "assets")), name="assets")

        @app.get("/", include_in_schema=False)
        async def index():
            return FileResponse(str(web / "index.html"))

        @app.get("/{path:path}", include_in_schema=False)
        async def spa_fallback(path: str):
            candidate = web / path
            if candidate.is_file() and str(candidate.resolve()).startswith(str(web.resolve())):
                return FileResponse(str(candidate))
            return FileResponse(str(web / "index.html"))

    @app.on_event("shutdown")
    async def shutdown():
        try:
            conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")
            conn.close()
            log.info("Service stopped gracefully")
        except Exception:
            pass

    return app


app = create_app()
