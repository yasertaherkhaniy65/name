"""
یارنامه — پیکربندی مسیرها و تنظیمات محلی.
محل نصب برنامه از محل ذخیره داده‌ها کاملاً مستقل است.
"""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path

APP_NAME = "YarNameh"
APP_TITLE_FA = "یارنامه"
APP_VERSION = "1.0.0"
DB_FILENAME = "yarnameh.sqlite"
DEFAULT_PORT = 8765


def is_frozen() -> bool:
    return getattr(sys, "frozen", False)


def base_dir() -> Path:
    """پوشه حاوی فایل‌های برنامه (سورس یا بسته PyInstaller)."""
    if is_frozen():
        return Path(sys._MEIPASS)  # noqa: SLF001
    return Path(__file__).resolve().parent.parent


def web_dir() -> Path:
    return base_dir() / "web"


def data_dir() -> Path:
    """
    محل ذخیره داده‌های کاربر — مستقل از محل نصب.
    ویندوز: %LOCALAPPDATA%\\YarNameh
    توسعه/لینوکس: ~/.local/share/YarNameh یا متغیر محیطی YARNAMEH_DATA_DIR
    """
    env = os.environ.get("YARNAMEH_DATA_DIR")
    if env:
        p = Path(env)
    elif os.name == "nt":
        local_app = os.environ.get("LOCALAPPDATA") or os.path.expanduser("~\\AppData\\Local")
        p = Path(local_app) / APP_NAME
    else:
        xdg = os.environ.get("XDG_DATA_HOME") or os.path.expanduser("~/.local/share")
        p = Path(xdg) / APP_NAME
    p.mkdir(parents=True, exist_ok=True)
    return p


DB_PATH = property(lambda self: None)  # placeholder — استفاده از توابع زیر


def db_path() -> Path:
    return data_dir() / DB_FILENAME


def files_dir() -> Path:
    p = data_dir() / "files"
    p.mkdir(parents=True, exist_ok=True)
    return p


def signatures_dir() -> Path:
    p = files_dir() / "signatures"
    p.mkdir(parents=True, exist_ok=True)
    return p


def stamps_dir() -> Path:
    p = files_dir() / "stamps"
    p.mkdir(parents=True, exist_ok=True)
    return p


def logos_dir() -> Path:
    p = files_dir() / "logos"
    p.mkdir(parents=True, exist_ok=True)
    return p


def attachments_dir() -> Path:
    p = files_dir() / "attachments"
    p.mkdir(parents=True, exist_ok=True)
    return p


def inline_images_dir() -> Path:
    p = files_dir() / "inline"
    p.mkdir(parents=True, exist_ok=True)
    return p


def backups_dir() -> Path:
    p = data_dir() / "backups"
    p.mkdir(parents=True, exist_ok=True)
    return p


def config_file() -> Path:
    return data_dir() / "config.json"


def read_config() -> dict:
    """فایل تنظیمات غیرحساس — هرگز کلید API یا داده شخصی در آن ذخیره نمی‌شود."""
    f = config_file()
    default = {"port": DEFAULT_PORT, "open_browser_on_start": True}
    if f.exists():
        try:
            cfg = json.loads(f.read_text(encoding="utf-8"))
            default.update({k: v for k, v in cfg.items() if k in default})
        except Exception:
            pass
    return default


def write_config(cfg: dict) -> None:
    f = config_file()
    f.write_text(json.dumps(read_config() | cfg, ensure_ascii=False, indent=2), encoding="utf-8")
