"""روتر الگوهای نامه + پارامترهای پویا."""
from __future__ import annotations

import re

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel, Field

from ..dal import templates as dal
from ..security import sanitize_text
from ..seed import ALLOWED_TYPES

router = APIRouter(prefix="/templates")

KEY_RE = re.compile(r"^[a-z][a-z0-9_]{1,49}$")


def get_conn(request: Request):
    return request.app.state.conn


class FieldIn(BaseModel):
    field_key: str = Field(min_length=2, max_length=50)
    label: str = Field(min_length=2, max_length=120)
    field_type: str = Field(default="text")
    is_required: bool = False
    default_value: str = Field(default="", max_length=500)
    help_text: str = Field(default="", max_length=300)
    group_name: str = Field(default="", max_length=80)
    options: list[str] = Field(default_factory=list)
    validation_regex: str = Field(default="", max_length=200)
    source_type: str = Field(default="manual")
    sort_order: int = 0


class TemplateIn(BaseModel):
    title: str = Field(min_length=2, max_length=150)
    category: str = Field(default="اداری و تجاری", max_length=60)
    description: str = Field(default="", max_length=500)
    body_html: str = Field(default="", max_length=100_000)
    paper_size: str = Field(default="A4")
    orientation: str = Field(default="portrait")
    margin_preset: str = Field(default="normal")
    default_signatory_id: int = 0
    is_active: bool = True
    sort_order: int = 0
    fields: list[FieldIn] = Field(default_factory=list)


def _validate_payload(payload: TemplateIn) -> dict:
    d = payload.model_dump()
    d["default_signatory_id"] = d["default_signatory_id"] or None  # ۰ یعنی بدون پیش‌فرض
    d["title"] = sanitize_text(d["title"], 150)
    d["category"] = sanitize_text(d["category"], 60)
    d["description"] = sanitize_text(d["description"], 500)
    if d["paper_size"] not in ("A4", "A5"):
        d["paper_size"] = "A4"
    if d["orientation"] not in ("portrait", "landscape"):
        d["orientation"] = "portrait"
    keys = set()
    for f in d["fields"]:
        if not KEY_RE.fullmatch(f["field_key"]):
            raise HTTPException(422, f"نام سیستمی «{f['field_key']}» باید با حروف کوچک لاتین شروع شود و فقط شامل حرف، عدد و _ باشد")
        if f["field_key"] in keys:
            raise HTTPException(422, f"نام سیستمی «{f['field_key']}» تکراری است")
        keys.add(f["field_key"])
        if f["field_type"] not in ALLOWED_TYPES:
            raise HTTPException(422, f"نوع پارامتر «{f['field_type']}» معتبر نیست")
        if f["field_type"] in ("select", "multiselect") and not f["options"]:
            raise HTTPException(422, f"برای «{f['label']}» حداقل یک گزینه تعریف کنید")
        f["label"] = sanitize_text(f["label"], 120)
        f["default_value"] = sanitize_text(f["default_value"], 500)
        f["help_text"] = sanitize_text(f["help_text"], 300)
        f["group_name"] = sanitize_text(f["group_name"], 80)
        f["options"] = [sanitize_text(o, 120) for o in f["options"]][:60]
        try:
            if f["validation_regex"]:
                re.compile(f["validation_regex"])
        except re.error:
            raise HTTPException(422, f"عبارت منظم اعتبارسنجی «{f['label']}» نامعتبر است")
    return d


@router.get("")
def list_all(request: Request, q: str = "", category: str = "", active: str = ""):
    return dal.list_templates(get_conn(request), sanitize_text(q, 80), sanitize_text(category, 60), active)


@router.get("/categories")
def get_categories(request: Request):
    return dal.categories(get_conn(request))


@router.get("/{tid}")
def get_one(tid: int, request: Request):
    t = dal.get_template(get_conn(request), tid)
    if not t:
        raise HTTPException(404, "الگو یافت نشد")
    return t


@router.post("")
def create(payload: TemplateIn, request: Request):
    conn = get_conn(request)
    with conn:
        tid = dal.create_template(conn, _validate_payload(payload))
        from ..dal.misc import log_action
        log_action(conn, "template.create", "template", tid)
    return {"id": tid}


@router.put("/{tid}")
def update(tid: int, payload: TemplateIn, request: Request):
    conn = get_conn(request)
    if not dal.get_template(conn, tid, with_fields=False):
        raise HTTPException(404, "الگو یافت نشد")
    with conn:
        dal.update_template(conn, tid, _validate_payload(payload))
        from ..dal.misc import log_action
        log_action(conn, "template.update", "template", tid)
    return {"ok": True}


@router.post("/{tid}/duplicate")
def duplicate(tid: int, request: Request):
    conn = get_conn(request)
    with conn:
        new_id = dal.duplicate_template(conn, tid)
        from ..dal.misc import log_action
        log_action(conn, "template.duplicate", "template", new_id)
    if not new_id:
        raise HTTPException(404, "الگو یافت نشد")
    return {"id": new_id}


@router.delete("/{tid}")
def delete(tid: int, request: Request):
    """حذف الگو هرگز متن نامه‌های قبلی را تغییر نمی‌دهد؛ در صورت استفاده، غیرفعال‌سازی پیشنهاد می‌شود."""
    conn = get_conn(request)
    ok, used = dal.delete_template(conn, tid)
    if not ok:
        raise HTTPException(409, {"message": "این الگو در نامه‌های ثبت‌شده استفاده شده است",
                                  "usage_count": used,
                                  "suggestion": "الگو را غیرفعال کنید؛ نامه‌های قبلی مستقل از الگو ذخیره شده‌اند"})
    from ..dal.misc import log_action
    with conn:
        log_action(conn, "template.delete", "template", tid)
    return {"ok": True}
