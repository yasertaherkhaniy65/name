"""روتر نامه‌ها: تولید متن، پیش‌نویس، ثبت نهایی، ابطال، کپی، نسخه‌ها."""
from __future__ import annotations

import json

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel, Field

from ..dal import letters as dal
from ..dal.misc import log_action
from ..renderer import validate_params, render_body, build_value_map, collect_letter_signatories
from ..security import sanitize_text, sanitize_html
from ..jdate import validate_jalali_str, today_jalali

router = APIRouter(prefix="/letters")

MARGIN_PRESETS = {"normal", "narrow", "wide"}


def get_conn(request: Request):
    return request.app.state.conn


class GenerateIn(BaseModel):
    template_id: int
    params: dict = Field(default_factory=dict)
    for_preview: bool = False  # True = نمایش پیش‌نمایش نهایی (شماره/تاریخ خالی)


class LetterIn(BaseModel):
    template_id: int = 0
    subject: str = Field(default="", max_length=300)
    contact_id: int = 0
    body_html: str = Field(default="", max_length=400_000)
    params: dict = Field(default_factory=dict)
    paper_size: str = Field(default="A4")
    orientation: str = Field(default="portrait")
    margin_preset: str = Field(default="normal")
    signatory_ids: list[int] = Field(default_factory=list)


class FinalizeIn(BaseModel):
    sequence_id: int
    issue_date: str = Field(min_length=4, max_length=10)  # ۱۴۰۵/۰۸/۰۳


class CancelIn(BaseModel):
    reason: str = Field(min_length=3, max_length=500)


def _load_template(conn, tid: int) -> dict:
    t = conn.execute("SELECT * FROM templates WHERE id=?", (tid,)).fetchone()
    if not t:
        raise HTTPException(404, "الگو یافت نشد")
    from ..dal.templates import get_template
    return get_template(conn, tid)


def _signatory_payloads(conn, ids: list[int]) -> list[dict]:
    out = []
    seen = set()
    for sid in ids[:5]:
        if sid in seen:
            continue
        seen.add(sid)
        row = conn.execute("SELECT * FROM signatories WHERE id=? AND is_active=1", (sid,)).fetchone()
        if row:
            s = dict(row)
            out.append({"signatory_id": s["id"], "snapshot_name": s["full_name"],
                        "snapshot_position": s["position"] or "",
                        "signature_image_path": s.get("signature_image_path"),
                        "stamp_image_path": s.get("stamp_image_path")})
    return out


@router.post("/generate")
def generate(payload: GenerateIn, request: Request):
    """تولید متن از پارامترها — هیچ داده‌ای ذخیره نمی‌شود؛ خروجی بعداً آزادانه ویرایش می‌شود."""
    conn = get_conn(request)
    template = _load_template(conn, payload.template_id)
    clean, errors = validate_params(template, payload.params)
    if errors:
        raise HTTPException(422, {"errors": errors})
    values = build_value_map(conn, template, clean, for_finalize=payload.for_preview)
    body = render_body(template, values)
    return {"body_html": body, "params": clean, "template_title": template["title"]}


@router.get("")
def list_letters(request: Request, q: str = "", status: str = "", year: str = "",
                 contact_id: int = 0, template_id: int = 0, from_jalali: str = "",
                 to_jalali: str = "", page: int = 1, page_size: int = 20):
    page = max(1, min(page, 1000))
    page_size = max(5, min(page_size, 100))
    return dal.list_letters(get_conn(request), sanitize_text(q, 120), status, year,
                            contact_id, template_id, from_jalali, to_jalali, page, page_size)


@router.post("")
def create_letter(payload: LetterIn, request: Request):
    """ایجاد پیش‌نویس (یا نامه با متن تأییدشده) — پیش‌نویس‌ها شماره رسمی نمی‌گیرند."""
    conn = get_conn(request)
    subject = sanitize_text(payload.subject, 300)
    if not subject:
        raise HTTPException(422, "موضوع نامه الزامی است")
    body = sanitize_html(payload.body_html)
    if not body.strip():
        raise HTTPException(422, "متن نامه خالی است")
    template = _load_template(conn, payload.template_id) if payload.template_id else None
    params = payload.params
    if template:
        params, errors = validate_params(template, payload.params)
        if errors:
            raise HTTPException(422, {"errors": errors})
    if payload.paper_size not in ("A4", "A5"):
        raise HTTPException(422, "اندازه کاغذ معتبر نیست")
    if payload.orientation not in ("portrait", "landscape"):
        raise HTTPException(422, "جهت کاغذ معتبر نیست")
    if payload.margin_preset not in MARGIN_PRESETS:
        raise HTTPException(422, "حاشیه معتبر نیست")
    sigs = _signatory_payloads(conn, payload.signatory_ids)
    with conn:
        lid = dal.create_letter(conn, {
            "subject": subject, "contact_id": payload.contact_id or None,
            "template_id": template["id"] if template else None,
            "template_title_snapshot": template["title"] if template else None,
            "body_html": body, "parameters": params, "status": "draft",
            "paper_size": payload.paper_size, "orientation": payload.orientation,
            "margin_preset": payload.margin_preset,
            "org_id": (conn.execute("SELECT id FROM organizations WHERE is_default=1").fetchone() or {"id": None})["id"],
            "contact_snapshot_json": json.dumps({k: sanitize_text(v, 300) for k, v in (params.get("__contact_snapshot") or {}).items()}, ensure_ascii=False) if params.get("__contact_snapshot") else None,
            "signatories": sigs,
        })
        log_action(conn, "letter.create", "letter", lid, {"subject": subject})
    return {"id": lid}


@router.get("/{lid}")
def get_letter(lid: int, request: Request):
    letter = dal.get_letter(get_conn(request), lid)
    if not letter:
        raise HTTPException(404, "نامه یافت نشد")
    return letter


@router.put("/{lid}")
def update_letter(lid: int, payload: LetterIn, request: Request):
    """به‌روزرسانی پیش‌نویس — شامل ذخیره خودکار. نامه ثبت‌شده از این مسیر تغییر نمی‌کند."""
    conn = get_conn(request)
    existing = dal.get_letter(conn, lid)
    if not existing:
        raise HTTPException(404, "نامه یافت نشد")
    if existing["status"] != "draft":
        raise HTTPException(409, "نامه ثبت‌شده تغییرناپذیر است")
    template = _load_template(conn, payload.template_id) if payload.template_id else None
    params = payload.params
    if template:
        params, errors = validate_params(template, payload.params)
        if errors:
            raise HTTPException(422, {"errors": errors})
    with conn:
        ok = dal.update_letter(conn, lid, {
            "subject": sanitize_text(payload.subject, 300),
            "contact_id": payload.contact_id or None,
            "body_html": sanitize_html(payload.body_html),
            "parameters": params,
            "paper_size": payload.paper_size if payload.paper_size in ("A4", "A5") else "A4",
            "orientation": payload.orientation if payload.orientation in ("portrait", "landscape") else "portrait",
            "margin_preset": payload.margin_preset if payload.margin_preset in MARGIN_PRESETS else "normal",
            "manually_edited": 1 if payload.body_html else 0,
            "update_signatories": bool(payload.signatory_ids),
            "signatories": _signatory_payloads(conn, payload.signatory_ids),
        })
    return {"ok": bool(ok)}


@router.post("/{lid}/regenerate")
def regenerate(lid: int, payload: GenerateIn, request: Request):
    """بازتولید متن با پارامترهای جدید — فقط با تأیید کاربر؛ نسخه قبلی حفظ می‌شود."""
    conn = get_conn(request)
    letter = dal.get_letter(conn, lid)
    if not letter:
        raise HTTPException(404, "نامه یافت نشد")
    if letter["status"] != "draft":
        raise HTTPException(409, "نامه ثبت‌شده تغییرناپذیر است")
    template = _load_template(conn, payload.template_id or letter["template_id"])
    clean, errors = validate_params(template, payload.params)
    if errors:
        raise HTTPException(422, {"errors": errors})
    values = build_value_map(conn, template, clean, for_finalize=payload.for_preview)
    new_body = render_body(template, values)
    with conn:
        dal.save_version(conn, lid, "نسخه قبل از بازتولید متن", letter["body_html"], letter["parameters"])
        conn.execute(
            """UPDATE letters SET body_html=?, parameters_json=?, template_id=?,
               manually_edited=0, updated_at=datetime('now','localtime') WHERE id=?""",
            (new_body, json.dumps(clean, ensure_ascii=False), template["id"], lid))
        log_action(conn, "letter.regenerate", "letter", lid)
    return {"body_html": new_body, "params": clean}


@router.post("/{lid}/finalize")
def finalize(lid: int, payload: FinalizeIn, request: Request):
    """ثبت نهایی: تخصیص شماره یکتا در تراکنش + جداسازی تاریخ صدور از زمان ثبت + نسخه نهایی مستقل."""
    conn = get_conn(request)
    issue = validate_jalali_str(payload.issue_date)
    if not issue:
        raise HTTPException(422, "تاریخ صدور معتبر نیست")
    seq = dal.get_sequence(conn, payload.sequence_id)
    if not seq or not seq["is_active"]:
        raise HTTPException(422, "شماره‌گذار معتبر نیست")
    try:
        result = dal.finalize_letter(conn, lid, payload.sequence_id, issue)
    except ValueError as e:
        raise HTTPException(409, str(e))
    with conn:
        log_action(conn, "letter.finalize", "letter", lid,
                   {"number": result["letter_number"]})
    return result


@router.post("/{lid}/cancel")
def cancel(lid: int, payload: CancelIn, request: Request):
    conn = get_conn(request)
    reason = sanitize_text(payload.reason, 500)
    ok = dal.cancel_letter(conn, lid, reason)
    if not ok:
        raise HTTPException(409, "فقط نامه ثبت‌شده قابل ابطال است")
    with conn:
        log_action(conn, "letter.cancel", "letter", lid, {"reason": reason})
    return {"ok": True}


@router.post("/{lid}/copy")
def copy(lid: int, request: Request):
    conn = get_conn(request)
    with conn:
        new_id = dal.copy_letter(conn, lid)
        log_action(conn, "letter.copy", "letter", new_id, {"from": lid})
    if not new_id:
        raise HTTPException(404, "نامه یافت نشد")
    return {"id": new_id}


@router.get("/{lid}/versions/{vid}")
def get_version(lid: int, vid: int, request: Request):
    v = dal.get_version_body(get_conn(request), lid, vid)
    if not v:
        raise HTTPException(404, "نسخه یافت نشد")
    return v
