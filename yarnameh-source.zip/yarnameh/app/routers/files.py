"""روتر فایل‌ها: آپلود امن (لوگو/امضا/مهر/پیوست) و ارائه رسانه‌ها با نام‌گذاری کنترل‌شده.

- فایل‌های کاربر هرگز در پوشه استاتیک وب قرار نمی‌گیرند
- نام فایل ذخیره‌شده تصادفی (token_hex) است و مسیر کاربر هرگز مستقیم استفاده نمی‌شود
- ارائه فقط با الگوی نام سخت‌گیرانه (محافظت کامل در برابر Path Traversal)
"""
from __future__ import annotations

import secrets

from fastapi import APIRouter, HTTPException, Request, UploadFile, File
from fastapi.responses import FileResponse

from .. import config
from ..dal import letters as letters_dal
from ..security import detect_image_ext, is_valid_pdf, filename_is_safe

router = APIRouter()

MAX_IMAGE = 5 * 1024 * 1024
MAX_ATTACHMENT = 15 * 1024 * 1024
ALLOWED_KINDS = {"logo", "signature", "stamp", "attachment", "inline"}


def get_conn(request: Request):
    return request.app.state.conn


def _folder_for(kind: str):
    return {
        "logo": config.logos_dir, "logos": config.logos_dir,
        "signature": config.signatures_dir, "signatures": config.signatures_dir,
        "stamp": config.stamps_dir, "stamps": config.stamps_dir,
        "attachment": config.attachments_dir, "attachments": config.attachments_dir,
        "inline": config.inline_images_dir,
    }[kind]


@router.post("/uploads")
async def upload(request: Request, kind: str = "attachment", letter_id: int = 0,
                 file: UploadFile = File(...)):
    if kind not in ALLOWED_KINDS:
        raise HTTPException(422, "نوع آپلود معتبر نیست")
    folder = _folder_for(kind)()  # kind مفرد — نام پوشه جمع است
    content = file.file.read(MAX_ATTACHMENT + 1)
    limit = MAX_IMAGE if kind in ("logo", "signature", "stamp", "inline") else MAX_ATTACHMENT
    if len(content) > limit:
        raise HTTPException(413, "حجم فایل بیش از حد مجاز است (حداکثر ۵ مگابایت تصویر، ۱۵ مگابایت پیوست)")
    head = content[:16]
    if kind in ("logo", "signature", "stamp", "inline"):
        ext = detect_image_ext(head)
        if not ext:
            raise HTTPException(415, "فقط تصویر PNG یا JPG معتبر است")
        mime = "image/png" if ext == ".png" else "image/jpeg"
    else:
        original = file.filename or ""
        if not filename_is_safe(original):
            raise HTTPException(422, "نام فایل معتبر نیست")
        ext_ok = any(original.lower().endswith(e) for e in (".png", ".jpg", ".jpeg", ".pdf", ".zip"))
        if not ext_ok:
            raise HTTPException(415, "فرمت پیوست مجاز نیست (PNG/JPG/PDF/ZIP)")
        ext = detect_image_ext(head)
        if ext:
            mime = "image/png" if ext == ".png" else "image/jpeg"
        elif is_valid_pdf(head) and original.lower().endswith(".pdf"):
            ext, mime = ".pdf", "application/pdf"
        elif original.lower().endswith(".zip") and content[:2] == b"PK":
            ext, mime = ".zip", "application/zip"
        else:
            raise HTTPException(415, "محتوای فایل با پسوند آن هم‌خوانی ندارد")
    stored = secrets.token_hex(16) + ext
    path = folder / stored
    path.write_bytes(content)
    result = {"stored_path": f"files/{folder.name}/{stored}",
              "url": f"/api/media/{folder.name}/{stored}", "size": len(content)}
    if kind == "attachment" and letter_id:
        conn = get_conn(request)
        letters_dal.add_attachment(conn, letter_id, original[:150],
                                   result["stored_path"], mime, len(content))
    return result


@router.get("/media/{kind}/{name}")
def media(kind: str, name: str, request: Request):
    """ارائه امن فایل — فقط الگوی نام معتبر؛ هر مسیر دیگری ۴۰۴ می‌شود."""
    from ..security import safe_media_name
    if not safe_media_name(kind, name):
        raise HTTPException(404, "فایل یافت نشد")
    try:
        folder = _folder_for(kind)()
    except KeyError:
        raise HTTPException(404, "فایل یافت نشد")
    path = folder / name
    if not path.is_file() or not str(path.resolve()).startswith(str(folder.resolve())):
        raise HTTPException(404, "فایل یافت نشد")
    mime = {"png": "image/png", "jpg": "image/jpeg", "jpeg": "image/jpeg",
            "pdf": "application/pdf", "zip": "application/zip"}.get(name.rsplit(".", 1)[-1], "application/octet-stream")
    return FileResponse(str(path), media_type=mime)
