"""روتر عمومی: سلامت سرویس، داشبورد، گزارش‌ها، سازمان، تنظیمات و رویدادها."""
from __future__ import annotations

import re

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field

from ..dal import letters as letters_dal
from ..dal import misc as misc_dal
from .. import config

router = APIRouter()


def get_conn(request: Request):
    return request.app.state.conn


def require_json_content_type(request: Request) -> None:
    """الزام Content-Type مناسب برای درخواست‌های JSON (لایه تکمیلی ضد CSRF)."""
    ct = (request.headers.get("content-type") or "").lower()
    if not (ct.startswith("application/json") or ct.startswith("multipart/form-data")):
        raise HTTPException(status_code=415, detail="نوع محتوای درخواست مجاز نیست")


class OrgIn(BaseModel):
    name: str = Field(min_length=2, max_length=150)
    legal_form: str = Field(default="", max_length=100)
    national_id: str = Field(default="", max_length=20)
    economic_code: str = Field(default="", max_length=20)
    registration_no: str = Field(default="", max_length=20)
    address: str = Field(default="", max_length=500)
    postal_code: str = Field(default="", max_length=12)
    phone: str = Field(default="", max_length=40)
    email: str = Field(default="", max_length=120)
    website: str = Field(default="", max_length=150)
    logo_path: str = Field(default="", max_length=200)
    stamp_path: str = Field(default="", max_length=200)

    def clean(self) -> dict:
        from ..security import sanitize_text
        d = self.model_dump()
        for k, v in d.items():
            d[k] = sanitize_text(v, 500)
        if self.postal_code and not re.fullmatch(r"\d{10}", self.postal_code or ""):
            raise HTTPException(422, "کد پستی باید ۱۰ رقم باشد")
        if self.email and not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", self.email or ""):
            raise HTTPException(422, "ایمیل معتبر نیست")
        return d


@router.get("/health")
def health(request: Request):
    conn = get_conn(request)
    db_ok = conn.execute("SELECT 1").fetchone() is not None
    return {
        "ok": True, "app": "YarNameh", "version": config.APP_VERSION,
        "db_ok": db_ok, "schema_version": request.app.state.schema_version,
        "data_dir": str(config.data_dir()),
    }


@router.get("/dashboard")
def dashboard(request: Request):
    conn = get_conn(request)
    stats = letters_dal.dashboard_stats(conn)
    last_backup = misc_dal.get_setting(conn, "last_backup_at")
    org = misc_dal.get_default_org(conn)
    stats["last_backup_at"] = last_backup
    stats["org_name"] = (org or {}).get("name", "")
    return stats


@router.get("/reports")
def reports(request: Request, year: int = 0):
    conn = get_conn(request)
    return letters_dal.reports(conn, year or None)


@router.get("/organization")
def get_org(request: Request):
    return misc_dal.get_default_org(get_conn(request)) or {}


@router.put("/organization")
def save_org(payload: OrgIn, request: Request):
    require_json_content_type(request)
    conn = get_conn(request)
    with conn:
        oid = misc_dal.upsert_default_org(conn, payload.clean())
        misc_dal.log_action(conn, "org.update", "organization", oid)
    return misc_dal.get_default_org(conn) or {}


@router.get("/audit")
def audit(request: Request, limit: int = 100):
    limit = max(1, min(limit, 300))
    return misc_dal.recent_logs(get_conn(request), limit)
