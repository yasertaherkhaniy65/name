"""
روتر هوش مصنوعی — آماده برای GLM API.
- کلید API فقط در دیتابیس محلی ذخیره می‌شود و هرگز به رابط کاربری ارسال نمی‌گردد
- در نبود کلید یا اینترنت، سرویس اصلی برنامه بدون خطا کار می‌کند
- هوش مصنوعی هرگز برای شماره‌گذاری رسمی، تاریخ قطعی یا ذخیره‌سازی استفاده نمی‌شود
"""
from __future__ import annotations

import json

import httpx
from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel, Field

from ..dal.misc import get_setting, set_setting, log_action
from ..security import sanitize_text

router = APIRouter(prefix="/ai")

DEFAULT_ENDPOINT = "https://open.bigmodel.cn/api/paas/v4/chat/completions"
DEFAULT_MODEL = "glm-4-flash"
TIMEOUT = 30


def get_conn(request: Request):
    return request.app.state.conn


def _ai_config(conn) -> dict:
    return {
        "api_key": get_setting(conn, "ai_api_key", "") or "",
        "endpoint": get_setting(conn, "ai_endpoint", DEFAULT_ENDPOINT) or DEFAULT_ENDPOINT,
        "model": get_setting(conn, "ai_model", DEFAULT_MODEL) or DEFAULT_MODEL,
    }


class AIConfigIn(BaseModel):
    api_key: str = Field(default="", max_length=200)
    endpoint: str = Field(default="", max_length=300)
    model: str = Field(default="", max_length=100)


class DraftIn(BaseModel):
    description: str = Field(min_length=5, max_length=3000)
    tone: str = Field(default="formal", max_length=20)
    extra: str = Field(default="", max_length=1000)


class RewriteIn(BaseModel):
    text: str = Field(min_length=5, max_length=20000)
    mode: str = Field(default="formal")  # formal | concise | grammar


class SubjectIn(BaseModel):
    text: str = Field(min_length=5, max_length=20000)


class SuggestTemplateIn(BaseModel):
    description: str = Field(min_length=5, max_length=3000)


class ExtractIn(BaseModel):
    text: str = Field(min_length=10, max_length=20000)
    template_id: int


class CheckIn(BaseModel):
    text: str = Field(min_length=10, max_length=20000)
    template_id: int


@router.get("/status")
def status(request: Request):
    conn = get_conn(request)
    cfg = _ai_config(conn)
    return {"enabled": bool(cfg["api_key"]), "model": cfg["model"],
            "endpoint": cfg["endpoint"] if cfg["api_key"] else ""}


@router.put("/config")
def save_config(payload: AIConfigIn, request: Request):
    conn = get_conn(request)
    with conn:
        if payload.api_key:
            set_setting(conn, "ai_api_key", payload.api_key.strip())
        elif payload.api_key == "":
            set_setting(conn, "ai_api_key", "")
        if payload.endpoint:
            set_setting(conn, "ai_endpoint", sanitize_text(payload.endpoint, 300))
        if payload.model:
            set_setting(conn, "ai_model", sanitize_text(payload.model, 100))
        log_action(conn, "ai.config", "settings")
    cfg = _ai_config(conn)
    return {"enabled": bool(cfg["api_key"]), "model": cfg["model"]}


async def _call_glm(conn, system_prompt: str, user_prompt: str, max_tokens: int = 2000) -> str:
    cfg = _ai_config(conn)
    if not cfg["api_key"]:
        raise HTTPException(409, "کلید API هوش مصنوعی تنظیم نشده است؛ از صفحه تنظیمات اقدام کنید")
    payload = {
        "model": cfg["model"],
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ],
        "max_tokens": max_tokens,
        "temperature": 0.4,
    }
    headers = {"Authorization": f"Bearer {cfg['api_key']}", "Content-Type": "application/json"}
    try:
        async with httpx.AsyncClient(timeout=TIMEOUT) as client:
            resp = await client.post(cfg["endpoint"], json=payload, headers=headers)
    except httpx.HTTPError:
        raise HTTPException(503, "ارتباط با سرویس هوش مصنوعی برقرار نشد؛ اینترنت را بررسی کنید")
    if resp.status_code == 401:
        raise HTTPException(401, "کلید API نامعتبر است")
    if resp.status_code != 200:
        raise HTTPException(502, "سرویس هوش مصنوعی خطا برگرداند")
    try:
        data = resp.json()
        return (data["choices"][0]["message"]["content"] or "").strip()
    except Exception:
        raise HTTPException(502, "پاسخ نامعتبر از سرویس هوش مصنوعی")


SYSTEM_BASE = (
    "تو دستیار نگارش نامه‌های اداری رسمی فارسی در نرم‌افزار یارنامه هستی. "
    "همیشه متن رسمی، محترمانه و مطابق آیین نگارش اداری ایران تولید کن. "
    "خروجی را بدون توضیح اضافه و بدون علامت گذاری مارک‌داون ارائه بده."
)


@router.post("/draft")
async def draft(payload: DraftIn, request: Request):
    conn = get_conn(request)
    tone = {"formal": "رسمی و اداری", "warm": "رسمی ولی صمیمانه", "firm": "رسمی و قاطع"}.get(
        payload.tone, "رسمی و اداری")
    text = await _call_glm(
        conn, SYSTEM_BASE,
        f"یک نامه اداری {tone} بنویس.\nشرح درخواست کاربر: {sanitize_text(payload.description, 3000)}"
        + (f"\nنکات تکمیلی: {sanitize_text(payload.extra, 1000)}" if payload.extra else ""))
    with conn:
        log_action(conn, "ai.draft", "ai")
    return {"text": text}


@router.post("/rewrite")
async def rewrite(payload: RewriteIn, request: Request):
    conn = get_conn(request)
    mode_prompt = {
        "formal": "متن زیر را رسمی‌تر و اداری‌تر بازنویسی کن (حفظ کامل معنا):",
        "concise": "متن زیر را خلاصه‌تر و شفاف‌تر بازنویسی کن (حفظ نکات کلیدی):",
        "grammar": "غلط‌های نگارشی و املا و نشانه‌گذاری متن زیر را اصلاح کن (بدون تغییر معنا):",
    }.get(payload.mode, "متن زیر را رسمی‌تر بازنویسی کن:")
    text = await _call_glm(conn, SYSTEM_BASE, f"{mode_prompt}\n\n{payload.text}")
    return {"text": text}


@router.post("/subject")
async def subject(payload: SubjectIn, request: Request):
    conn = get_conn(request)
    text = await _call_glm(
        conn,
        "تو پیشنهاددهنده موضوع نامه اداری هستی. فقط یک خط موضوع کوتاه و رسمی بده.",
        f"برای نامه زیر یک موضوع مناسب پیشنهاد بده:\n\n{payload.text}", 100)
    return {"subject": text.strip('"«» ')}


@router.post("/suggest-template")
async def suggest_template(payload: SuggestTemplateIn, request: Request):
    conn = get_conn(request)
    from ..dal.templates import list_templates
    titles = [t["title"] for t in list_templates(conn, active="1")][:60]
    text = await _call_glm(
        conn,
        "تو الگوی مناسب نامه را از فهرست انتخاب می‌کنی. فقط و فقط نام دقیق یکی از الگوها را برگردان.",
        f"شرح نیاز کاربر: {sanitize_text(payload.description, 3000)}\n\nفهرست الگوها:\n" +
        "\n".join(titles), 60)
    return {"template_title": text.strip('"«» ')}


@router.post("/extract-params")
async def extract_params(payload: ExtractIn, request: Request):
    """استخراج مقادیر پارامترها از متن آزاد کاربر — خروجی JSON از مدل، اعتبارسنجی سمت سرور."""
    conn = get_conn(request)
    from ..dal.templates import get_template
    t = get_template(conn, payload.template_id)
    if not t:
        raise HTTPException(404, "الگو یافت نشد")
    fields_desc = "\n".join(
        f"- {f['field_key']} ({f['label']})" + (f" گزینه‌ها: {'، '.join(f['options'])}" if f.get("options") else "")
        for f in t["fields"])
    text = await _call_glm(
        conn,
        "تو مقادیر فیلدهای نامه را از متن استخراج می‌کنی. فقط یک JSON معتبر با کلیدهای داده‌شده برگردان؛ "
        "فیلدهای ناموجود را خالی بگذار. هیچ توضیح اضافه ننویس.",
        f"متن کاربر:\n{payload.text}\n\nفیلدها:\n{fields_desc}\n\nفقط JSON برگردان.")
    try:
        start, end = text.find("{"), text.rfind("}")
        if start == -1 or end == -1:
            raise ValueError
        data = json.loads(text[start:end + 1])
        allowed = {f["field_key"] for f in t["fields"]}
        return {"values": {k: str(v)[:500] for k, v in data.items() if k in allowed}}
    except Exception:
        raise HTTPException(502, "استخراج پارامترها ناموفق بود؛ لطفاً دستی وارد کنید")


@router.post("/check-completeness")
async def check_completeness(payload: CheckIn, request: Request):
    conn = get_conn(request)
    from ..dal.templates import get_template
    t = get_template(conn, payload.template_id)
    if not t:
        raise HTTPException(404, "الگو یافت نشد")
    required = "، ".join(f["label"] for f in t["fields"] if f.get("is_required"))
    text = await _call_glm(
        conn,
        "تو بازبین نامه اداری هستی. کوتاه و کاربردی پاسخ بده: نقص‌های اطلاعات را فهرست کن؛ اگر کامل است عبارت «کامل است» را بنویس.",
        f"نوع نامه: {t['title']}\nاطلاعات الزامی این نوع نامه: {required}\n\nمتن نامه:\n{payload.text}", 600)
    return {"review": text}
