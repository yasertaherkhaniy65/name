"""روتر امضاکنندگان و مهرها."""
from __future__ import annotations

import secrets

from fastapi import APIRouter, HTTPException, Request, UploadFile, File
from pydantic import BaseModel, Field

from ..dal import misc as dal
from .. import config
from ..security import sanitize_text, detect_image_ext

router = APIRouter(prefix="/signatories")

MAX_IMAGE_SIZE = 5 * 1024 * 1024  # 5MB


def get_conn(request: Request):
    return request.app.state.conn


class SignatoryIn(BaseModel):
    full_name: str = Field(min_length=2, max_length=120)
    position: str = Field(min_length=2, max_length=120)
    unit: str = Field(default="", max_length=120)
    signature_image_path: str = Field(default="", max_length=200)
    stamp_image_path: str = Field(default="", max_length=200)
    sort_order: int = Field(default=0)
    is_active: bool = True
    notes: str = Field(default="", max_length=1000)

    def clean(self) -> dict:
        d = self.model_dump()
        d["full_name"] = sanitize_text(d["full_name"], 120)
        d["position"] = sanitize_text(d["position"], 120)
        d["unit"] = sanitize_text(d["unit"], 120)
        d["notes"] = sanitize_text(d["notes"], 1000)
        for k in ("signature_image_path", "stamp_image_path"):
            if d[k] and not d[k].startswith("files/"):
                d[k] = ""
        return d


def _save_image(upload: UploadFile, folder) -> str:
    content = upload.file.read(MAX_IMAGE_SIZE + 1)
    if len(content) > MAX_IMAGE_SIZE:
        raise HTTPException(413, "حجم تصویر بیش از حد مجاز است")
    ext = detect_image_ext(content[:16])
    if not ext:
        raise HTTPException(415, "فقط تصویر PNG یا JPG معتبر است")
    name = secrets.token_hex(16) + ext
    path = folder / name
    path.write_bytes(content)
    return f"files/{folder.name}/{name}"


@router.get("")
def list_all(request: Request, q: str = "", active: str = ""):
    return dal.list_signatories(get_conn(request), sanitize_text(q, 80), active)


@router.post("")
def create(payload: SignatoryIn, request: Request):
    conn = get_conn(request)
    with conn:
        sid = dal.create_signatory(conn, payload.clean())
        dal.log_action(conn, "signatory.create", "signatory", sid)
    return {"id": sid}


@router.put("/{sid}")
def update(sid: int, payload: SignatoryIn, request: Request):
    conn = get_conn(request)
    if not dal.get_signatory(conn, sid):
        raise HTTPException(404, "امضاکننده یافت نشد")
    with conn:
        dal.update_signatory(conn, sid, payload.clean())
        dal.log_action(conn, "signatory.update", "signatory", sid)
    return {"ok": True}


@router.delete("/{sid}")
def delete(sid: int, request: Request):
    conn = get_conn(request)
    with conn:
        dal.delete_signatory(conn, sid)
        dal.log_action(conn, "signatory.delete", "signatory", sid)
    return {"ok": True}


@router.post("/{sid}/image")
async def upload_image(sid: int, request: Request, kind: str = "signature",
                       file: UploadFile = File(...)):
    conn = get_conn(request)
    sig = dal.get_signatory(conn, sid)
    if not sig:
        raise HTTPException(404, "امضاکننده یافت نشد")
    if kind not in ("signature", "stamp"):
        raise HTTPException(422, "نوع تصویر معتبر نیست")
    path = _save_image(file, config.signatures_dir() if kind == "signature" else config.stamps_dir())
    with conn:
        if kind == "signature":
            conn.execute("UPDATE signatories SET signature_image_path=?, updated_at=datetime('now','localtime') WHERE id=?", (path, sid))
        else:
            conn.execute("UPDATE signatories SET stamp_image_path=?, updated_at=datetime('now','localtime') WHERE id=?", (path, sid))
        dal.log_action(conn, "signatory.image", "signatory", sid, {"kind": kind})
    return {"path": path}
