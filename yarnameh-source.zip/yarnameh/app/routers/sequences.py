"""روتر شماره‌گذاری نامه‌ها."""
from __future__ import annotations

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel, Field

from ..dal import letters as dal
from ..security import sanitize_text

router = APIRouter(prefix="/sequences")


def get_conn(request: Request):
    return request.app.state.conn


class SequenceIn(BaseModel):
    name: str = Field(min_length=2, max_length=100)
    prefix: str = Field(default="", max_length=15)
    number_width: int = Field(default=4, ge=2, le=8)
    separator: str = Field(default="-", max_length=3)
    include_year: bool = True
    year_prefix: bool = False
    reset_yearly: bool = True
    is_active: bool = True

    def clean(self) -> dict:
        d = self.model_dump()
        d["name"] = sanitize_text(d["name"], 100)
        d["prefix"] = sanitize_text(d["prefix"], 15).upper().replace(" ", "-")
        d["separator"] = d["separator"] if d["separator"] in ("-", "/", ".") else "-"
        return d


@router.get("")
def list_all(request: Request):
    conn = get_conn(request)
    items = dal.list_sequences(conn)
    for s in items:
        s["preview"] = dal.sequence_preview(conn, s["id"])
    return items


@router.post("")
def create(payload: SequenceIn, request: Request):
    conn = get_conn(request)
    with conn:
        sid = dal.create_sequence(conn, payload.clean())
    return {"id": sid}


@router.put("/{sid}")
def update(sid: int, payload: SequenceIn, request: Request):
    conn = get_conn(request)
    if not dal.get_sequence(conn, sid):
        raise HTTPException(404, "شماره‌گذار یافت نشد")
    with conn:
        dal.update_sequence(conn, sid, payload.clean())
    return {"ok": True}
