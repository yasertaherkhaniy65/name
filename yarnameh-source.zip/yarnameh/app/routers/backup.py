"""روتر پشتیبان‌گیری و بازیابی — با SQLite Backup API برای سازگاری کامل."""
from __future__ import annotations

import shutil
import sqlite3
import tarfile
import tempfile
from datetime import datetime
from pathlib import Path

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field

from .. import config, database
from ..dal.misc import get_setting, set_setting, log_action, all_settings
from ..security import filename_is_safe

router = APIRouter(prefix="/backup")


def get_conn(request: Request):
    return request.app.state.conn


class RestoreIn(BaseModel):
    file_name: str = Field(min_length=5, max_length=200)


def _create_backup(dest_dir: Path) -> Path:
    """پشتیبان کامل: دیتابیس (Backup API) + فایل‌ها، در یک بسته tar.
    استفاده از sqlite3.Connection.backup تضمین می‌کند نسخه پشتیبان سازگار و کامل باشد."""
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    dest_dir.mkdir(parents=True, exist_ok=True)
    out_path = dest_dir / f"yarnameh-backup-{stamp}.tar"
    with tempfile.TemporaryDirectory() as tmp:
        tmp = Path(tmp)
        db_copy = tmp / config.DB_FILENAME
        src = database.connect()
        try:
            src.backup(sqlite3.connect(str(db_copy)))
        finally:
            src.close()
        # اسنپ‌شات تنظیمات برای انتقال بین سیستم‌ها
        settings_snapshot = tmp / "config.json"
        if config.config_file().exists():
            shutil.copy2(config.config_file(), settings_snapshot)
        with tarfile.open(out_path, "w") as tar:
            tar.add(db_copy, arcname=config.DB_FILENAME)
            if settings_snapshot.exists():
                tar.add(settings_snapshot, arcname="config.json")
            files_root = config.files_dir()
            if files_root.exists():
                for p in sorted(files_root.rglob("*")):
                    if p.is_file():
                        tar.add(p, arcname=str(p.relative_to(config.data_dir())))
    return out_path


@router.get("/list")
def list_backups(request: Request):
    conn = get_conn(request)
    items = []
    for p in sorted(config.backups_dir().glob("yarnameh-backup-*.tar"), reverse=True):
        items.append({"file_name": p.name, "size": p.stat().st_size,
                      "created_at": datetime.fromtimestamp(p.stat().st_mtime).strftime("%Y-%m-%d %H:%M")})
    return {"items": items, "last_backup_at": get_setting(conn, "last_backup_at"),
            "backups_dir": str(config.backups_dir())}


@router.post("/create")
def create_backup(request: Request):
    conn = get_conn(request)
    try:
        path = _create_backup(config.backups_dir())
    except Exception:
        raise HTTPException(500, "خطا در تهیه نسخه پشتیبان — جزئیات در فایل ثبت رویداد")
    stamp = datetime.now().strftime("%Y-%m-%d %H:%M")
    with conn:
        set_setting(conn, "last_backup_at", stamp)
        log_action(conn, "backup.create", "backup", None, {"file": path.name})
    return {"ok": True, "file_name": path.name, "size": path.stat().st_size, "created_at": stamp}


@router.get("/download/{file_name}")
def download(file_name: str, request: Request):
    if not filename_is_safe(file_name) or not file_name.startswith("yarnameh-backup-"):
        raise HTTPException(404, "فایل یافت نشد")
    path = config.backups_dir() / file_name
    if not path.is_file():
        raise HTTPException(404, "فایل یافت نشد")
    return FileResponse(str(path), filename=file_name,
                        media_type="application/x-tar")


@router.post("/restore")
def restore(payload: RestoreIn, request: Request):
    """
    بازیابی با کنترل ایمنی:
    ۱) اعتبارسنجی بسته و سلامت دیتابیس داخلی (integrity_check)
    ۲) تهیه پشتیبان خودکار از وضعیت فعلی قبل از جایگزینی
    ۳) جایگزینی دیتابیس و فایل‌ها
    """
    if not filename_is_safe(payload.file_name) or not payload.file_name.startswith("yarnameh-backup-"):
        raise HTTPException(404, "فایل پشتیبان یافت نشد")
    src = config.backups_dir() / payload.file_name
    if not src.is_file():
        raise HTTPException(404, "فایل پشتیبان یافت نشد")

    conn = get_conn(request)
    tmp = Path(tempfile.mkdtemp())
    try:
        with tarfile.open(src, "r") as tar:
            members = tar.getnames()
            if config.DB_FILENAME not in members:
                raise HTTPException(422, "بسته پشتیبان معتبر نیست (فایل دیتابیس یافت نشد)")
            tar.extractall(tmp)
        db_file = tmp / config.DB_FILENAME
        if not database.check_integrity(db_file):
            raise HTTPException(422, "فایل پشتیبان سالم نیست (integrity check ناموفق)")
        # پشتیبان خودکار از وضعیت فعلی (قبل از هر جایگزینی)
        safety = _create_backup(config.backups_dir() / "auto-before-restore")
        if not safety.exists():
            safety = _create_backup(config.backups_dir())
        # جایگزینی دیتابیس با اتصال مجدد امن
        conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")
        conn.close()
        shutil.copy2(db_file, config.db_path())
        new_conn = database.connect()
        database.apply_migrations(new_conn)
        request.app.state.conn = new_conn
        # جایگزینی فایل‌ها
        for sub in ("signatures", "stamps", "logos", "attachments", "inline"):
            src_sub = tmp / "files" / sub
            dst_sub = config.files_dir() / sub
            dst_sub.mkdir(parents=True, exist_ok=True)
            if src_sub.exists():
                for f in src_sub.iterdir():
                    shutil.copy2(f, dst_sub / f.name)
        if (tmp / "config.json").exists():
            shutil.copy2(tmp / "config.json", config.config_file())
        return {"ok": True, "message": "بازیابی انجام شد؛ در صورت باز بودن رابط، صفحه را نوسازی کنید",
                "safety_backup": safety.name}
    except HTTPException:
        raise
    except Exception:
        raise HTTPException(500, "خطا در بازیابی — جزئیات در فایل ثبت رویداد")
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@router.get("/settings")
def settings_snapshot(request: Request):
    return all_settings(get_conn(request))
