"""روتر مخاطبین."""
from __future__ import annotations

import re

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field

from ..dal import contacts as dal

router = APIRouter(prefix="/contacts")

KINDS = {"person", "company", "bank", "government", "organization", "other"}


def get_conn(request: Request):
    return request.app.state.conn


class ContactIn(BaseModel):
    kind: str = Field(default="organization")
    name: str = Field(min_length=2, max_length=150)
    company_name: str = Field(default="", max_length=150)
    salutation: str = Field(default="", max_length=100)
    position: str = Field(default="", max_length=100)
    national_id: str = Field(default="", max_length=20)
    economic_code: str = Field(default="", max_length=20)
    customer_no: str = Field(default="", max_length=40)
    address: str = Field(default="", max_length=500)
    postal_code: str = Field(default="", max_length=12)
    phone: str = Field(default="", max_length=60)
    email: str = Field(default="", max_length=120)
    notes: str = Field(default="", max_length=1000)
    is_active: bool = True

    def clean(self) -> dict:
        from ..security import sanitize_text
        d = self.model_dump()
        for k, v in d.items():
            d[k] = sanitize_text(v, 500)
        if d["kind"] not in KINDS:
            raise HTTPException(422, "نوع مخاطب معتبر نیست")
        if d["national_id"] and not re.fullmatch(r"\d{10,11}", d["national_id"]):
            raise HTTPException(422, "شناسه ملی/کد ملی باید ۱۰ یا ۱۱ رقم باشد")
        if d["postal_code"] and not re.fullmatch(r"\d{10}", d["postal_code"]):
            raise HTTPException(422, "کد پستی باید ۱۰ رقم باشد")
        if d["email"] and not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", d["email"]):
            raise HTTPException(422, "ایمیل معتبر نیست")
        return d


@router.get("")
def list_contacts(request: Request, q: str = "", kind: str = "", active: str = "",
                  page: int = 1, page_size: int = 25):
    page = max(1, min(page, 1000))
    page_size = max(5, min(page_size, 100))
    return dal.list_contacts(get_conn(request), q.strip()[:80], kind, active, page, page_size)


@router.get("/similar")
def similar(request: Request, name: str = "", exclude_id: int = 0):
    return {"items": dal.find_similar(get_conn(request), name.strip()[:150], exclude_id)}


@router.post("")
def create(payload: ContactIn, request: Request):
    conn = get_conn(request)
    data = payload.clean()
    with conn:
        cid = dal.create_contact(conn, data)
        from ..dal.misc import log_action
        log_action(conn, "contact.create", "contact", cid, {"name": data["name"]})
    return {"id": cid, "duplicates": dal.find_similar(conn, data["name"], exclude_id=cid)}


@router.get("/{contact_id}")
def get_one(contact_id: int, request: Request):
    c = dal.get_contact(get_conn(request), contact_id)
    if not c:
        raise HTTPException(404, "مخاطب یافت نشد")
    return c


@router.put("/{contact_id}")
def update(contact_id: int, payload: ContactIn, request: Request):
    conn = get_conn(request)
    if not dal.get_contact(conn, contact_id):
        raise HTTPException(404, "مخاطب یافت نشد")
    with conn:
        dal.update_contact(conn, contact_id, payload.clean())
        from ..dal.misc import log_action
        log_action(conn, "contact.update", "contact", contact_id)
    return {"ok": True}


@router.delete("/{contact_id}")
def delete(contact_id: int, request: Request, force: bool = False):
    """حذف کامل فقط بدون ارجاع؛ در صورت استفاده، غیرفعال‌سازی (force=1)."""
    conn = get_conn(request)
    if not dal.get_contact(conn, contact_id):
        raise HTTPException(404, "مخاطب یافت نشد")
    ok, used = dal.delete_contact(conn, contact_id)
    if not ok:
        if force:
            dal.set_active(conn, contact_id, False)
            return {"ok": True, "deactivated": True,
                    "message": f"مخاطب در {used} نامه استفاده شده است؛ به‌جای حذف، غیرفعال شد تا سوابق حفظ شوند"}
        raise HTTPException(409, {"message": "این مخاطب در نامه‌های ثبت‌شده استفاده شده است",
                                  "usage_count": used,
                                  "suggestion": "می‌توانید مخاطب را غیرفعال کنید یا حذف را تأیید کنید"})
    from ..dal.misc import log_action
    with conn:
        log_action(conn, "contact.delete", "contact", contact_id)
    return {"ok": True}
