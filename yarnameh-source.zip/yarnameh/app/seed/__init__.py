"""یارنامه — الگوهای آماده اولیه: ۳۰ الگو در ۴ دسته + بارگذاری امن در دیتابیس."""
from __future__ import annotations

import json
import re
import sqlite3

from . import bank, hr, tax, commercial

CATEGORY_ORDER = ["بانکی و مالی", "منابع انسانی", "مالیاتی و حسابداری", "اداری و تجاری"]

ALLOWED_TYPES = {
    "text", "textarea", "number", "amount", "jalali_date", "select",
    "contact", "signatory", "org", "id_no", "bool", "multiselect",
    "phone", "attachments_list", "notes",
}


def all_templates() -> list[dict]:
    """تجمیع الگوهای چهار دسته + اتصال بلوک‌های شرطی هر دسته."""
    result: list[dict] = []
    for mod in (bank, hr, tax, commercial):
        blocks = getattr(mod, "BLOCK_FIELDS", {})
        for t in mod.TEMPLATES:
            t = dict(t)
            t["blocks"] = blocks
            t["is_system"] = 1
            result.append(t)
    return result


# رجیستری دائمی بلوک‌های شرطی الگوهای آماده (عنوان → بلوک‌ها)
SEED_BLOCKS: dict[str, dict] = {t["title"]: t["blocks"] for t in all_templates()}


def validate_seed() -> list[str]:
    """بررسی سلامت تعاریف الگوها (کلید یکتا، نوع معتبر، متغیرها موجود)."""
    problems: list[str] = []
    seen_keys: set[str] = set()
    for t in all_templates():
        title = t["title"]
        if title in seen_keys:
            problems.append(f"عنوان تکراری: {title}")
        seen_keys.add(title)
        field_keys = set()
        for f in t.get("fields", []):
            if f["key"] in field_keys:
                problems.append(f"پارامتر تکراری در «{title}»: {f['key']}")
            field_keys.add(f["key"])
            if f.get("type") not in ALLOWED_TYPES:
                problems.append(f"نوع نامعتبر «{f.get('type')}» در «{title}» پارامتر {f['key']}")
        for var in _extract_vars(t["body"]):
            base = var.replace("_block", "").replace("_line", "")
            if var not in field_keys and base not in field_keys and var not in (
                    "letter_number", "letter_date", "today_jalali"):
                if var not in (t.get("blocks") or {}):
                    problems.append(f"متغیر بی‌تعریف «{var}» در متن الگوی «{title}»")
    return problems


def _extract_vars(body: str) -> set[str]:
    return set(re.findall(r"\{\{\s*([a-zA-Z0-9_]+)\s*\}\}", body))


def seed_if_empty(conn: sqlite3.Connection) -> int:
    """بارگذاری الگوهای آماده — فقط الگوهایی که وجود ندارند اضافه می‌شوند (idempotent)."""
    problems = validate_seed()
    if problems:
        raise RuntimeError("خطا در تعاریف الگوهای آماده: " + "; ".join(problems))
    inserted = 0
    with conn:
        conn.execute("BEGIN IMMEDIATE")
        try:
            existing = {r["title"] for r in
                        conn.execute("SELECT title FROM templates WHERE is_system=1").fetchall()}
            for order, t in enumerate(all_templates()):
                if t["title"] in existing:
                    continue
                cur = conn.execute(
                    """INSERT INTO templates (title, category, description, body_html, paper_size,
                       orientation, margin_preset, is_system, is_active, sort_order)
                       VALUES (?,?,?,?,?,?,?,?,?,?)""",
                    (t["title"], t["category"], t["description"], t["body"],
                     t.get("paper", "A4"), t.get("orientation", "portrait"),
                     t.get("margin_preset", "normal"), 1, 1, order))
                tid = cur.lastrowid
                for i, f in enumerate(t.get("fields", [])):
                    conn.execute(
                        """INSERT INTO template_fields (template_id, field_key, label, field_type,
                           is_required, default_value, help_text, group_name, options_json,
                           validation_regex, source_type, sort_order)
                           VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
                        (tid, f["key"], f["label"], f.get("type", "text"),
                         1 if f.get("required") else 0, f.get("default"), f.get("help"),
                         f.get("group"), json.dumps(f.get("options") or [], ensure_ascii=False),
                         f.get("regex"), "manual", f.get("sort_order", i)))
                inserted += 1
            # شماره‌گذار پیش‌فرض
            if not conn.execute("SELECT 1 FROM number_sequences LIMIT 1").fetchone():
                conn.execute(
                    """INSERT INTO number_sequences (name, prefix, number_width, separator,
                       include_year, year_prefix, reset_yearly, is_active)
                       VALUES ('شماره‌گذاری پیش‌فرض', '', 4, '-', 1, 0, 1, 1)""")
            conn.execute("COMMIT")
        except Exception:
            conn.execute("ROLLBACK")
            raise
    return inserted
