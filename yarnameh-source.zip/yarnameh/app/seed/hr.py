"""الگوهای آماده — دسته منابع انسانی (۷ الگو)."""

TEMPLATES = [
    {
        "title": "درخواست مرخصی",
        "category": "منابع انسانی",
        "description": "درخواست مرخصی روزانه یا ساعتی کارکنان با ذکر نوع و علت",
        "fields": [
            {"key": "employee_name", "label": "نام کارمند", "type": "text", "required": True, "group": "مشخصات کارمند"},
            {"key": "personnel_no", "label": "کد پرسنلی", "type": "id_no", "required": True, "group": "مشخصات کارمند"},
            {"key": "unit", "label": "واحد سازمانی", "type": "text", "required": True, "group": "مشخصات کارمند"},
            {"key": "position", "label": "سمت", "type": "text", "group": "مشخصات کارمند"},
            {"key": "leave_type", "label": "نوع مرخصی", "type": "select", "required": True, "group": "مشخصات مرخصی",
             "options": ["استحقاقی", "استعلاجی", "بدون حقوق", "ساعتی", "تشویقی", "زایمان", "سایر"]},
            {"key": "from_date", "label": "تاریخ شروع", "type": "jalali_date", "required": True, "group": "مشخصات مرخصی"},
            {"key": "to_date", "label": "تاریخ پایان", "type": "jalali_date", "required": True, "group": "مشخصات مرخصی"},
            {"key": "duration", "label": "مدت (روز یا ساعت)", "type": "text", "required": True, "group": "مشخصات مرخصی", "help": "مثال: ۳ روز یا ۵ ساعت"},
            {"key": "reason", "label": "علت مرخصی", "type": "textarea", "required": True, "group": "مشخصات مرخصی"},
            {"key": "deputy_name", "label": "جانشین در دوره غیبت", "type": "text", "group": "اطلاعات تکمیلی"},
            {"key": "manager", "label": "مدیر / تأییدکننده", "type": "signatory", "group": "اطلاعات تکمیلی", "help": "امضاکننده تأییدکننده درخواست"},
            {"key": "extra_notes", "label": "توضیحات تکمیلی", "type": "notes", "group": "اطلاعات تکمیلی"},
        ],
        "body": """<p>با سلام و احترام؛</p>
<p>احتراماً، بازنشانی به استحضار می‌رساند اینجانب <b>{{employee_name}}</b> به کد پرسنلی <b>{{personnel_no}}</b> شاغل در واحد {{unit}}{{position_line}}، درخواست مرخصی <b>{{leave_type}}</b> به مدت <b>{{duration}}</b> از تاریخ <b>{{from_date}}</b> لغایت <b>{{to_date}}</b> را دارم.</p>
<p>علت درخواست: {{reason}}</p>
{{deputy_block}}
<p>خواهشمند است در صورت تصویب، دستور فرمایید مرخصی مربوطه در سوابق اینجانب ثبت گردد. در طول دوره مرخصی، پاسخگویی به امور محوله از طریق جانشین و تماس تلفنی انجام خواهد شد.</p>
{{extra_notes_block}}
<p>با سپاس فراوان.</p>""",
    },
    {
        "title": "درخواست افزایش حقوق",
        "category": "منابع انسانی",
        "description": "درخواست رسمی بازنگری و افزایش حقوق با ذکر دلایل",
        "fields": [
            {"key": "employee_name", "label": "نام کارمند", "type": "text", "required": True, "group": "مشخصات کارمند"},
            {"key": "personnel_no", "label": "کد پرسنلی", "type": "id_no", "required": True, "group": "مشخصات کارمند"},
            {"key": "unit", "label": "واحد سازمانی", "type": "text", "required": True, "group": "مشخصات کارمند"},
            {"key": "position", "label": "سمت فعلی", "type": "text", "required": True, "group": "مشخصات کارمند"},
            {"key": "employment_date", "label": "تاریخ استخدام", "type": "jalali_date", "group": "مشخصات کارمند"},
            {"key": "current_salary", "label": "حقوق فعلی (ریال)", "type": "amount", "group": "مشخصات درخواست"},
            {"key": "requested_salary", "label": "حقوق پیشنهادی (ریال)", "type": "amount", "group": "مشخصات درخواست"},
            {"key": "reasons", "label": "دلایل درخواست", "type": "textarea", "required": True, "group": "مشخصات درخواست"},
            {"key": "achievements", "label": "دستاوردها و سوابق عملکرد", "type": "textarea", "group": "مشخصات درخواست"},
            {"key": "receiver", "label": "مخاطب (مدیریت محترم)", "type": "contact", "group": "سایر"},
            {"key": "extra_notes", "label": "توضیحات تکمیلی", "type": "notes", "group": "سایر"},
        ],
        "body": """<p>با سلام و احترام؛</p>
<p>احتراماً، بازنشانی به استحضار می‌رساند اینجانب <b>{{employee_name}}</b> به کد پرسنلی {{personnel_no}}، از تاریخ {{employment_date_line}} در واحد {{unit}} به سمت {{position}} مشغول به خدمت بوده‌ام.</p>
<p>با توجه به موارد ذیل، درخواست بازنگری و افزایش حقوق اینجانب را دارم:</p>
<p>{{reasons}}</p>
{{achievements_block}}
{{salary_block}}
<p>خواهشمند است در صورت صلاحدید، دستور فرمایید درخواست اینجانب در کمیته مربوطه بررسی و نتیجه اعلام گردد.</p>
{{extra_notes_block}}
<p>پیشاپیش از بذل توجه جنابعالی سپاسگزارم.</p>""",
    },
    {
        "title": "درخواست مأموریت",
        "category": "منابع انسانی",
        "description": "درخواست اعزام مأموریت داخلی یا خارجی با ذکر هدف و هزینه‌ها",
        "fields": [
            {"key": "employee_name", "label": "نام کارمند", "type": "text", "required": True, "group": "مشخصات کارمند"},
            {"key": "personnel_no", "label": "کد پرسنلی", "type": "id_no", "required": True, "group": "مشخصات کارمند"},
            {"key": "unit", "label": "واحد سازمانی", "type": "text", "required": True, "group": "مشخصات کارمند"},
            {"key": "mission_type", "label": "نوع مأموریت", "type": "select", "required": True, "group": "مشخصات مأموریت",
             "options": ["داخلی", "خارج از کشور"]},
            {"key": "destination", "label": "مقصد", "type": "text", "required": True, "group": "مشخصات مأموریت"},
            {"key": "from_date", "label": "تاریخ شروع", "type": "jalali_date", "required": True, "group": "بازه زمانی"},
            {"key": "to_date", "label": "تاریخ پایان", "type": "jalali_date", "required": True, "group": "بازه زمانی"},
            {"key": "duration", "label": "مدت (روز)", "type": "number", "required": True, "group": "بازه زمانی"},
            {"key": "purpose", "label": "هدف مأموریت", "type": "textarea", "required": True, "group": "مشخصات مأموریت"},
            {"key": "companions", "label": "همراهان (در صورت وجود)", "type": "text", "group": "سایر"},
            {"key": "extra_notes", "label": "توضیحات تکمیلی", "type": "notes", "group": "سایر"},
        ],
        "body": """<p>با سلام و احترام؛</p>
<p>احتراماً، بازنشانی به استحضار می‌رساند اینجانب <b>{{employee_name}}</b> به کد پرسنلی {{personnel_no}} عضو واحد {{unit}}، درخواست اعزام به مأموریت <b>{{mission_type}}</b> به مقصد <b>{{destination}}</b> از تاریخ <b>{{from_date}}</b> لغایت <b>{{to_date}}</b> به مدت {{duration}} روز را دارم.</p>
<p>هدف از مأموریت: {{purpose}}</p>
{{companions_block}}
<p>خواهشمند است در صورت موافقت، دستور فرمایید حکم مأموریت صادر و مراحل مربوط به پذیرایی و حمل‌ونقل برابر آیین‌نامه‌های جاری انجام پذیرد.</p>
{{extra_notes_block}}
<p>با تشکر از توجه شما.</p>""",
    },
    {
        "title": "درخواست گواهی اشتغال به کار",
        "category": "منابع انسانی",
        "description": "درخواست صدور گواهی اشتغال به کار یا گواهی سوابق برای مراجع مختلف",
        "fields": [
            {"key": "employee_name", "label": "نام کارمند", "type": "text", "required": True, "group": "مشخصات کارمند"},
            {"key": "personnel_no", "label": "کد پرسنلی", "type": "id_no", "group": "مشخصات کارمند"},
            {"key": "national_id", "label": "کد ملی", "type": "id_no", "group": "مشخصات کارمند"},
            {"key": "unit", "label": "واحد سازمانی", "type": "text", "required": True, "group": "مشخصات شغلی"},
            {"key": "position", "label": "سمت", "type": "text", "required": True, "group": "مشخصات شغلی"},
            {"key": "employment_date", "label": "تاریخ شروع به کار", "type": "jalali_date", "required": True, "group": "مشخصات شغلی"},
            {"key": "cert_type", "label": "نوع گواهی", "type": "select", "required": True, "group": "مشخصات گواهی",
             "options": ["گواهی اشتغال به کار", "گواهی سوابق کاری", "گواهی حقوق و دستمزد", "گواهی به‌همراه بیمه", "سایر"]},
            {"key": "cert_purpose", "label": "مورد استفاده", "type": "text", "required": True, "group": "مشخصات گواهی", "help": "مثال: ارائه به بانک، سفارت، اداره و ..."},
            {"key": "include_salary", "label": "درج میزان حقوق در گواهی", "type": "bool", "group": "مشخصات گواهی"},
            {"key": "extra_notes", "label": "توضیحات تکمیلی", "type": "notes", "group": "سایر"},
        ],
        "body": """<p>با سلام و احترام؛</p>
<p>احتراماً، بازنشانی به استحضار می‌رساند اینجانب <b>{{employee_name}}</b>{{personnel_no_line}} درخواست صدور <b>{{cert_type}}</b> برای خودم را دارم.</p>
<p>مشخصات شغلی اینجانب به شرح ذیل است:</p>
<p>واحد سازمانی: {{unit}} — سمت: {{position}} — تاریخ شروع به کار: {{employment_date}}</p>
{{salary_include_block}}
<p>گواهی مورد درخواست جهت {{cert_purpose}} لازم است. خواهشمند است دستور فرمایید نسبت به صدور و امضای گواهی مربوطه اقدام گردد.</p>
{{extra_notes_block}}
<p>با سپاس از توجه شما.</p>""",
    },
    {
        "title": "معرفی‌نامه پرسنلی",
        "category": "منابع انسانی",
        "description": "صادرکردن معرفی‌نامه رسمی برای کارمند جهت مراجع مختلف",
        "fields": [
            {"key": "receiver", "label": "مرجع گیرنده معرفی‌نامه", "type": "contact", "group": "اطلاعات گیرنده", "help": "در صورت اطلاع؛ وگرنه دستی وارد کنید"},
            {"key": "employee_name", "label": "نام کارمند", "type": "text", "required": True, "group": "مشخصات کارمند"},
            {"key": "personnel_no", "label": "کد پرسنلی", "type": "id_no", "group": "مشخصات کارمند"},
            {"key": "national_id", "label": "کد ملی", "type": "id_no", "group": "مشخصات کارمند"},
            {"key": "position", "label": "سمت", "type": "text", "required": True, "group": "مشخصات شغلی"},
            {"key": "unit", "label": "واحد سازمانی", "type": "text", "group": "مشخصات شغلی"},
            {"key": "employment_date", "label": "تاریخ شروع به کار", "type": "jalali_date", "group": "مشخصات شغلی"},
            {"key": "intro_purpose", "label": "هدف معرفی‌نامه", "type": "text", "required": True, "group": "مشخصات معرفی‌نامه", "help": "مثال: انجام امور بانکی، افتتاح حساب، مراجعه به اداره و ..."},
            {"key": "validity", "label": "مدت اعتبار", "type": "text", "default": "یک‌بار استفاده", "group": "مشخصات معرفی‌نامه"},
            {"key": "extra_notes", "label": "توضیحات تکمیلی", "type": "notes", "group": "سایر"},
        ],
        "body": """<p>به نام خدا</p>
<p>با سلام و احترام؛</p>
<p>بازنشانی تأیید می‌نماید آقای/خانم <b>{{employee_name}}</b>{{personnel_id_line}} از کارکنان این شرکت در واحد {{unit}} به سمت <b>{{position}}</b>{{employment_line}} می‌باشد.</p>
<p>معرفی‌نامه حاضر صرفاً جهت {{intro_purpose}} صادر گردیده و مدت اعتبار آن {{validity}} است.</p>
<p>خواهشمند است مورد توجه و همکاری لازم قرار گیرد.</p>
{{extra_notes_block}}
<p>هرگونه ابهام در مورد اصالت این معرفی‌نامه قابل پیگیری از طریق واحد منابع انسانی شرکت خواهد بود.</p>""",
    },
    {
        "title": "درخواست تغییر سمت",
        "category": "منابع انسانی",
        "description": "درخواست جابه‌جایی یا ارتقای شغلی با ذکر سوابق و توانمندی‌ها",
        "fields": [
            {"key": "employee_name", "label": "نام کارمند", "type": "text", "required": True, "group": "مشخصات کارمند"},
            {"key": "personnel_no", "label": "کد پرسنلی", "type": "id_no", "required": True, "group": "مشخصات کارمند"},
            {"key": "current_position", "label": "سمت فعلی", "type": "text", "required": True, "group": "وضعیت شغلی"},
            {"key": "current_unit", "label": "واحد فعلی", "type": "text", "required": True, "group": "وضعیت شغلی"},
            {"key": "requested_position", "label": "سمت درخواستی", "type": "text", "required": True, "group": "درخواست"},
            {"key": "requested_unit", "label": "واحد درخواستی", "type": "text", "group": "درخواست"},
            {"key": "justification", "label": "دلایل و شایستگی‌ها", "type": "textarea", "required": True, "group": "درخواست"},
            {"key": "extra_notes", "label": "توضیحات تکمیلی", "type": "notes", "group": "سایر"},
        ],
        "body": """<p>با سلام و احترام؛</p>
<p>احتراماً، بازنشانی به استحضار می‌رساند اینجانب <b>{{employee_name}}</b> به کد پرسنلی {{personnel_no}}، در حال حاضر در واحد {{current_unit}} به سمت {{current_position}} مشغول به فعالیت هستم.</p>
<p>بدین‌وسیله درخواست انتقال به سمت <b>{{requested_position}}</b>{{requested_unit_line}} را دارم. دلایل و شایستگی‌های اینجانب به شرح ذیل است:</p>
<p>{{justification}}</p>
<p>خواهشمند است در صورت صلاحدید، دستور فرمایید این درخواست در کمیته ارزیابی و انتقال بررسی گردد.</p>
{{extra_notes_block}}
<p>پیشاپیش از توجه و حمایت جنابعالی سپاسگزارم.</p>""",
    },
    {
        "title": "درخواست تسویه‌حساب",
        "category": "منابع انسانی",
        "description": "درخواست تسویه‌حساب خروج از سازمان و انجام امور اداری مربوطه",
        "fields": [
            {"key": "employee_name", "label": "نام کارمند", "type": "text", "required": True, "group": "مشخصات کارمند"},
            {"key": "personnel_no", "label": "کد پرسنلی", "type": "id_no", "required": True, "group": "مشخصات کارمند"},
            {"key": "unit", "label": "واحد سازمانی", "type": "text", "required": True, "group": "مشخصات کارمند"},
            {"key": "position", "label": "سمت", "type": "text", "group": "مشخصات کارمند"},
            {"key": "last_work_date", "label": "تاریخ آخرین روز کاری", "type": "jalali_date", "required": True, "group": "مشخصات خروج"},
            {"key": "leave_type", "label": "نوع خروج", "type": "select", "required": True, "group": "مشخصات خروج",
             "options": ["استعفا", "پایان قرارداد", "بازنشستگی", "توافق طرفین", "سایر"]},
            {"key": "items_list", "label": "اموال و امور در دست تحویل", "type": "textarea", "group": "تحویل اموال", "help": "هر سطر یک مورد: لپ‌تاپ، کارت پارکینگ، پرونده‌ها و ..."},
            {"key": "extra_notes", "label": "توضیحات تکمیلی", "type": "notes", "group": "سایر"},
        ],
        "body": """<p>با سلام و احترام؛</p>
<p>احتراماً، بازنشانی به استحضار می‌رساند اینجانب <b>{{employee_name}}</b> به کد پرسنلی {{personnel_no}}، شاغل در واحد {{unit}}{{position_line}}، بنا به دلایل فوق‌الذکر درخواست تسویه‌حساب با نوع خروج <b>{{leave_type}}</b> را دارم. تاریخ آخرین روز کاری اینجانب <b>{{last_work_date}}</b> خواهد بود.</p>
{{items_block}}
<p>خواهشمند است دستور فرمایید مراحل تسویه‌حساب شامل تحویل اموال و اسناد، تسویه مالی و رفع تعهدات بیمه‌ای برابر رویه‌های جاری شرکت انجام پذیرد.</p>
{{extra_notes_block}}
<p>در خاتمه از همکاری صمیمانه کلیه همکاران و مدیریت محترم در طول دوره همکاری سپاسگزاری می‌نمایم.</p>""",
    },
]

BLOCK_FIELDS = {
    "position_line": " به سمت {{position}}",
    "deputy_block": "<p>جانشین اینجانب در دوره غیبت، جناب/سرکار {{deputy_name}} خواهد بود.</p>",
    "extra_notes_block": "<p>{{extra_notes}}</p>",
    "employment_date_line": "{{employment_date}}",
    "achievements_block": "<p>از مهم‌ترین اقدامات و دستاوردهای اینجانب در دوره همکاری: {{achievements}}</p>",
    "salary_block": "<p>حقوق فعلی: {{current_salary}} ریال — حقوق پیشنهادی: {{requested_salary}} ریال</p>",
    "companions_block": "<p>همراهان مأموریت: {{companions}}</p>",
    "personnel_no_line": " به کد پرسنلی {{personnel_no}}",
    "personnel_id_line": " به کد پرسنلی {{personnel_no}} (کد ملی: {{national_id}})",
    "employment_line": " از تاریخ {{employment_date}}",
    "salary_include_block": "<p>مستدعی است میزان حقوق و مزایای اینجانب نیز در گواهی درج گردد.</p>",
    "items_block": "<p>اموال و امور در دست تحویل به شرح ذیل است:<br>{{items_list}}</p>",
    "requested_unit_line": " در واحد {{requested_unit}}",
}
