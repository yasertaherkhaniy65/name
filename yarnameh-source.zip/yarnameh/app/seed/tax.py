"""الگوهای آماده — دسته مالیاتی و حسابداری (۶ الگو)."""

TEMPLATES = [
    {
        "title": "اعتراض به برگ تشخیص مالیات",
        "category": "مالیاتی و حسابداری",
        "description": "اعتراض رسمی به برگ تشخیص مالیات و درخواست رسیدگی در هیئت حل اختلاف",
        "fields": [
            {"key": "receiver", "label": "اداره امور مالیاتی مخاطب", "type": "contact", "required": True, "group": "اطلاعات مرجع"},
            {"key": "taxpayer_name", "label": "نام مؤدی", "type": "text", "required": True, "group": "مشخصات مؤدی"},
            {"key": "national_id", "label": "شناسه ملی / کد ملی", "type": "id_no", "required": True, "group": "مشخصات مؤدی"},
            {"key": "economic_code", "label": "کد اقتصادی", "type": "id_no", "group": "مشخصات مؤدی"},
            {"key": "file_no", "label": "شماره پرونده مالیاتی", "type": "id_no", "required": True, "group": "مشخصات پرونده"},
            {"key": "tax_type", "label": "نوع برگ مالیاتی", "type": "select", "required": True, "group": "مشخصات برگ",
             "options": ["برگ تشخیص", "برگ مالیات عملکرد", "برگ مالیات بر ارزش افزوده", "برگ مالیات حقوق", "سایر"]},
            {"key": "doc_number", "label": "شماره برگ", "type": "id_no", "required": True, "group": "مشخصات برگ"},
            {"key": "notify_date", "label": "تاریخ ابلاغ", "type": "jalali_date", "required": True, "group": "مشخصات برگ"},
            {"key": "tax_year", "label": "سال مالی", "type": "id_no", "required": True, "group": "مشخصات برگ"},
            {"key": "disputed_amount", "label": "مبلغ مورد اعتراض (ریال)", "type": "amount", "required": True, "group": "اعتراض"},
            {"key": "objection_desc", "label": "شرح اعتراض", "type": "textarea", "required": True, "group": "اعتراض"},
            {"key": "request_line", "label": "درخواست نهایی", "type": "textarea", "required": True, "group": "اعتراض"},
            {"key": "attachments_list", "label": "فهرست پیوست‌ها", "type": "attachments_list", "group": "پیوست‌ها", "help": "هر سطر یک مورد"},
            {"key": "extra_notes", "label": "توضیحات تکمیلی", "type": "notes", "group": "سایر"},
        ],
        "body": """<p>با سلام و احترام؛</p>
<p>احتراماً، به استحضار می‌رساند اینجانب/شرکت <b>{{taxpayer_name}}</b> به شناسه ملی/کد ملی {{national_id}}{{economic_code_line}} دارای پرونده مالیاتی شماره <b>{{file_no}}</b> نزد آن اداره محترم، برگ <b>{{tax_type}}</b> شماره {{doc_number}} برای سال مالی {{tax_year}} را در تاریخ {{notify_date}} ابلاغ‌شده دریافت نموده است.</p>
<p>با عنایت به مفاد برگ مذکور، مبلغ <b>{{disputed_amount}} ریال</b> به‌عنوان مالیات تعیین گردیده که اینجانب/شرکت نسبت به آن اعتراض دارم/داریم. شرح اعتراض به شرح ذیل است:</p>
<p>{{objection_desc}}</p>
<p>درخواست نهایی اینجانب/شرکت: {{request_line}}</p>
<p>لذا خواهشمند است دستور فرمایید پرونده اعتراضی جهت رسیدگی به هیئت حل اختلاف مالیاتی ارجاع گردد. توضیح آنکه مهلت قانونی اعتراض رعایت شده و رسیدگی‌های قبلی نیز ملاک دفاع اینجانب/شرکت خواهد بود.</p>
{{attachments_block}}
{{extra_notes_block}}
<p>با احترام.</p>""",
    },
    {
        "title": "درخواست تقسیط بدهی مالیاتی",
        "category": "مالیاتی و حسابداری",
        "description": "درخواست اقساط بدهی مالیاتی با ذکر توان پرداخت و ضمانت اجرایی",
        "fields": [
            {"key": "receiver", "label": "اداره امور مالیاتی مخاطب", "type": "contact", "required": True, "group": "اطلاعات مرجع"},
            {"key": "taxpayer_name", "label": "نام مؤدی", "type": "text", "required": True, "group": "مشخصات مؤدی"},
            {"key": "national_id", "label": "شناسه ملی / کد ملی", "type": "id_no", "required": True, "group": "مشخصات مؤدی"},
            {"key": "file_no", "label": "شماره پرونده مالیاتی", "type": "id_no", "required": True, "group": "مشخصات بدهی"},
            {"key": "debt_amount", "label": "مبلغ کل بدهی (ریال)", "type": "amount", "required": True, "group": "مشخصات بدهی"},
            {"key": "installment_count", "label": "تعداد اقساط درخواستی", "type": "number", "required": True, "group": "درخواست تقسیط"},
            {"key": "installment_amount", "label": "مبلغ هر قسط (ریال)", "type": "amount", "required": True, "group": "درخواست تقسیط"},
            {"key": "payment_method", "label": "شیوه پرداخت", "type": "select", "group": "درخواست تقسیط",
             "options": ["اقساط ماهانه", "اقساط فصلی", "چک صیادی", "سایر"]},
            {"key": "hardship_desc", "label": "شرح ناتوانی موقت و توان پرداخت", "type": "textarea", "required": True, "group": "درخواست تقسیط"},
            {"key": "extra_notes", "label": "توضیحات تکمیلی", "type": "notes", "group": "سایر"},
        ],
        "body": """<p>با سلام و احترام؛</p>
<p>احتراماً، به استحضار می‌رساند اینجانب/شرکت <b>{{taxpayer_name}}</b> به شناسه ملی/کد ملی {{national_id}} دارای پرونده مالیاتی شماره <b>{{file_no}}</b>، بدهی مالیاتی بالغ بر <b>{{debt_amount}} ریال</b> نزد آن اداره محترم دارد.</p>
<p>متأسفانه به دلایل ذیل، پرداخت یکجای بدهی مذکور در حال حاضر ممکن نیست:</p>
<p>{{hardship_desc}}</p>
<p>لذا درخواست تقسیط بدهی مذکور به تعداد <b>{{installment_count}} قسط</b> و به مبلغ هر قسط <b>{{installment_amount}} ریال</b>{{payment_method_line}} را دارم/داریم. تعهد می‌نماییم اقساط در موعد مقرر به‌طور کامل پرداخت گردد.</p>
<p>خواهشمند است دستور فرمایید با درخواست تقسیط موافقت و شرایط آن اعلام گردد.</p>
{{extra_notes_block}}
<p>با سپاس از توجه جنابعالی.</p>""",
    },
    {
        "title": "درخواست بررسی یا استرداد وجه",
        "category": "مالیاتی و حسابداری",
        "description": "درخواست بررسی و استرداد وجه اضافه پرداختی (مالیات، عوارض، کارمزد و ...)",
        "fields": [
            {"key": "receiver", "label": "مرجع مخاطب", "type": "contact", "required": True, "group": "اطلاعات مرجع"},
            {"key": "payer_name", "label": "نام پرداخت‌کننده", "type": "text", "required": True, "group": "مشخصات پرداخت"},
            {"key": "national_id", "label": "شناسه ملی / کد ملی", "type": "id_no", "group": "مشخصات پرداخت"},
            {"key": "payment_type", "label": "نوع وجه پرداختی", "type": "select", "required": True, "group": "مشخصات پرداخت",
             "options": ["مالیات اضافه پرداختی", "عوارض و جرائم قابل استرداد", "وجه اضافه واریزی", "کسور وجه‌الضمان", "سایر"]},
            {"key": "amount", "label": "مبلغ (ریال)", "type": "amount", "required": True, "group": "مشخصات پرداخت"},
            {"key": "payment_date", "label": "تاریخ پرداخت", "type": "jalali_date", "required": True, "group": "مشخصات پرداخت"},
            {"key": "doc_no", "label": "شماره سند / فیش / پرونده", "type": "id_no", "group": "مشخصات پرداخت"},
            {"key": "reason", "label": "شرح درخواست", "type": "textarea", "required": True, "group": "شرح درخواست"},
            {"key": "bank_account", "label": "شماره حساب جهت واریز", "type": "id_no", "group": "شرح درخواست"},
            {"key": "attachments_list", "label": "فهرست پیوست‌ها", "type": "attachments_list", "group": "پیوست‌ها"},
            {"key": "extra_notes", "label": "توضیحات تکمیلی", "type": "notes", "group": "سایر"},
        ],
        "body": """<p>با سلام و احترام؛</p>
<p>احتراماً، به استحضار می‌رساند اینجانب/شرکت <b>{{payer_name}}</b>{{national_id_line}} در تاریخ <b>{{payment_date}}</b> مبلغ <b>{{amount}} ریال</b> بابت <b>{{payment_type}}</b>{{doc_no_line}} پرداخت نموده است.</p>
<p>شرح درخواست: {{reason}}</p>
{{bank_account_block}}
<p>مستندات و رسیدهای مربوطه به پیوست تقدیم می‌گردد. خواهشمند است دستور فرمایید نسبت به بررسی موضوع و در صورت احراز استحقاق، استرداد وجه مذکور به حساب فوق‌الذکر اقدام گردد.</p>
{{attachments_block}}
{{extra_notes_block}}
<p>با سپاس از توجه و تسریع در رسیدگی.</p>""",
    },
    {
        "title": "پاسخ به درخواست اسناد حسابرس",
        "category": "مالیاتی و حسابداری",
        "description": "پاسخ رسمی به استعلام اسناد و اطلاعات از سوی حسابرس یا تیم حسابرسی",
        "fields": [
            {"key": "receiver", "label": "مخاطب (مؤسسه حسابرسی)", "type": "contact", "group": "اطلاعات گیرنده"},
            {"key": "auditor_name", "label": "نام حسابرس / سرپرست تیم", "type": "text", "group": "اطلاعات گیرنده"},
            {"key": "company_name", "label": "نام شرکت", "type": "text", "required": True, "group": "مشخصات شرکت"},
            {"key": "audit_period", "label": "دوره حسابرسی", "type": "text", "required": True, "group": "مشخصات حسابرسی", "help": "مثال: سال مالی ۱۴۰۴"},
            {"key": "letter_no", "label": "شماره نامه استعلام", "type": "id_no", "group": "مشخصات حسابرسی"},
            {"key": "letter_date", "label": "تاریخ نامه استعلام", "type": "jalali_date", "group": "مشخصات حسابرسی"},
            {"key": "response_desc", "label": "پاسخ و توضیحات", "type": "textarea", "required": True, "group": "پاسخ"},
            {"key": "attachments_list", "label": "اسناد پیوسته", "type": "attachments_list", "group": "پیوست‌ها"},
            {"key": "extra_notes", "label": "توضیحات تکمیلی", "type": "notes", "group": "سایر"},
        ],
        "body": """<p>با سلام و احترام؛</p>
<p>در پاسخ به نامه استعلام جناب‌عالی{{letter_ref_line}} مربوط به دوره حسابرسی <b>{{audit_period}}</b> شرکت <b>{{company_name}}</b>، اطلاعات و اسناد درخواستی به شرح ذیل تقدیم می‌گردد:</p>
<p>{{response_desc}}</p>
{{attachments_block}}
<p>در صورت نیاز به اسناد تکمیلی یا توضیحات بیشتر، واحد مالی شرکت آمادگی کامل دارد. از همکاری جناب‌عالی در جریان عملیات حسابرسی سپاسگزاریم.</p>
{{extra_notes_block}}""",
    },
    {
        "title": "درخواست تأیید مانده حساب",
        "category": "مالیاتی و حسابداری",
        "description": "درخواست تأییدیه مانده حساب برای حسابرسی یا مراجع رسمی",
        "fields": [
            {"key": "receiver", "label": "مخاطب (شرکت/بانک)", "type": "contact", "required": True, "group": "اطلاعات گیرنده"},
            {"key": "requester_name", "label": "نام درخواست‌کننده", "type": "text", "required": True, "group": "مشخصات درخواست"},
            {"key": "requester_national", "label": "شناسه ملی / کد ملی", "type": "id_no", "group": "مشخصات درخواست"},
            {"key": "balance_date", "label": "تاریخ مانده", "type": "jalali_date", "required": True, "group": "مشخصات مانده"},
            {"key": "balance_amount", "label": "مبلغ مانده (ریال)", "type": "amount", "group": "مشخصات مانده", "help": "مانده ثبت‌شده نزد شما"},
            {"key": "balance_direction", "label": "بدهکار / بستانکار", "type": "select", "group": "مشخصات مانده",
             "options": ["بدهکار", "بستانکار"]},
            {"key": "confirm_purpose", "label": "مورد استفاده", "type": "text", "required": True, "group": "سایر", "help": "مثال: حسابرسی مالی، رسیدگی مالیاتی"},
            {"key": "extra_notes", "label": "توضیحات تکمیلی", "type": "notes", "group": "سایر"},
        ],
        "body": """<p>با سلام و احترام؛</p>
<p>احتراماً، بازنشانی به استحضار می‌رساند اینجانب/شرکت <b>{{requester_name}}</b>{{requester_national_line}} درخواست صدور تأییدیه مانده حساب نزد مجموعه محترم شما در تاریخ <b>{{balance_date}}</b> را دارم.</p>
<p>بر اساس سوابق مالی اینجانب/شرکت، مانده حساب به مبلغ <b>{{balance_amount}} ریال</b> به صورت {{balance_direction}} می‌باشد. تأییدیه مورد درخواست جهت {{confirm_purpose}} لازم است.</p>
<p>خواهشمند است دستور فرمایید نسبت به صدور تأییدیه مانده حساب، مهر و امضاشده، اقدام گردد. در صورت مغایرت، لطفاً گردش مربوطه اعلام فرمایید تا نسبت به رفع مغایرت اقدام شود.</p>
{{extra_notes_block}}
<p>با سپاس از همکاری شما.</p>""",
    },
    {
        "title": "درخواست اصلاح صورتحساب",
        "category": "مالیاتی و حسابداری",
        "description": "درخواست اصلاح یا ابطال و صدور مجدد صورتحساب معیوب",
        "fields": [
            {"key": "receiver", "label": "مخاطب (صادرکننده صورتحساب)", "type": "contact", "required": True, "group": "اطلاعات گیرنده"},
            {"key": "requester_name", "label": "نام درخواست‌کننده", "type": "text", "required": True, "group": "مشخصات درخواست"},
            {"key": "invoice_no", "label": "شماره صورتحساب", "type": "id_no", "required": True, "group": "مشخصات صورتحساب"},
            {"key": "invoice_date", "label": "تاریخ صورتحساب", "type": "jalali_date", "required": True, "group": "مشخصات صورتحساب"},
            {"key": "invoice_amount", "label": "مبلغ صورتحساب (ریال)", "type": "amount", "group": "مشخصات صورتحساب"},
            {"key": "error_type", "label": "نوع خطا", "type": "select", "required": True, "group": "شرح خطا",
             "options": ["خطای مبلغ", "خطای تعداد", "خطای مشخصات خریدار", "خطای کالا یا خدمت", "تکراری بودن صورتحساب", "سایر"]},
            {"key": "error_desc", "label": "شرح خطا", "type": "textarea", "required": True, "group": "شرح خطا"},
            {"key": "request_line", "label": "درخواست نهایی", "type": "textarea", "required": True, "group": "شرح خطا"},
            {"key": "extra_notes", "label": "توضیحات تکمیلی", "type": "notes", "group": "سایر"},
        ],
        "body": """<p>با سلام و احترام؛</p>
<p>احتراماً، بازنشانی به استحضار می‌رساند در بررسی صورتحساب شماره <b>{{invoice_no}}</b> به تاریخ <b>{{invoice_date}}</b>{{invoice_amount_line}} صادره از مجموعه محترم شما، خطای <b>{{error_type}}</b> مشاهده گردید.</p>
<p>شرح خطا: {{error_desc}}</p>
<p>درخواست نهایی: {{request_line}}</p>
<p>خواهشمند است دستور فرمایید نسبت به اصلاح صورتحساب مذکور و صدور نسخه صحیح اقدام گردد. اسناد و مراسلات مربوطه در صورت نیاز به پیوست ارسال خواهد شد.</p>
{{extra_notes_block}}
<p>با سپاس از توجه شما.</p>""",
    },
]

BLOCK_FIELDS = {
    "economic_code_line": " و کد اقتصادی {{economic_code}}",
    "attachments_block": "<p>پیوست‌ها:<br>{{attachments_list}}</p>",
    "extra_notes_block": "<p>{{extra_notes}}</p>",
    "payment_method_line": " با شیوه پرداخت {{payment_method}}",
    "national_id_line": " به شناسه ملی/کد ملی {{national_id}}",
    "doc_no_line": " با شماره سند/فیش {{doc_no}}",
    "bank_account_block": "<p>شماره حساب جهت واریز وجه: {{bank_account}}</p>",
    "letter_ref_line": " (شماره {{letter_no}} مورخ {{letter_date}})",
    "requester_national_line": " به شناسه ملی/کد ملی {{requester_national}}",
    "invoice_amount_line": " به مبلغ {{invoice_amount}} ریال",
}
