"""الگوهای آماده — دسته بانکی و مالی (۷ الگو)."""

TEMPLATES = [
    {
        "title": "درخواست تسهیلات بانکی",
        "category": "بانکی و مالی",
        "description": "درخواست رسمی دریافت تسهیلات از بانک همراه با مشخصات متقاضی و هدف تسهیلات",
        "fields": [
            {"key": "receiver", "label": "بانک مخاطب", "type": "contact", "group": "اطلاعات بانک", "help": "از فهرست مخاطبین انتخاب کنید یا نام بانک را دستی وارد کنید"},
            {"key": "branch_name", "label": "نام شعبه", "type": "text", "required": True, "group": "اطلاعات بانک"},
            {"key": "company_name", "label": "نام شرکت متقاضی", "type": "text", "required": True, "group": "مشخصات متقاضی"},
            {"key": "national_id", "label": "شناسه ملی شرکت", "type": "id_no", "group": "مشخصات متقاضی"},
            {"key": "registration_no", "label": "شماره ثبت", "type": "id_no", "group": "مشخصات متقاضی"},
            {"key": "loan_type", "label": "نوع تسهیلات", "type": "select", "required": True, "group": "مشخصات تسهیلات",
             "options": ["مشارکت مدنی", "عاملیت", "مزایده", "قرض‌الحسنه", "جعاله", "سلف", "خرید دین", "فاینانس", "سایر"]},
            {"key": "amount", "label": "مبلغ تسهیلات (ریال)", "type": "amount", "required": True, "group": "مشخصات تسهیلات"},
            {"key": "purpose", "label": "هدف دریافت تسهیلات", "type": "textarea", "required": True, "group": "مشخصات تسهیلات"},
            {"key": "account_no", "label": "شماره حساب", "type": "id_no", "group": "مشخصات تسهیلات"},
            {"key": "repayment", "label": "پیشنهاد بازپرداخت", "type": "text", "group": "مشخصات تسهیلات", "help": "مثال: ۳۶ قسط ماهانه"},
            {"key": "extra_notes", "label": "توضیحات تکمیلی", "type": "notes", "group": "سایر"},
        ],
        "body": """<p>با سلام و احترام؛</p>
<p>احتراماً، به استحضار می‌رساند شرکت <b>{{company_name}}</b>{{national_id_line}} به موجب این نامه درخواست دریافت تسهیلات از نوع <b>{{loan_type}}</b> به مبلغ <b>{{amount}} ریال</b> از بانک محترم {{receiver}} شعبه {{branch_name}} را دارد.</p>
<p>هدف از دریافت تسهیلات مذکور عبارت است از: {{purpose}}</p>
{{account_no_block}}
{{repayment_block}}
<p>در صورت تصویب، آمادگی داریم کلیه مدارک و مستندات موردنیاز بانک را ارائه و مفاد قرارداد مربوطه را پذیرا باشیم.</p>
{{extra_notes_block}}
<p>پیشاپیش از عنایت و حسن توجه جنابعالی کمال تشکر و قدردانی را داریم.</p>""",
    },
    {
        "title": "درخواست دسته‌چک",
        "category": "بانکی و مالی",
        "description": "درخواست صدور یا تعویض دسته‌چک برای حساب جاری",
        "fields": [
            {"key": "receiver", "label": "بانک مخاطب", "type": "contact", "required": True, "group": "اطلاعات بانک"},
            {"key": "branch_name", "label": "نام شعبه", "type": "text", "required": True, "group": "اطلاعات بانک"},
            {"key": "account_no", "label": "شماره حساب جاری", "type": "id_no", "required": True, "group": "مشخصات حساب"},
            {"key": "account_holder", "label": "نام صاحب حساب", "type": "text", "required": True, "group": "مشخصات حساب"},
            {"key": "national_id", "label": "شناسه ملی / کد ملی", "type": "id_no", "group": "مشخصات حساب"},
            {"key": "booklet_count", "label": "تعداد برگ درخواستی", "type": "number", "default": "۱۰", "group": "مشخصات درخواست"},
            {"key": "reason", "label": "علت درخواست", "type": "select", "group": "مشخصات درخواست",
             "options": ["اتمام برگه‌های دسته‌چک فعلی", "تعویض دسته‌چک قدیمی", "افتتاح حساب جدید", "افزایش تعداد برگه‌ها", "سایر"]},
            {"key": "extra_notes", "label": "توضیحات تکمیلی", "type": "notes", "group": "سایر"},
        ],
        "body": """<p>با سلام و احترام؛</p>
<p>احتراماً، بازنشانی به استحضار می‌رساند اینجانب/شرکت <b>{{account_holder}}</b> دارنده حساب جاری شماره <b>{{account_no}}</b> نزد بانک محترم {{receiver}} شعبه {{branch_name}}، درخواست صدور دسته‌چک به تعداد {{booklet_count}} برگ را دارد.</p>
<p>علت درخواست: {{reason}}</p>
<p>خواهشمند است دستور فرمایید نسبت به صدور دسته‌چک مورد درخواست در اسرع وقت اقدام گردد. لازم به ذکر است کلیه تعهدات مربوط به حساب و دسته‌چک مذکور بر عهده اینجانب/شرکت خواهد بود.</p>
{{extra_notes_block}}
<p>با سپاس از توجه شما.</p>""",
    },
    {
        "title": "درخواست افتتاح حساب",
        "category": "بانکی و مالی",
        "description": "درخواست افتتاح حساب جدید برای شخص حقیقی یا حقوقی",
        "fields": [
            {"key": "receiver", "label": "بانک مخاطب", "type": "contact", "required": True, "group": "اطلاعات بانک"},
            {"key": "branch_name", "label": "نام شعبه", "type": "text", "required": True, "group": "اطلاعات بانک"},
            {"key": "account_type", "label": "نوع حساب", "type": "select", "required": True, "group": "مشخصات حساب",
             "options": ["جاری", "قرض‌الحسنه پس‌انداز", "سپرده کوتاه‌مدت", "سپرده بلندمدت", "سپرده ویژه"]},
            {"key": "applicant_name", "label": "نام متقاضی (شخص/شرکت)", "type": "text", "required": True, "group": "مشخصات متقاضی"},
            {"key": "national_id", "label": "شناسه ملی / کد ملی", "type": "id_no", "group": "مشخصات متقاضی"},
            {"key": "initial_deposit", "label": "مبلغ واریز اولیه (ریال)", "type": "amount", "group": "مشخصات حساب"},
            {"key": "purpose", "label": "هدف افتتاح حساب", "type": "textarea", "group": "مشخصات حساب"},
            {"key": "extra_notes", "label": "توضیحات تکمیلی", "type": "notes", "group": "سایر"},
        ],
        "body": """<p>با سلام و احترام؛</p>
<p>احتراماً، به استحضار می‌رساند اینجانب/شرکت <b>{{applicant_name}}</b>{{national_id_line}} قصد دارد نزد بانک محترم {{receiver}} شعبه {{branch_name}} یک فقره حساب از نوع <b>{{account_type}}</b> افتتاح نماید.</p>
{{initial_deposit_block}}
{{purpose_block}}
<p>مدارک شناسایی و مستندات موردنیاز به پیوست تقدیم می‌گردد. خواهشمند است دستور فرمایید نسبت به تشکیل پرونده و افتتاح حساب اقدام لازم صورت پذیرد.</p>
{{extra_notes_block}}
<p>پیشاپیش از همکاری جنابعالی سپاسگزاریم.</p>""",
    },
    {
        "title": "معرفی صاحبان امضای مجاز",
        "category": "بانکی و مالی",
        "description": "معرفی رسمی افراد دارای حق امضا نزد بانک همراه با محدوده اختیارات",
        "fields": [
            {"key": "receiver", "label": "بانک مخاطب", "type": "contact", "required": True, "group": "اطلاعات بانک"},
            {"key": "branch_name", "label": "نام شعبه", "type": "text", "required": True, "group": "اطلاعات بانک"},
            {"key": "company_name", "label": "نام شرکت", "type": "text", "required": True, "group": "مشخصات شرکت"},
            {"key": "national_id", "label": "شناسه ملی", "type": "id_no", "group": "مشخصات شرکت"},
            {"key": "account_no", "label": "شماره حساب جاری", "type": "id_no", "group": "مشخصات حساب"},
            {"key": "signer1_name", "label": "نام امضاکننده اول", "type": "text", "required": True, "group": "امضاکنندگان"},
            {"key": "signer1_position", "label": "سمت امضاکننده اول", "type": "text", "required": True, "group": "امضاکنندگان"},
            {"key": "signer1_national", "label": "کد ملی امضاکننده اول", "type": "id_no", "group": "امضاکنندگان"},
            {"key": "signer1_scope", "label": "حدود اختیارات امضاکننده اول", "type": "select", "group": "امضاکنندگان",
             "options": ["امضای منفرد", "امضای مشترک (دو امضا)", "بدون سقف مبلغ", "تا سقف مبلغ تعیین‌شده"]},
            {"key": "signer1_limit", "label": "سقف مبلغ (ریال)", "type": "amount", "group": "امضاکنندگان", "help": "در صورت وجود سقف"},
            {"key": "signer2_name", "label": "نام امضاکننده دوم", "type": "text", "group": "امضاکنندگان"},
            {"key": "signer2_position", "label": "سمت امضاکننده دوم", "type": "text", "group": "امضاکنندگان"},
            {"key": "signer2_national", "label": "کد ملی امضاکننده دوم", "type": "id_no", "group": "امضاکنندگان"},
            {"key": "extra_notes", "label": "توضیحات تکمیلی", "type": "notes", "group": "سایر"},
        ],
        "body": """<p>با سلام و احترام؛</p>
<p>احتراماً، به استحضار می‌رساند شرکت <b>{{company_name}}</b>{{national_id_line}} دارنده حساب جاری شماره {{account_no}} نزد بانک محترم {{receiver}} شعبه {{branch_name}}، اشخاص زیر را به‌عنوان صاحبان امضای مجاز خود معرفی می‌نماید:</p>
<p>۱- آقای/خانم <b>{{signer1_name}}</b> به سمت {{signer1_position}} (کد ملی: {{signer1_national}}) — حدود اختیارات: {{signer1_scope}}{{signer1_limit_line}}</p>
{{signer2_block}}
<p>امضای اشخاص فوق در ستون ویژه امضا در ذیل این نامه درج گردیده و مبنای اقدام بانک محترم خواهد بود.</p>
<p>لازم به ذکر است در صورت هرگونه تغییر در صاحبان امضا، مراتب حداکثر ظرف مدت قانونی به‌طور رسمی به بانک اعلام خواهد شد.</p>
{{extra_notes_block}}
<p>با تشکر از همکاری جنابعالی.</p>""",
    },
    {
        "title": "درخواست صدور ضمانت‌نامه",
        "category": "بانکی و مالی",
        "description": "درخواست صدور ضمانت‌نامه بانکی (شرکت در مناقصه/مزایده، حسن انجام کار و ...)",
        "fields": [
            {"key": "receiver", "label": "بانک مخاطب", "type": "contact", "required": True, "group": "اطلاعات بانک"},
            {"key": "branch_name", "label": "نام شعبه", "type": "text", "required": True, "group": "اطلاعات بانک"},
            {"key": "company_name", "label": "نام شرکت متقاضی", "type": "text", "required": True, "group": "مشخصات متقاضی"},
            {"key": "guarantee_type", "label": "نوع ضمانت‌نامه", "type": "select", "required": True, "group": "مشخصات ضمانت‌نامه",
             "options": ["شرکت در مناقصه", "شرکت در مزایده", "پیش‌پرداخت", "حسن انجام تعهدات", "استرداد کسور وجه‌الضمان", "گمرکی", "سایر"]},
            {"key": "beneficiary", "label": "نام ذی‌نفع", "type": "text", "required": True, "group": "مشخصات ضمانت‌نامه", "help": "اداره، شرکت یا سازمانی که ضمانت‌نامه به نفع او صادر می‌شود"},
            {"key": "amount", "label": "مبلغ ضمانت‌نامه (ریال)", "type": "amount", "required": True, "group": "مشخصات ضمانت‌نامه"},
            {"key": "duration", "label": "مدت اعتبار", "type": "text", "required": True, "group": "مشخصات ضمانت‌نامه", "help": "مثال: ۶ ماه"},
            {"key": "tender_no", "label": "شماره مناقصه/مزایده یا قرارداد", "type": "id_no", "group": "مشخصات ضمانت‌نامه"},
            {"key": "collateral", "label": "وثیقه پیشنهادی", "type": "text", "group": "مشخصات ضمانت‌نامه"},
            {"key": "extra_notes", "label": "توضیحات تکمیلی", "type": "notes", "group": "سایر"},
        ],
        "body": """<p>با سلام و احترام؛</p>
<p>احتراماً، به استحضار می‌رساند شرکت <b>{{company_name}}</b> درخواست صدور یک فقره ضمانت‌نامه بانکی از نوع <b>{{guarantee_type}}</b> به مبلغ <b>{{amount}} ریال</b> به نفع <b>{{beneficiary}}</b> را دارد.</p>
<p>مدت اعتبار ضمانت‌نامه مورد درخواست {{duration}} بوده{{tender_no_line}} و به پیوست مدارک و مستندات مربوطه تقدیم می‌گردد.</p>
{{collateral_block}}
<p>خواهشمند است در صورت احراز صلاحیت، دستور فرمایید نسبت به صدور ضمانت‌نامه مورد درخواست اقدام لازم به عمل آید. تعهدات مربوط به این ضمانت‌نامه و کارمزد آن پذیرفته می‌شود.</p>
{{extra_notes_block}}
<p>پیشاپیش از حسن توجه شما سپاسگزاریم.</p>""",
    },
    {
        "title": "درخواست گردش حساب",
        "category": "بانکی و مالی",
        "description": "درخواست ارائه صورتحساب و گردش حساب برای بازه زمانی مشخص",
        "fields": [
            {"key": "receiver", "label": "بانک مخاطب", "type": "contact", "required": True, "group": "اطلاعات بانک"},
            {"key": "branch_name", "label": "نام شعبه", "type": "text", "required": True, "group": "اطلاعات بانک"},
            {"key": "account_no", "label": "شماره حساب", "type": "id_no", "required": True, "group": "مشخصات حساب"},
            {"key": "account_holder", "label": "نام صاحب حساب", "type": "text", "required": True, "group": "مشخصات حساب"},
            {"key": "from_date", "label": "از تاریخ", "type": "jalali_date", "required": True, "group": "بازه زمانی"},
            {"key": "to_date", "label": "تا تاریخ", "type": "jalali_date", "required": True, "group": "بازه زمانی"},
            {"key": "usage_reason", "label": "مورد استفاده", "type": "text", "group": "سایر", "help": "مثال: حسابرسی سالانه، تسویه با طرف حساب و ..."},
            {"key": "extra_notes", "label": "توضیحات تکمیلی", "type": "notes", "group": "سایر"},
        ],
        "body": """<p>با سلام و احترام؛</p>
<p>احتراماً، بازنشانی به استحضار می‌رساند اینجانب/شرکت <b>{{account_holder}}</b> دارنده حساب شماره <b>{{account_no}}</b> نزد بانک محترم {{receiver}} شعبه {{branch_name}}، درخواست دریافت گردش و صورتحساب مربوط به بازه زمانی <b>{{from_date}}</b> لغایت <b>{{to_date}}</b> را دارد.</p>
{{usage_reason_block}}
<p>خواهشمند است دستور فرمایید نسبت به تهیه و ارائه صورتحساب مذکور، مهر و امضاشده، اقدام فرمایید.</p>
{{extra_notes_block}}
<p>با سپاس از توجه و همکاری شما.</p>""",
    },
    {
        "title": "پیگیری مغایرت بانکی",
        "category": "بانکی و مالی",
        "description": "اعلام و پیگیری مغایرت بین صورتحساب بانک و اسناد حسابداری داخلی",
        "fields": [
            {"key": "receiver", "label": "بانک مخاطب", "type": "contact", "required": True, "group": "اطلاعات بانک"},
            {"key": "branch_name", "label": "نام شعبه", "type": "text", "required": True, "group": "اطلاعات بانک"},
            {"key": "account_no", "label": "شماره حساب", "type": "id_no", "required": True, "group": "مشخصات حساب"},
            {"key": "account_holder", "label": "نام صاحب حساب", "type": "text", "required": True, "group": "مشخصات حساب"},
            {"key": "mismatch_date", "label": "تاریخ تراکنش مورد مغایرت", "type": "jalali_date", "required": True, "group": "مشخصات مغایرت"},
            {"key": "mismatch_amount", "label": "مبلغ مغایرت (ریال)", "type": "amount", "required": True, "group": "مشخصات مغایرت"},
            {"key": "mismatch_type", "label": "نوع مغایرت", "type": "select", "required": True, "group": "مشخصات مغایرت",
             "options": ["برداشت غیرمعلوم", "واریز ثبت‌نشده", "دو بار برداشت", "کارمزد غیرمنطبق", "عدم وصول چک وارده", "سایر"]},
            {"key": "doc_no", "label": "شماره سند / شماره فیش", "type": "id_no", "group": "مشخصات مغایرت"},
            {"key": "description", "label": "شرح مغایرت", "type": "textarea", "required": True, "group": "مشخصات مغایرت"},
            {"key": "extra_notes", "label": "توضیحات تکمیلی", "type": "notes", "group": "سایر"},
        ],
        "body": """<p>با سلام و احترام؛</p>
<p>احتراماً، در جریان تطبیق صورتحساب دریافت‌شده از بانک محترم {{receiver}} شعبه {{branch_name}} با اسناد حسابداری این واحد، مغایرتی در حساب شماره <b>{{account_no}}</b> به نام <b>{{account_holder}}</b> مشاهده گردید که بدین‌وسیله به استحضار می‌رسد:</p>
<p>تاریخ تراکنش: <b>{{mismatch_date}}</b> — مبلغ: <b>{{mismatch_amount}} ریال</b> — نوع مغایرت: <b>{{mismatch_type}}</b>{{doc_no_line}}</p>
<p>شرح مغایرت: {{description}}</p>
<p>خواهشمند است دستور فرمایید مورد را بررسی و نتیجه در اسرع وقت جهت رفع مغایرت به این واحد اعلام گردد. در صورت نیاز به ارائه اسناد تکمیلی، در خدمت خواهیم بود.</p>
{{extra_notes_block}}
<p>با سپاس از توجه و تسریع در بررسی.</p>""",
    },
]

# بلوک‌های شرطی که در حین رندر پاک یا پر می‌شوند (فیلدهای اختیاری)
BLOCK_FIELDS = {
    "national_id_line": " (شناسه ملی {{national_id}})",
    "account_no_block": "<p>شماره حساب مربوطه: {{account_no}}</p>",
    "repayment_block": "<p>پیشنهاد این واحد برای بازپرداخت تسهیلات، {{repayment}} می‌باشد.</p>",
    "extra_notes_block": "<p>{{extra_notes}}</p>",
    "initial_deposit_block": "<p>مبلغ واریز اولیه در نظر گرفته‌شده {{initial_deposit}} ریال می‌باشد.</p>",
    "purpose_block": "<p>هدف از افتتاح حساب: {{purpose}}</p>",
    "usage_reason_block": "<p>صورتحساب مذکور جهت {{usage_reason}} مورد نیاز است.</p>",
    "tender_no_line": " و مربوط به شماره {{tender_no}} است",
    "collateral_block": "<p>وثیقه پیشنهادی جهت تضمین: {{collateral}}</p>",
    "doc_no_line": " — شماره سند/فیش: {{doc_no}}",
    "signer1_limit_line": " (تا سقف {{signer1_limit}} ریال)",
    "signer2_block": "<p>۲- آقای/خانم <b>{{signer2_name}}</b> به سمت {{signer2_position}} (کد ملی: {{signer2_national}})</p>",
}
