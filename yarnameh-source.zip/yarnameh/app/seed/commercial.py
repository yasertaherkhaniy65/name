"""الگوهای آماده — دسته اداری و تجاری (۱۰ الگو)."""

TEMPLATES = [
    {
        "title": "درخواست استعلام قیمت",
        "category": "اداری و تجاری",
        "description": "درخواست قیمت و شرایط فروش کالا یا خدمات از تأمین‌کننده",
        "fields": [
            {"key": "receiver", "label": "شرکت / فروشنده مخاطب", "type": "contact", "required": True, "group": "اطلاعات گیرنده"},
            {"key": "company_name", "label": "نام شرکت درخواست‌کننده", "type": "text", "required": True, "group": "مشخصات درخواست"},
            {"key": "items_list", "label": "شرح کالا / خدمات", "type": "textarea", "required": True, "group": "مشخصات درخواست", "help": "هر سطر یک قلم همراه با تعداد و مشخصات"},
            {"key": "qty_note", "label": "مقدار / تعداد تقریبی", "type": "text", "group": "مشخصات درخواست"},
            {"key": "deadline_date", "label": "مهلت اعلام قیمت", "type": "jalali_date", "group": "شرایط"},
            {"key": "delivery_terms", "label": "شرایط تحویل", "type": "text", "group": "شرایط", "help": "مثال: تحویل در محل شرکت"},
            {"key": "payment_terms", "label": "شرایط پرداخت پیشنهادی", "type": "text", "group": "شرایط"},
            {"key": "extra_notes", "label": "توضیحات تکمیلی", "type": "notes", "group": "سایر"},
        ],
        "body": """<p>با سلام و احترام؛</p>
<p>احتراماً، شرکت <b>{{company_name}}</b> در نظر دارد موارد ذیل را از مجموعه محترم شما تهیه نماید. خواهشمند است قیمت و شرایط فروش را اعلام فرمایید:</p>
<p>{{items_list}}</p>
{{qty_block}}
{{deadline_block}}
{{terms_block}}
<p>مستدعی است پیشنهاد قیمت به‌صورت مکتوب و همراه با شرایط پرداخت و مدت اعتبار پیشنهاد به این شرکت ارسال گردد تا نسبت به بررسی و تصمیم‌گیری اقدام شود.</p>
{{extra_notes_block}}
<p>با سپاس از توجه و همکاری شما.</p>""",
    },
    {
        "title": "ارسال پیشنهاد قیمت",
        "category": "اداری و تجاری",
        "description": "ارسال پیشنهاد قیمت رسمی به مشتری همراه با شرایط فروش",
        "fields": [
            {"key": "receiver", "label": "مشتری مخاطب", "type": "contact", "required": True, "group": "اطلاعات گیرنده"},
            {"key": "company_name", "label": "نام شرکت پیشنهاددهنده", "type": "text", "required": True, "group": "مشخصات پیشنهاد"},
            {"key": "inquiry_ref", "label": "در پاسخ به (شماره نامه استعلام)", "type": "id_no", "group": "مشخصات پیشنهاد"},
            {"key": "items_list", "label": "شرح کالا / خدمات و قیمت", "type": "textarea", "required": True, "group": "مشخصات پیشنهاد", "help": "هر سطر: شرح، تعداد، قیمت واحد، جمع"},
            {"key": "total_amount", "label": "جمع کل پیشنهاد (ریال)", "type": "amount", "group": "مشخصات پیشنهاد"},
            {"key": "offer_validity", "label": "مدت اعتبار پیشنهاد", "type": "text", "default": "۳۰ روز", "group": "شرایط"},
            {"key": "delivery_terms", "label": "مدت و شرایط تحویل", "type": "text", "group": "شرایط"},
            {"key": "payment_terms", "label": "شرایط پرداخت", "type": "text", "group": "شرایط"},
            {"key": "extra_notes", "label": "توضیحات تکمیلی", "type": "notes", "group": "سایر"},
        ],
        "body": """<p>با سلام و احترام؛</p>
<p>در پاسخ به درخواست جنابعالی{{inquiry_ref_line}}، پیشنهاد قیمت شرکت <b>{{company_name}}</b> برای موارد درخواستی به شرح ذیل تقدیم می‌گردد:</p>
<p>{{items_list}}</p>
{{total_block}}
<p>شرایط پیشنهاد: مدت اعتبار پیشنهاد {{offer_validity}} است{{delivery_line}}.</p>
<p>شرایط پرداخت: {{payment_terms}}</p>
<p>در صورت تمایل به همکاری، مراتب جهت نهایی‌سازی قرارداد و زمان‌بندی اجرا اعلام گردد. از اعتماد جنابعالی سپاسگزاریم.</p>
{{extra_notes_block}}""",
    },
    {
        "title": "درخواست تمدید قرارداد",
        "category": "اداری و تجاری",
        "description": "درخواست تمدید قرارداد جاری با ذکر شماره و رضایت از همکاری",
        "fields": [
            {"key": "receiver", "label": "مخاطب (طرف قرارداد)", "type": "contact", "required": True, "group": "اطلاعات گیرنده"},
            {"key": "company_name", "label": "نام شرکت درخواست‌کننده", "type": "text", "required": True, "group": "مشخصات درخواست"},
            {"key": "contract_no", "label": "شماره قرارداد", "type": "id_no", "required": True, "group": "مشخصات قرارداد"},
            {"key": "contract_subject", "label": "موضوع قرارداد", "type": "text", "required": True, "group": "مشخصات قرارداد"},
            {"key": "contract_end", "label": "تاریخ پایان قرارداد", "type": "jalali_date", "required": True, "group": "مشخصات قرارداد"},
            {"key": "extend_duration", "label": "مدت تمدید پیشنهادی", "type": "text", "required": True, "group": "درخواست", "help": "مثال: یک سال"},
            {"key": "extend_from", "label": "تمدید از تاریخ", "type": "jalali_date", "group": "درخواست"},
            {"key": "coop_desc", "label": "دلایل تمدید", "type": "textarea", "group": "درخواست"},
            {"key": "extra_notes", "label": "توضیحات تکمیلی", "type": "notes", "group": "سایر"},
        ],
        "body": """<p>با سلام و احترام؛</p>
<p>احتراماً، به استحضار می‌رساند قرارداد شماره <b>{{contract_no}}</b> موضوع <b>{{contract_subject}}</b> بین مجموعه محترم شما و شرکت {{company_name}} در تاریخ {{contract_end}} منقضی می‌گردد.</p>
<p>با توجه به رضایت کامل از کیفیت همکاری{{coop_desc_line}}، درخواست تمدید قرارداد مذکور به مدت <b>{{extend_duration}}</b>{{extend_from_line}} را داریم.</p>
<p>در صورت موافقت، آمادگی داریم مفاد الحاقیه تمدید را بررسی و امضا نماییم.</p>
{{extra_notes_block}}
<p>پیشاپیش از ادامه همکاری متقابل سپاسگزاریم.</p>""",
    },
    {
        "title": "درخواست همکاری",
        "category": "اداری و تجاری",
        "description": "پیشنهاد اولیه برقراری همکاری تجاری یا خدماتی",
        "fields": [
            {"key": "receiver", "label": "مخاطب", "type": "contact", "required": True, "group": "اطلاعات گیرنده"},
            {"key": "company_name", "label": "نام شرکت پیشنهاددهنده", "type": "text", "required": True, "group": "معرفی"},
            {"key": "activity_desc", "label": "زمینه فعالیت", "type": "textarea", "required": True, "group": "معرفی"},
            {"key": "coop_type", "label": "نوع همکاری پیشنهادی", "type": "select", "required": True, "group": "پیشنهاد همکاری",
             "options": ["تأمین کالا", "ارائه خدمات", "نمایندگی و پخش", "پیمانکاری", "سرمایه‌گذاری مشترک", "سایر"]},
            {"key": "coop_desc", "label": "شرح پیشنهاد", "type": "textarea", "required": True, "group": "پیشنهاد همکاری"},
            {"key": "advantages", "label": "مزایای همکاری", "type": "textarea", "group": "پیشنهاد همکاری"},
            {"key": "meeting_proposal", "label": "پیشنهاد جلسه", "type": "bool", "group": "سایر"},
            {"key": "extra_notes", "label": "توضیحات تکمیلی", "type": "notes", "group": "سایر"},
        ],
        "body": """<p>با سلام و احترام؛</p>
<p>احتراماً، شرکت <b>{{company_name}}</b> در زمینه زیر فعالیت می‌نماید:</p>
<p>{{activity_desc}}</p>
<p>با عنایت به سوابق و توانمندی‌های این مجموعه، پیشنهاد برقراری همکاری به شکل <b>{{coop_type}}</b> را داریم. شرح پیشنهاد به شرح ذیل است:</p>
<p>{{coop_desc}}</p>
{{advantages_block}}
{{meeting_block}}
<p>در صورت علاقه‌مندی، اطلاعات تکمیلی و جلسه حضوری برای تبادل نظر در اختیار جنابعالی قرار خواهد گرفت.</p>
{{extra_notes_block}}
<p>با احترام و امید به همکاری مطلوب.</p>""",
    },
    {
        "title": "دعوت به جلسه",
        "category": "اداری و تجاری",
        "description": "دعوت رسمی به جلسه کاری با ذکر دستور جلسه",
        "fields": [
            {"key": "receiver", "label": "مخاطب", "type": "contact", "required": True, "group": "اطلاعات گیرنده"},
            {"key": "company_name", "label": "نام شرکت دعوت‌کننده", "type": "text", "required": True, "group": "مشخصات جلسه"},
            {"key": "meeting_subject", "label": "موضوع جلسه", "type": "text", "required": True, "group": "مشخصات جلسه"},
            {"key": "meeting_date", "label": "تاریخ جلسه", "type": "jalali_date", "required": True, "group": "مشخصات جلسه"},
            {"key": "meeting_time", "label": "ساعت جلسه", "type": "text", "required": True, "group": "مشخصات جلسه"},
            {"key": "meeting_place", "label": "محل برگزاری", "type": "text", "required": True, "group": "مشخصات جلسه"},
            {"key": "agenda", "label": "دستور جلسه", "type": "textarea", "group": "دستور جلسه", "help": "هر سطر یک بند"},
            {"key": "attendees_note", "label": "حضورکنندگان پیشنهادی", "type": "text", "group": "سایر"},
            {"key": "extra_notes", "label": "توضیحات تکمیلی", "type": "notes", "group": "سایر"},
        ],
        "body": """<p>با سلام و احترام؛</p>
<p>احتراماً، مجموعه <b>{{company_name}}</b> جهت بررسی موضوع <b>{{meeting_subject}}</b>، جنابعالی را به جلسه‌ای که به شرح ذیل برگزار می‌گردد دعوت می‌نماید:</p>
<p>تاریخ: <b>{{meeting_date}}</b> — ساعت: <b>{{meeting_time}}</b> — محل: <b>{{meeting_place}}</b></p>
{{agenda_block}}
{{attendees_block}}
<p>خواهشمند است در صورت امکان حضور، مراتب را اعلام فرمایید. در صورت عدم امکان حضور در زمان مذکور، پیشنهاد زمان جایگزین را بفرمایید.</p>
{{extra_notes_block}}
<p>با سپاس از توجه شما.</p>""",
    },
    {
        "title": "پاسخ به نامه وارده",
        "category": "اداری و تجاری",
        "description": "پاسخ رسمی به نامه دریافتی با اشاره به شماره و تاریخ نامه مبنا",
        "fields": [
            {"key": "receiver", "label": "فرستنده نامه وارده", "type": "contact", "required": True, "group": "اطلاعات گیرنده"},
            {"key": "company_name", "label": "نام شرکت پاسخ‌دهنده", "type": "text", "required": True, "group": "مشخصات"},
            {"key": "incoming_no", "label": "شماره نامه وارده", "type": "id_no", "required": True, "group": "مشخصات نامه مبنا"},
            {"key": "incoming_date", "label": "تاریخ نامه وارده", "type": "jalali_date", "required": True, "group": "مشخصات نامه مبنا"},
            {"key": "incoming_subject", "label": "موضوع نامه وارده", "type": "text", "required": True, "group": "مشخصات نامه مبنا"},
            {"key": "response_desc", "label": "پاسخ", "type": "textarea", "required": True, "group": "پاسخ"},
            {"key": "attachments_list", "label": "پیوست‌ها", "type": "attachments_list", "group": "پیوست‌ها"},
            {"key": "extra_notes", "label": "توضیحات تکمیلی", "type": "notes", "group": "سایر"},
        ],
        "body": """<p>با سلام و احترام؛</p>
<p>در پاسخ به نامه شماره <b>{{incoming_no}}</b> مورخ <b>{{incoming_date}}</b> راجع به <b>{{incoming_subject}}</b>، به استحضار می‌رساند:</p>
<p>{{response_desc}}</p>
{{attachments_block}}
<p>در صورت نیاز به توضیحات بیشتر یا جلسه حضوری، آمادگی کامل وجود دارد.</p>
{{extra_notes_block}}
<p>با احترام.</p>""",
    },
    {
        "title": "درخواست تسویه بدهی",
        "category": "اداری و تجاری",
        "description": "مطالبه بدهی معوقه با ذکر اسناد و مهلت پرداخت",
        "fields": [
            {"key": "receiver", "label": "بدهکار مخاطب", "type": "contact", "required": True, "group": "اطلاعات گیرنده"},
            {"key": "company_name", "label": "نام شرکت طلبکار", "type": "text", "required": True, "group": "مشخصات بدهی"},
            {"key": "invoice_no", "label": "شماره فاکتور / قرارداد", "type": "id_no", "required": True, "group": "مشخصات بدهی"},
            {"key": "invoice_date", "label": "تاریخ سند", "type": "jalali_date", "required": True, "group": "مشخصات بدهی"},
            {"key": "due_amount", "label": "مبلغ بدهی (ریال)", "type": "amount", "required": True, "group": "مشخصات بدهی"},
            {"key": "due_date", "label": "سررسید پرداخت", "type": "jalali_date", "group": "مشخصات بدهی"},
            {"key": "overdue_days", "label": "روزهای تأخیر", "type": "number", "group": "مشخصات بدهی"},
            {"key": "pay_deadline", "label": "مهلت پرداخت پیشنهادی", "type": "jalali_date", "required": True, "group": "درخواست"},
            {"key": "installment_offer", "label": "پیشنهاد تقسیط (در صورت تمایل)", "type": "text", "group": "درخواست"},
            {"key": "extra_notes", "label": "توضیحات تکمیلی", "type": "notes", "group": "سایر"},
        ],
        "body": """<p>با سلام و احترام؛</p>
<p>احتراماً، بازنشانی به استحضار می‌رساند بابت فاکتور/قرارداد شماره <b>{{invoice_no}}</b> مورخ <b>{{invoice_date}}</b>، مبلغ <b>{{due_amount}} ریال</b> بابت کالاها/خدمات ارائه‌شده به مجموعه محترم شما، تاکنون تسویه نگردیده است.</p>
{{overdue_block}}
<p>خواهشمند است نسبت به تسویه بدهی مذکور حداکثر تا تاریخ <b>{{pay_deadline}}</b> اقدام فرمایید{{installment_line}}.</p>
<p>در صورت انجام پرداخت، رسید و گواهی تسویه در اسرع وقت برای شما ارسال خواهد شد.</p>
{{extra_notes_block}}
<p>با سپاس از توجه و اقدام به‌موقع شما.</p>""",
    },
    {
        "title": "معرفی‌نامه",
        "category": "اداری و تجاری",
        "description": "معرفی‌نامه رسمی برای شخص یا کارمند جهت مراجعه و پیگیری امور",
        "fields": [
            {"key": "receiver", "label": "مرجع گیرنده", "type": "contact", "group": "اطلاعات گیرنده"},
            {"key": "company_name", "label": "نام شرکت معرفی‌کننده", "type": "text", "required": True, "group": "مشخصات معرفی‌نامه"},
            {"key": "person_name", "label": "نام شخص معرفی‌شده", "type": "text", "required": True, "group": "مشخصات شخص"},
            {"key": "national_id", "label": "کد ملی", "type": "id_no", "group": "مشخصات شخص"},
            {"key": "person_role", "label": "سوابق / سمت", "type": "text", "group": "مشخصات شخص"},
            {"key": "intro_purpose", "label": "هدف معرفی", "type": "text", "required": True, "group": "مشخصات معرفی‌نامه", "help": "مثال: انجام امور بانکی، تحویل اسناد، حضور در جلسه"},
            {"key": "validity", "label": "مدت اعتبار", "type": "text", "default": "یک‌بار استفاده", "group": "مشخصات معرفی‌نامه"},
            {"key": "extra_notes", "label": "توضیحات تکمیلی", "type": "notes", "group": "سایر"},
        ],
        "body": """<p>به نام خدا</p>
<p>با سلام و احترام؛</p>
<p>بازنشانی تأیید می‌نماید آقای/خانم <b>{{person_name}}</b>{{national_id_line}}{{role_line}} از طرف شرکت <b>{{company_name}}</b> جهت {{intro_purpose}} معرفی می‌گردد.</p>
<p>معرفی‌نامه حاضر صرفاً برای هدف فوق صادر شده و مدت اعتبار آن {{validity}} است. خواهشمند است همکاری لازم مبذول فرمایید.</p>
{{extra_notes_block}}
<p>برای هرگونه استعلام اصالت این معرفی‌نامه می‌توانید با واحد مربوطه شرکت تماس حاصل فرمایید.</p>""",
    },
    {
        "title": "ارسال مدارک",
        "category": "اداری و تجاری",
        "description": "نامه ارسال مدارک و اسناد با فهرست کامل پیوست‌ها",
        "fields": [
            {"key": "receiver", "label": "مخاطب", "type": "contact", "required": True, "group": "اطلاعات گیرنده"},
            {"key": "company_name", "label": "نام شرکت ارسال‌کننده", "type": "text", "required": True, "group": "مشخصات ارسال"},
            {"key": "sending_reason", "label": "علت ارسال", "type": "text", "required": True, "group": "مشخصات ارسال", "help": "مثال: طبق درخواست جنابعالی، تکمیل پرونده و ..."},
            {"key": "attachments_list", "label": "فهرست مدارک", "type": "attachments_list", "required": True, "group": "فهرست مدارک", "help": "هر سطر یک مورد"},
            {"key": "delivery_method", "label": "روش ارسال", "type": "select", "group": "مشخصات ارسال",
             "options": ["پیک", "پست پیشتاز", "ایمیل", "تحویل حضوری", "باربری", "سایر"]},
            {"key": "extra_notes", "label": "توضیحات تکمیلی", "type": "notes", "group": "سایر"},
        ],
        "body": """<p>با سلام و احترام؛</p>
<p>احتراماً، {{sending_reason}}، مدارک به شرح ذیل به پیوست تقدیم می‌گردد:</p>
<p>{{attachments_list}}</p>
{{delivery_block}}
<p>خواهشمند است پس از دریافت، مراتب را جهت ثبت در سوابق به این واحد اعلام فرمایید.</p>
{{extra_notes_block}}
<p>با احترام.</p>""",
    },
    {
        "title": "اعلام مغایرت کالا یا خدمات",
        "category": "اداری و تجاری",
        "description": "اعلام رسمی مغایرت، نقص یا کمبود کالا و خدمات دریافتی",
        "fields": [
            {"key": "receiver", "label": "تأمین‌کننده / طرف قرارداد", "type": "contact", "required": True, "group": "اطلاعات گیرنده"},
            {"key": "company_name", "label": "نام شرکت اعلام‌کننده", "type": "text", "required": True, "group": "مشخصات اعلام"},
            {"key": "invoice_no", "label": "شماره فاکتور / قرارداد", "type": "id_no", "required": True, "group": "مشخصات سند"},
            {"key": "receive_date", "label": "تاریخ دریافت کالا / خدمات", "type": "jalali_date", "required": True, "group": "مشخصات سند"},
            {"key": "mismatch_type", "label": "نوع مغایرت", "type": "select", "required": True, "group": "شرح مغایرت",
             "options": ["کمبود تعداد", "مغایرت مشخصات فنی", "خرابی یا ایراد", "عدم تطابق با سفارش", "کمبود مدارک", "سایر"]},
            {"key": "mismatch_desc", "label": "شرح مغایرت", "type": "textarea", "required": True, "group": "شرح مغایرت"},
            {"key": "request_line", "label": "درخواست (جبران / تعویض / اصلاح)", "type": "textarea", "required": True, "group": "شرح مغایرت"},
            {"key": "deadline_date", "label": "مهلت پاسخ", "type": "jalali_date", "group": "سایر"},
            {"key": "extra_notes", "label": "توضیحات تکمیلی", "type": "notes", "group": "سایر"},
        ],
        "body": """<p>با سلام و احترام؛</p>
<p>احتراماً، بازنشانی به استحضار می‌رساند در بررسی کالاها/خدمات موضوع فاکتور/قرارداد شماره <b>{{invoice_no}}</b> دریافت‌شده در تاریخ <b>{{receive_date}}</b>، مغایرتی به نوع <b>{{mismatch_type}}</b> مشاهده گردید.</p>
<p>شرح مغایرت: {{mismatch_desc}}</p>
<p>درخواست این مجموعه: {{request_line}}</p>
{{deadline_note}}
<p>مستندات و تصاویر مربوطه در صورت نیاز ارائه خواهد شد. خواهشمند است جهت رفع مغایرت در اسرع وقت هماهنگی لازم صورت پذیرد.</p>
{{extra_notes_block}}
<p>با احترام.</p>""",
    },
]

BLOCK_FIELDS = {
    "qty_block": "<p>مقدار تقریبی موردنیاز: {{qty_note}}</p>",
    "deadline_block": "<p>مستدعی است قیمت‌ها حداکثر تا تاریخ {{deadline_date}} اعلام گردد.</p>",
    "terms_block": "<p>شرایط موردنظر این شرکت — تحویل: {{delivery_terms}}؛ پرداخت: {{payment_terms}}</p>",
    "extra_notes_block": "<p>{{extra_notes}}</p>",
    "inquiry_ref_line": " (نامه شماره {{inquiry_ref}})",
    "total_block": "<p>جمع کل پیشنهاد: <b>{{total_amount}} ریال</b></p>",
    "delivery_line": " و مدت و شرایط تحویل {{delivery_terms}} است",
    "coop_desc_line": " و با توجه به {{coop_desc}}",
    "advantages_block": "<p>مزایای همکاری: {{advantages}}</p>",
    "meeting_block": "<p>در صورت موافقت، پیشنهاد می‌گردد جلسه‌ای جهت بررسی جزئیات همکاری برگزار گردد.</p>",
    "agenda_block": "<p>دستور جلسه:<br>{{agenda}}</p>",
    "attendees_block": "<p>حضورکنندگان پیشنهادی: {{attendees_note}}</p>",
    "attachments_block": "<p>پیوست‌ها:<br>{{attachments_list}}</p>",
    "overdue_block": "<p>با توجه به سررسید {{due_date}}، پرداخت مذکور {{overdue_days}} روز تأخیر دارد.</p>",
    "installment_line": " در صورت نیاز، پیشنهاد تقسیط {{installment_offer}} قابل بررسی است",
    "national_id_line": " (کد ملی: {{national_id}})",
    "role_line": " به سمت {{person_role}}",
    "delivery_block": "<p>روش ارسال: {{delivery_method}}</p>",
    "deadline_note": "<p>مهلت پاسخ: {{deadline_date}}</p>",
}
