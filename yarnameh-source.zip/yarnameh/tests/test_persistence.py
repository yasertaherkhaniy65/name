"""آزمون ماندگاری داده پس از راه‌اندازی مجدد + idempotency مهاجرت‌ها."""
import httpx
import sqlite3
import subprocess
import sys
import time
import os
import shutil

BASE = "http://127.0.0.1:8903"
DATA = "/home/z/my-project/yarnameh-test3"
ROOT = "/home/z/my-project/download/yarnameh"

shutil.rmtree(DATA, ignore_errors=True)
os.makedirs(DATA)
env = os.environ | {"YARNAMEH_DATA_DIR": DATA}


def start():
    p = subprocess.Popen([sys.executable, "-m", "uvicorn", "app.main:app",
                          "--host", "127.0.0.1", "--port", "8903"],
                         cwd=ROOT, env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    for _ in range(40):
        try:
            httpx.get(f"{BASE}/api/health", timeout=2)
            return p
        except Exception:
            time.sleep(0.5)
    raise RuntimeError("سرور بالا نیامد")


p = start()
try:
    c = httpx.Client(base_url=BASE, timeout=30)
    con = c.post("/api/contacts", json={"kind": "company", "name": "شرکت ماندگار"}).json()
    tpl = c.post("/api/templates", json={
        "title": "الگوی ماندگار", "body_html": "<p>{{xx}}</p>",
        "fields": [{"field_key": "xx", "label": "XX", "field_type": "text"}]}).json()
    gen = c.post("/api/letters/generate", json={"template_id": tpl["id"], "params": {"xx": "مقدار"}}).json()
    ltr = c.post("/api/letters", json={"template_id": tpl["id"], "subject": "نامه ماندگار",
                                       "body_html": gen["body_html"], "params": gen["params"]}).json()
    fin = c.post(f"/api/letters/{ltr['id']}/finalize",
                 json={"sequence_id": 1, "issue_date": "1405/08/03"}).json()
    number = fin["letter_number"]
    conn = sqlite3.connect(f"{DATA}/yarnameh.sqlite")
    v1 = conn.execute("SELECT MAX(version) FROM schema_migrations").fetchone()[0]
    conn.close()
    print(f"شماره صادرشده: {number} | نسخه اسکیما: {v1}")
    assert number == "1405-0001" and v1 == 1
finally:
    p.terminate()
    p.wait(timeout=10)

# راه‌اندازی مجدد — داده‌ها باید حفظ شوند
p = start()
try:
    c = httpx.Client(base_url=BASE, timeout=30)
    letters = c.get("/api/letters", params={"q": "ماندگار"}).json()
    found = [l for l in letters["items"] if l["letter_number"] == number]
    print("پس از اجرای مجدد: نامه و شماره حفظ شد:", bool(found))
    assert found
    contacts = c.get("/api/contacts", params={"q": "ماندگار"}).json()
    assert contacts["total"] == 1
    # idempotency مهاجرت — اجرای مجدد نباید نسخه‌ای اضافه کند
    conn = sqlite3.connect(f"{DATA}/yarnameh.sqlite")
    v2 = conn.execute("SELECT MAX(version) FROM schema_migrations").fetchone()[0]
    count = conn.execute("SELECT COUNT(*) FROM schema_migrations").fetchone()[0]
    conn.close()
    print(f"مهاجرت‌ها idempotent: نسخه {v2} با {count} رکورد (باید ۱ باشد)")
    assert v2 == 1 and count == 1
    print("PERSISTENCE TEST: PASS")
finally:
    p.terminate()
    p.wait(timeout=10)
