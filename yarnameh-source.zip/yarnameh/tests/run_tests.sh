#!/bin/bash
# اجرای سرور آزمون + آزمون‌ها در یک نشست
set -e
cd /home/z/my-project/download/yarnameh
rm -rf /home/z/my-project/yarnameh-test
mkdir -p /home/z/my-project/yarnameh-test
export YARNAMEH_DATA_DIR=/home/z/my-project/yarnameh-test
python3 -m uvicorn app.main:app --host 127.0.0.1 --port 8901 > /tmp/yarnameh-test-server.log 2>&1 &
SERVER_PID=$!
sleep 4
python3 tests/test_api.py
TEST_EXIT=$?
kill $SERVER_PID 2>/dev/null || true
sleep 1
echo "--- آخرین لاگ سرور ---"
tail -5 /tmp/yarnameh-test-server.log
exit $TEST_EXIT
