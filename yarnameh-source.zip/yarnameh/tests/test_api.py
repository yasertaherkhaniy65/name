"""یارنامه — آزمون جامع API (۱۸ آزمون الزامی، سطح سرویس).
اجرا: python tests/test_api.py  (سرور باید روی 127.0.0.1:8901 با دیتای تمیز بالا باشد)
"""
import io
import json
import struct
import sys
import zlib

import httpx

BASE = "http://127.0.0.1:8901"
PASS, FAIL = [], []


def check(name, cond, detail=""):
    if cond:
        PASS.append(name)
        print(f"  ✓ {name}")
    else:
        FAIL.append((name, detail))
        print(f"  ✗ {name} — {detail}")


def png_bytes(w=4, h=4):
    def chunk(typ, data):
        c = struct.pack(">I", len(data)) + typ + data
        return c + struct.pack(">I", zlib.crc32(typ + data) & 0xFFFFFFFF)
    ihdr = struct.pack(">IIBBBBB", w, h, 8, 2, 0, 0, 0)
    raw = b"".join(b"\x00" + b"\x99" * (w * 3) for _ in range(h))
    idat = zlib.compress(raw)
    return (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", ihdr)
            + chunk(b"IDAT", idat) + chunk(b"IEND", b""))


def main():
    c = httpx.Client(base_url=BASE, timeout=30)

    print("\n[۱] سلامت سرویس و دیتابیس")
    h = c.get("/api/health").json()
    check("health ok", h["ok"] and h["db_ok"])
    check("schema v1", h["schema_version"] >= 1)

    print("\n[۲] مخاطبین: ثبت، هشدار تکراری، فیلتر")
    r = c.post("/api/contacts", json={"kind": "bank", "name": "بانک ملت شعبه ولیعصر",
                                      "address": "تهران، خیابان ولیعصر", "postal_code": "1234567890",
                                      "phone": "0218123"}).json()
    bank_id = r["id"]
    r2 = c.post("/api/contacts", json={"kind": "company", "name": "شرکت نمونه فولاد"}).json()
    company_id = r2["id"]
    dups = c.get("/api/contacts/similar", params={"name": "بانک ملت"}).json()
    check("هشدار مخاطب مشابه", len(dups["items"]) >= 1)
    lst = c.get("/api/contacts", params={"q": "فولاد"}).json()
    check("جست‌وجوی مخاطب", lst["total"] == 1)
    bad = c.post("/api/contacts", json={"kind": "company", "name": "x", "postal_code": "12"})
    check("اعتبارسنجی کد پستی", bad.status_code == 422)

    print("\n[۳] امضاکنندگان + آپلود امن تصویر امضا")
    sig = c.post("/api/signatories", json={"full_name": "علی رضایی", "position": "مدیرعامل",
                                           "unit": "هیئت مدیره"}).json()
    sig_id = sig["id"]
    up = c.post(f"/api/signatories/{sig_id}/image?kind=signature",
                files={"file": ("sig.png", io.BytesIO(png_bytes()), "image/png")})
    check("آپلود امضا", up.status_code == 200)
    sig_path = up.json()["path"]
    fake = c.post(f"/api/signatories/{sig_id}/image?kind=stamp",
                  files={"file": ("fake.png", io.BytesIO(b"not an image"), "image/png")})
    check("رد فایل جعلی (magic bytes)", fake.status_code == 415)

    print("\n[۴] الگوها: CRUD + پارامترهای پویا")
    tpl = c.post("/api/templates", json={
        "title": "الگوی آزمون آزمایشی", "category": "اداری و تجاری",
        "description": "تست", "paper_size": "A4",
        "body_html": "<p>با سلام؛</p><p>شرکت {{company_name}} درخواست {{subject_of_request}} به مبلغ {{amount}} ریال دارد.</p><p>شماره: {{letter_number}}</p>{{notes_block}}",
        "fields": [
            {"field_key": "company_name", "label": "نام شرکت", "field_type": "text", "is_required": True},
            {"field_key": "subject_of_request", "label": "موضوع درخواست", "field_type": "select",
             "is_required": True, "options": ["تسهیلات", "حساب"]},
            {"field_key": "amount", "label": "مبلغ", "field_type": "amount"},
            {"field_key": "notes", "label": "توضیحات", "field_type": "notes"},
            {"field_key": "receiver", "label": "مخاطب", "field_type": "contact"},
        ]}).json()
    tpl_id = tpl["id"]
    got = c.get(f"/api/templates/{tpl_id}").json()
    check("فیلدهای پویا ذخیره شد", len(got["fields"]) == 5)
    bad_key = c.post("/api/templates", json={"title": "bad", "fields": [{"field_key": "Invalid-Key!", "label": "x"}]})
    check("رد نام سیستمی نامعتبر", bad_key.status_code == 422)

    print("\n[۵] تولید متن: جایگزینی صحیح متغیرها + پارامترهای وابسته")
    gen = c.post("/api/letters/generate", json={"template_id": tpl_id, "params": {
        "company_name": "شرکت <script>alert(1)</script> فولاد",
        "subject_of_request": "تسهیلات",
        "amount": "1250000000",
        "notes": "تست چند خطی",
        "receiver": str(company_id)}}).json()
    body = gen["body_html"]
    check("جایگزین متغیر ساده", "۱٬۲۵۰٬۰۰۰٬۰۰۰" in body.replace(",", "،") or "1,250,000,000" in body)
    check("escape امن (XSS)", "<script>" not in body)
    check("پارامتر وابسته", "تهران، خیابان ولیعصر" in body.replace("&amp;", "&") or "receiver_address" not in body)
    miss = c.post("/api/letters/generate", json={"template_id": tpl_id, "params": {"company_name": ""}})
    check("اعتبارسنجی فیلد الزامی", miss.status_code == 422)
    check("شماره در پیش‌نویس نقطه‌چین", "&#8230;" in body)

    print("\n[۶] پیش‌نویس: ذخیره، بازیابی، ویرایش خودکار")
    r = c.post("/api/letters", json={"template_id": tpl_id, "subject": "درخواست تسهیلات آزمون",
                                     "contact_id": bank_id, "body_html": body,
                                     "params": gen["params"], "signatory_ids": [sig_id]}).json()
    lid = r["id"]
    got = c.get(f"/api/letters/{lid}").json()
    check("پیش‌نویس بدون شماره", got["letter_number"] is None)
    check("امضاکننده متصل شد", len(got["signatories"]) == 1)
    up2 = c.put(f"/api/letters/{lid}", json={
        "template_id": tpl_id, "subject": "درخواست تسهیلات آزمون (ویرایش)",
        "contact_id": bank_id, "body_html": body + "<p>خط افزوده</p>",
        "params": gen["params"], "manually_edited": 1}).json()
    check("ذخیره خودکار پیش‌نویس", up2["ok"])
    got2 = c.get(f"/api/letters/{lid}").json()
    check("ویرایش حفظ شد", "خط افزوده" in got2["body_html"])

    print("\n[۷] بازتولید متن: حفظ نسخه قبلی")
    regen = c.post(f"/api/letters/{lid}/regenerate", json={"template_id": tpl_id, "params": {
        **gen["params"], "company_name": "شرکت بازتولیدشده"}}).json()
    check("متن بازتولید شد", "بازتولیدشده" in regen["body_html"])
    got3 = c.get(f"/api/letters/{lid}").json()
    check("نسخه قبلی نگه داشته شد", got3["versions"][0]["note"] == "نسخه قبل از بازتولید متن")

    print("\n[۸] شماره‌گذاری: یکتایی، قالب، عدم شماره برای پیش‌نویس")
    fin = c.post(f"/api/letters/{lid}/finalize", json={"sequence_id": 1, "issue_date": "1405/08/03"}).json()
    check("شماره صادر شد", fin["letter_number"] == "1405-0001", str(fin))
    # اتصال مجدد → خطا
    again = c.post(f"/api/letters/{lid}/finalize", json={"sequence_id": 1, "issue_date": "1405/08/03"})
    check("ثبت مجدد رد شد", again.status_code == 409)
    # ویرایش نامه ثبت‌شده ممنوع
    edit_final = c.put(f"/api/letters/{lid}", json={"subject": "هک", "body_html": "x"})
    check("نامه ثبت‌شده تغییرناپذیر", edit_final.status_code == 409)
    # ۵ نامه دیگر → شماره‌های یکتا متوالی
    numbers = [fin["letter_number"]]
    for i in range(5):
        rr = c.post("/api/letters", json={"template_id": tpl_id, "subject": f"نامه {i}",
                                          "body_html": body, "params": gen["params"]}).json()
        f2 = c.post(f"/api/letters/{rr['id']}/finalize", json={"sequence_id": 1, "issue_date": "1405/08/05"}).json()
        numbers.append(f2["letter_number"])
    check("۵ شماره متوالی بدون تکرار", numbers == ["1405-0001", "1405-0002", "1405-0003", "1405-0004", "1405-0005", "1405-0006"], str(numbers))
    inv = c.post("/api/letters", json={"template_id": tpl_id, "subject": "تاریخ بد", "body_html": body, "params": gen["params"]}).json()
    inv_fin = c.post(f"/api/letters/{inv['id']}/finalize", json={"sequence_id": 1, "issue_date": "1405/12/31"})
    check("رد تاریخ نامعتبر شمسی (۳۰ اسفند سال غیرکبیسه)", inv_fin.status_code == 422)

    print("\n[۹] ابطال: علت ثبت، شماره حفظ می‌شود و آزاد نمی‌گردد")
    cn = c.post(f"/api/letters/{inv['id']}/finalize", json={"sequence_id": 1, "issue_date": "1405/08/10"}).json()
    cnum = cn["letter_number"]
    cancel = c.post(f"/api/letters/{inv['id']}/cancel", json={"reason": "اشتباه در مبلغ"}).json()
    check("ابطال با علت", cancel["ok"])
    got_c = c.get(f"/api/letters/{inv['id']}").json()
    check("شماره ابطال‌شده حفظ شده", got_c["letter_number"] == cnum and got_c["status"] == "canceled")
    rr = c.post("/api/letters", json={"template_id": tpl_id, "subject": "بعد از ابطال", "body_html": body, "params": gen["params"]}).json()
    f3 = c.post(f"/api/letters/{rr['id']}/finalize", json={"sequence_id": 1, "issue_date": "1405/08/11"}).json()
    check("شماره بعد از ابطال سرریز نمی‌شود", f3["letter_number"] == "1405-0008", f3["letter_number"])

    print("\n[۱۰] کپی نامه → پیش‌نویس بدون شماره")
    cp = c.post(f"/api/letters/{lid}/copy").json()
    got_cp = c.get(f"/api/letters/{cp['id']}").json()
    check("کپی پیش‌نویس بدون شماره", got_cp["status"] == "draft" and got_cp["letter_number"] is None)

    print("\n[۱۱] بایگانی و جست‌وجو")
    arch = c.get("/api/letters", params={"q": "فولاد", "status": "final"}).json()
    check("جست‌وجوی متن/موضوع", arch["total"] >= 5)
    dr = c.get("/api/letters", params={"from_jalali": "1405-08-03", "to_jalali": "1405-08-05"}).json()
    check("فیلتر بازه تاریخ شمسی", dr["total"] >= 5)

    print("\n[۱۲] پاک‌سازی HTML نامه در ذخیره‌سازی")
    r = c.post("/api/letters", json={"template_id": 0, "subject": "XSS تست",
                                     "body_html": "<p>سلام</p><script>alert(1)</script><p style=\"width:expression(alert(1))\">متن</p><img src=x onerror=alert(1)>"}).json()
    got_x = c.get(f"/api/letters/{r['id']}").json()
    check("اسکریپت حذف شد", "<script" not in got_x["body_html"] and "onerror" not in got_x["body_html"])
    check("expression در استایل حذف شد", "expression" not in got_x["body_html"])
    check("متن سالم ماند", "سلام" in got_x["body_html"])

    print("\n[۱۳] امنیت: مبدأ، هاست، مسیر فایل‌ها")
    x = c.post("/api/contacts", json={"kind": "person", "name": "hacker test"},
               headers={"Origin": "http://evil.example.com"})
    check("درخواست Cross-Origin رد شد", x.status_code == 403)
    x2 = c.get("/api/health", headers={"Host": "evil.com:8901"})
    check("Host خارجی رد شد", x2.status_code == 403)
    trav = c.get("/api/media/logos/../../yarnameh.sqlite")
    check("Path Traversal رد شد — دیتابیس افشا نشد",
          not trav.content.startswith(b"SQLite format") and " yarnameh.sqlite" not in trav.text[:0],
          trav.text[:60])
    fake_media = c.get("/api/media/logos/notahexname.png")
    check("نام فایل غیرمجاز رد شد", fake_media.status_code == 404)
    ok_media = c.get(f"/api/media/{sig_path.replace('files/', '')}")
    check("فایل مجاز با الگوی درست ارائه شد", ok_media.status_code == 200 and ok_media.headers["content-type"] == "image/png")

    print("\n[۱۴] گزارش‌ها و داشبورد")
    dash = c.get("/api/dashboard").json()
    check("داشبورد از دیتابیس واقعی", dash["total_final"] >= 7)
    rep = c.get("/api/reports").json()
    check("گزارش ماهانه ۱۲ ماه", len(rep["by_month"]) == 12)

    print("\n[۱۵] پشتیبان‌گیری با Backup API + سلامت فایل")
    bk = c.post("/api/backup/create").json()
    check("پشتیبان ساخته شد", bk["ok"] and bk["size"] > 1000)
    bl = c.get("/api/backup/list").json()
    check("فهرست پشتیبان", len(bl["items"]) >= 1)
    dl = c.get(f"/api/backup/download/{bk['file_name']}")
    check("دانلود پشتیبان", dl.status_code == 200 and len(dl.content) == bk["size"])
    rs = c.post("/api/backup/restore", json={"file_name": bk["file_name"]}).json()
    check("بازیابی با پشتیبان ایمنی", rs.get("ok") and "safety_backup" in rs)
    bad_rs = c.post("/api/backup/restore", json={"file_name": "../../etc/passwd"})
    check("نام فایل پشتیبان نامعتبر رد شد", bad_rs.status_code == 404)

    print("\n[۱۶] AI بدون کلید: خطای کنترل‌شده بدون کرش")
    ai = c.get("/api/ai/status").json()
    check("وضعیت AI گزارش می‌شود", "enabled" in ai)
    ai_try = c.post("/api/ai/draft", json={"description": "درخواست مرخصی سه روزه"})
    check("بدون کلید: پیام روشن نه کرش", ai_try.status_code in (409,))

    print("\n[۱۷] حذف مخاطب استفاده‌شده → حفظ سوابق")
    used = c.delete(f"/api/contacts/{bank_id}")
    check("حذف مخاطب استفاده‌شده رد شد", used.status_code == 409)
    f = used.json().get("detail", {})
    check("گزارش تعداد استفاده", isinstance(f, dict) and f.get("usage_count", 0) >= 1)
    ldc = c.get(f"/api/letters/{lid}").json()
    check("نامه‌ها بعد از رد حذف سالم", ldc["letter_number"] == "1405-0001")

    print("\n[۱۸] حذف الگوی استفاده‌شده → حفظ نامه‌ها")
    dt = c.delete(f"/api/templates/{tpl_id}")
    check("حذف الگوی استفاده‌شده رد شد", dt.status_code == 409)
    got4 = c.get(f"/api/letters/{lid}").json()
    check("متن نامه مستقل از الگو", len(got4["body_html"]) > 50)

    print("\n" + "=" * 60)
    print(f"نتیجه: {len(PASS)} موفق، {len(FAIL)} ناموفق")
    if FAIL:
        for name, detail in FAIL:
            print(f"  ✗ {name}: {detail}")
        sys.exit(1)


if __name__ == "__main__":
    main()
